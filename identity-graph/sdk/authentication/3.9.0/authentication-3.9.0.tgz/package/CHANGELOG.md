# Changelog
All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [3.9.0] - 2026-11-03

### Added
- Added Unity services CLI commands for Authentication, available when `com.unity.pipeline` is installed.
- Added `services.authentication.player_accounts` CLI commands (compiled only when `com.unity.pipeline` is installed) to set up Unity Player Accounts for the linked project without the Dashboard: `enable`, `get` and `update` for the project's Player Accounts client, and `list_identity_providers`, `create_identity_provider`, `enable_identity_provider`, `disable_identity_provider` and `delete_identity_provider` for the game's own Apple, Google and Facebook apps.
- Live Releases: sign-in requests now include the release pointer configured in Core, so the server resolves the player's session to that release. The resolved release is available from `AuthenticationService.Instance.Targeting.ReleaseId` and `ReleaseName`, and is shared with other Unity Gaming Services packages through Core.
- Live Releases: in Play Mode in the Editor, sign-in uses the release selected for the active environment in Project Settings > Services > Environments, unless a release pointer is set in code.

### Changed
- Requires `com.unity.services.core` 1.19.0 or newer.
- Player Accounts `IsSignedIn` now stays `true` during a token refresh, and `SignInFailed` is now raised after the player is signed out.

### Fixed
- Fixed the Authentication project settings reporting that it finished waiting twice when saving or deleting an ID provider failed.
- Fixed Player Accounts sign-in on Android and iOS not validating the OAuth `state` parameter. A custom redirect page or proxy must pass `state` through unchanged.
- Fixed Player Accounts `SignOut()` not cancelling a sign-in or token refresh in progress.
- Fixed Player Accounts sign-in and token refresh failures not being reported, or leaving the player in an inconsistent state.
- Fixed the ID provider save and delete confirmation dialogs in Project Settings showing an extra "No" button that logged an "Unrecognized option" error.

## [3.8.1] - 2026-10-21

### Fixed
- Fixed targeting sending no attributes on sign-in, so no variant tags resolved, in players built with Managed Stripping Level `Low` or higher.

## [3.8.0] - 2026-09-14

### Added
- Added `IAuthenticationService.State`, exposing the current `AuthenticationState` (`SignedOut`, `SigningIn`, `Authorized`, `Refreshing`, `Expired`) that reflects the lifecycle of the player's session and access token.
- Added support for the Apple Swift Xcode project type on iOS. Requires Unity 6000.6.0b7 or newer, which exposes the project type's public symbols through the `UnityAPI` framework.

### Changed
- Now always enabling the server assembly in editor mode to enable authoring assets. This assembly remains unavailable on non dedicated server builds. (Condition: `UNITY_EDITOR || UNITY_SERVER || ENABLE_UCS_SERVER`)

## [3.7.4] - 2026-08-12

### Fixed
- Fixed server access tokens never being refreshed. The scheduled refresh re-entered the sign-in methods, which rejected the `Refreshing` state with `ClientInvalidUserState`, logged `Failed to refresh access token due to network error or internal server error, will retry later.` and eventually moved the server to `Expired`. This affected both `SignInWithServiceAccountAsync` and `SignInFromServerAsync`. A refreshed service account token is now also granted the scopes requested at sign-in, and a refresh that fails keeps the current access token instead of reporting an `AuthorizationFailed` event.

## [3.7.3] - 2026-07-06

### Fixed
- Fixed the Authentication SDK leaking low-level exceptions (such as `NullReferenceException`) instead of `RequestFailedException` under hostile or blocked network conditions. Sign-in failures now consistently surface as a `RequestFailedException`; a null or empty response is reported as `CommonErrorCodes.TransportError`.
- Fixed UI samples to use the new input system

## [3.7.2] - 2026-06-30

### Fixed
- Fixed an issue on iOS where the Unity Player Accounts sign-in window stayed open after sign-in without returning to the app, thereby failing to complete the sign-in process. The fix comes with some changes to the authentication flow on iOS: on calling `PlayerAccountService.Instance.StartSignInAsync()`, users will now see a pop-up '<app name> wants to use "unity3d.com" to sign in' with 'Cancel' and 'Continue' buttons. If the user presses 'Continue', they will then proceed to the sign-in page via web view as before, and will be returned to the app on successful sign-in. Pressing 'Cancel' will abort the sign-in attempt and return the user to the app immediately.

## [3.7.1] - 2026-06-16

### Added
- Restricted session token requests now include the installation ID.

## [3.7.0] - 2026-06-03

### Added
- Added Targeting component and enablement
  - AuthenticationService.Instance.Targeting.SetEnabled(true);
- Added `IAuthenticationService.GenerateRestrictedTokenAsync(RestrictedTokenOptions)` for issuing a session token with caller-controlled restrictions, returned to the caller rather than applied to the current session.

### Fixed
- Fixed an issue where enabling Unity Player Accounts on iOS removed other custom URL schemes from the app.
- Support for 2021 has been dropped

## [3.6.1] - 2026-03-24

### Fixed
- Fixed Player Accounts handling of deep links that are not part of an active sign-in.

## [3.6.0] - 2025-12-10

### Added
- Added ability to specify scopes when signing in with a service account in the server authentication service. The base method now provides all scopes associated to the service account.

### Fixed
- Fixed an issue with ID token validation during code-link to check for both null and empty string values, ensuring proper handling of invalid tokens.

### Changed
- Changed the `SessionToken` value to be public for easier access.

## [3.5.1] - 2025-05-26

### Added
- Added event `IAuthenticationService.PlayerInfoChanged` for when the instance of `PlayerInfo` is set.
- Added event `PlayerInfo.Changed` for when the values within `PlayerInfo` are updated.
- Added event `IAuthenticationService.PlayerNameChanged` for when the player name changes.
- Added event `IAuthenticationService.PlayerIdChanged` for when the player id changes.
- Added more details to server exception messages.

## [3.4.1] - 2025-03-11

### Fixed
- Fixed an issue where the player name does not update correctly when calling `IAuthenticationService.SwitchProfile()`
- Fixed an unexpected error log in the Player Accounts sample

## [3.4.0] - 2024-11-08

### Added
- Added `PlayerAuthentication` component to manage authentication in the scene authoring.

### Changed
- Updated the minimum supported Editor version to 2021.3.

## [3.3.4] - 2024-09-18
### Fixed
- Fixed an issue where `IAuthenticationService.Instance.GetSignInCodeInfoAsync()` and `IAuthenticationService.Instance.ConfirmCodeAsync()` was not working properly on iOS devices

## [3.3.3] - 2024-06-10
### Fixed
- Fixed an issue where `IAuthenticationService.SwitchProfile()` was not working properly

## [3.3.2] - 2024-05-29
### Fixed
- Fixed missing script reference in Player Accounts sample

## [3.3.1] - 2024-04-02
### Added
- Added the Apple Privacy Manifest file (PrivacyInfo.xcprivacy)
- Added support for running different profiles when using Multiplayer Player Mode.

### Fixed
- Fixed `AuthenticationState` is in invalid state when access token is changed after sign-out or sign-in
- Fixed `NullReferenceException` in Player Accounts SDK if not properly set up and the application received a deep-link request.

## [3.3.0] - 2024-01-10
### Added
- Added `LastNotificationDate` field to inform the client of the player's notifications last created date.
- Added `GetNotificationsAsync` method to allow the client to request the player's notifications
- Added `Notifications` field to cache the notifications after GetNotificationsAsync is called
- Added `BannedUser` error code to identify an exception when a user has been banned.

### Fixed
- Fixed authentication refresh and expiration scheduling relying on device time which could cause edge cases.

## [3.2.0] - 2023-11-16

### Changed
- Changed `Custom Token Exchange` ID provider to `Custom ID`.

### Added
- Added `GetCustomId` method to PlayerInfo.
- Added `SignInWithSteamAsync` method with `appId` parameter for Multiple App Id Support
- Added `LinkWithSteamAsync` method with `appId` parameter for Multiple App Id Support
- Added `Additional App IDs` to Steam ID Provider for Multiple App Id support

### Fixed
- Fixed serialization of player accounts settings.

## [3.1.0] - 2023-10-20
### Added
- The Unity Player Accounts functionality has been merged in this package
- Added a warning when Unity Player Accounts package is installed with this version. It can be uninstalled
- Added `ProcessAuthenticationTokens` method to enable BYOI custom id sign-in

## [3.0.0] - 2023-08-21
### Changed
- Upgrading base unity version support to 2020.3
- Updated the core SDK dependency version

### Added
- Adding event in access token component for packages to be notified of changes to the `IAccessToken` value.
- Added `GenerateSignInCodeAsync` method to generate a sign-in code that can be used to sign-in.
- Added `SignInWithCodeAsync` method to sign in using the previously generated sign-in code. This method can optionally poll the server for sign-in confirmation.
- Added `GetSignInCodeInfoAsync` method to fetch information about a given sign-in code.
- Added `ConfirmCodeAsync` method for sending a request to confirm a provided sign-in code.
- Added `SignInCodeReceived` which is triggered when `SignInWithCodeAsync` method successfully generates a`SignInCode`.
- Added `SignInCodeExpired` which is invoked when the sign-in code expires.
- Adding server authentication service which lets developers authorize operations when running on unity's game server hosting or with service accounts.

## [2.7.2] - 2023-07-19
### Added
- Added `SignInWithSteamAsync` and `LinkWithSteamAsync` methods with `identity` parameter for better security.
- Added `SignInWithUsernamePasswordAsync`, `SignUpWithUsernamePasswordAsync`, `AddUsernamePasswordAsync`, `UpdatePasswordAsync`
### Changed
- Marked previous versions of `SignInWithSteamAsync` and `LinkWithSteamAsync` methods as obsolete.

## [2.6.1] - 2023-05-31
### Added
- Added `SignInWithUnityAsync` public API.
- Added `LinkWithUnityAsync` public API.
- Added `UnlinkUnityAsync` public API.
- Added Unity Player Accounts configuration in Editor settings.
### Fixed
- Adding Preserve attributes to api models to prevent issues with code stripping for Oculus

## [2.5.0] - 2023-05-09
### Fixed
- Properly disposing web request when using player names
- Fixing exception reporting in some cases for the SignInFailed event
- Remove time validation on client side, to prevent token expiry errors caused by the wrong date/time settings on devices.
- Adding Preserve attributes to api models to prevent issues with code stripping for player names

## [2.5.0-pre.3] - 2023-03-01
### Added
- Added `GetPlayerNameAsync` to retrieve the current player name in the Authentication service
- Added `UpdatePlayerNameAsync` to update the current player name in the Authentication service
- Added `PlayerName` property and caching in the Authentication service
### Changed
- `PlayerId` property now properly returns null instead of an empty string by default
- Package's license to refresh legal links.

## [2.4.0] - 2022-11-29
### Added
- Added `SignInWithAppleGameCenterAsync`, `LinkWithAppleGameCenterAsync`, `UnlinkAppleGameCenterAsync`
### Changed
- Updated the core SDK dependency version

## [2.3.1] - 2022-10-17
### Changed
- Updated the core SDK dependency version

## [2.3.0] - 2022-10-12
### Added
- Added `GetGooglePlayGamesId()` to `PlayerInfo`.
- Added `SignInWithOculusAsync`, `LinkWithOculusAsync`, `UnlinkOculusAsync`
- Added Oculus ID provider to Project Settings UI to configure ID providers.
### Changed
- Updated the core SDK dependency to the latest version.

## [2.2.0] - 2022-07-28
### Added
- Added `SignInWithOpenIdConnectAsync`, `LinkWithOpenIdConnectAsync`, `UnlinkOpenIdConnectAsync`
### Changed
- Updated the core SDK dependency to the latest version.

## [2.1.1] - 2022-06-22
### Changed
- Updated the core SDK dependency to latest version.

## [2.1.0] - 2022-06-07
### Added
- Added `SignInWithGooglePlayGames`, `LinkWithGooglePlayGames`, `UnlinkGooglePlayGames`
### Changed
- Updated the core SDK dependency to latest version.

## [2.0.0] - 2022-04-04
Public GA release.

## [1.0.0-pre.85] - 2022-02-23
### Changed
- Restructured package file hierarchy.
- Refactored PlayerInfo's CreatedAt to be a DateTime (UTC).
- Refactored PlayerInfo's identities to use new Identity type.
- ExternalId is no longer public and is replaced by Identity.

## [1.0.0-pre.83] - 2022-02-18
### Changed
- Removed 'SignInWithExternalTokenAsync and LinkWithExternalTokenAsync apis.
- Changed the following models to internal: UnlinkRequest, SignInWithExternalTokenRequest, LinkWithExternalTokenRequest

## [1.0.0-pre.80] - 2022-02-15
### Added
-  Added helper methods to retrieve external Ids
### Changed
-  Renamed public model `UserInfo` to `PlayerInfo`
-  Renamed `GetUserInfo` to `GetPlayerInfo`
-  Removed `DomainId` property from the `PlayerInfo` model

## [1.0.0-pre.77] - 2022-02-12
### Added
- Added SignInOptions models for all sign in operations.
- Added LinkOptions model for all link operations.
### Changed
- Removed SignInWithSessionTokenAsync. This is fully handled by SignInAnonymously.
- Split ExternalTokenRequest into SignInExtenalTokenRequest and LinkWithExternalTokenRequest.

## [1.0.0-pre.73] - 2022-02-08
### Changed
- Removed namespaces Unity.Services.Authentication.Models and Unity.Services.Authentication.Utilities for simplified use.

## [1.0.0-pre.67] - 2022-02-02
### Added
- Added optional parameter on Signout to clear credentials.
- Added player id caching between sessions.
- Added optional force link parameter to linking apis (Apple, Facebook, Google, Steam).
### Changed
- Reset the session token when getting an invalid session token error.

## [1.0.0-pre.44] - 2021-12-16
### Added
- Added enableRefresh parameter to SignInWithExternalTokenAsync.

## [1.0.0-pre.32] - 2021-12-03
Added profile support. Profiles allow managing multiple accounts at the same time by isolating the session token persistence.
### Added
- Added `Profile` property to `IAuthenticationService` to access the current profile.
- Added `SwitchProfile` to `IAuthenticationService` to change the current profile.
- Added `ClientInvalidProfile` error code to `AuthenticationErrorCodes` used when entering an invalid profile name.
- Added `SetProfile` extension method to `InitializationOptions`.

## [1.0.0-pre.26] - 2021-11-26
### Added
- Added `DeleteAccountAsync` to `IAuthenticationService`.
- Added `AccountLinkLimitExceeded` and `ClientUnlinkExternalIdNotFound` error codes to `AuthenticationErrorCodes`.
- Error code `AccountLinkLimitExceeded` is used when the current player's account has reached the limit of links for the provider when using a link operation.
- Error code `ClientUnlinkExternalIdNotFound` is sent when no matching external id is found in the player's `UserInfo` when using an unlink operation.

## [1.0.0-pre.20] - 2021-11-19
### Added
- Added `UserInfo` property to `IAuthenticationService`.
- Added `UnlinkAppleAsync` function to `IAuthenticationService`.
- Added `UnlinkFacebookAsync` function to `IAuthenticationService`.
- Added `UnlinkGoogleAsync` function to `IAuthenticationService`.
- Added `UnlinkSteamAsync` function to `IAuthenticationService`.

## [1.0.0-pre.14] - 2021-11-11
### Added
- Added `IsAuthorized` property.
- Added `SessionTokenExists` property.
- Added `GetUserInfoAsync` to `IAuthenticationService`

## [1.0.0-pre.8] - 2021-11-03
### Added
- Added `IsExpired` property.
- Added `Expired` event.
- Added `ClearSessionToken` function

## [1.0.0-pre.7] - 2021-10-20
### Changed
- Updated UI Samples
- Updated the core SDK dependency to latest version.

## [1.0.0-pre.6] - 2021-10-01
### Added
- Added Samples to Package Manager
- Added `SignInWithExternalTokenAsync` and `LinkWithExternalTokenAsync` to `IAuthenticationService`.
### Changed
- Made `ExternalTokenRequest` class public.

## [1.0.0-pre.5] - 2021-08-25
### Added
- Integrate with Package Manager under the Services tab filter and comply with the standard for the UI detail screen.

## [1.0.0-pre.4] - 2021-08-05
### Changed
- Updated the `AuthenticationException` to base on `RequestFailedException`.
- Updated the core SDK dependency to latest version.

## [1.0.0-pre.3] - 2021-07-30
### Fixed
- Package structure for promotion
### Changed
- Updated the core SDK dependency to latest version.

## [1.0.0-pre.2] - 2021-07-28
### Changed
- Updated the core SDK dependency to latest version.

## [1.0.0-pre.1] - 2021-07-28
### Changed
- Updated the core SDK dependency to latest version.

## [0.7.1-preview] - 2021-07-22
### Changed
- Updated the core SDK dependency to latest version.

## [0.7.0-preview] - 2021-07-22
### Changed
- Updated the core SDK dependency to latest version.
### Added
- Add missing xmldoc for the public functions.

## [0.6.0-preview] - 2021-07-15
### Added
- Add support for Unity Environments

## [0.5.0-preview] - 2021-06-16
### Changed
- Remove `SetOAuthClient()` as the authentication flow is simplified.
- Updated the initialization code to initialize with `UnityServices.Initialize()`

## [0.4.0-preview] - 2021-06-07
### Added
- Added Project Settings UI to configure ID providers.
- Added `SignInWithSteam`, `LinkWithSteam` functions.
- Changed the public interface of the Authentication service from a static instance and static methods to a singleton instance hidden behind an interface.

### Changed
- Change the public signature of `Authentication` to return a Task, as opposed to a IAsyncOperation
- Change the public API names of `Authentication` to `Async`

## [0.3.1-preview] - 2021-04-23
### Changed
- Change the `SignInFailed` event to take `AuthenticationException` instead of a string as parameter. It can provide more information for debugging purposes.
- Fixed the `com.unity.services.core` package dependency version.

## [0.3.0-preview] - 2021-04-21
### Added
- Added `SignInWithApple`, `LinkWithApple`, `SignInWithGoogle`, `LinkWithGoogle`, `SignInWithFacebook`, `LinkWithFacebook` functions.
- Added `SignInWithSessionToken`
- Added error codes used by the social scenarios to `AuthenticationError`.

## [0.2.3-preview] - 2021-03-23
### Changed
- Rename the package from `com.unity.services.identity` to `com.unity.services.authentication`. Renamed the internal types/methods, too.

## [0.2.2-preview] - 2021-03-15
### Added
- Core package integration

## [0.2.1-preview] - 2021-03-05

- Fixed dependency on Utilities package

## [0.2.0-preview] - 2021-03-05

- Removed requirement for OAuth client ID to be specified (automatically uses project default OAuth client)

## [0.1.0-preview] - 2021-01-18

### This is the first release of *com.unity.services.identity*.
