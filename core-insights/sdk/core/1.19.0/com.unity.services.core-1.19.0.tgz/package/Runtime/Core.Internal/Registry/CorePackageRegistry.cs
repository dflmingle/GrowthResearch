#if UNITY_6000_7_OR_NEWER
using Unity.Scripting.LifecycleManagement;
#endif
using UnityEngine;
using NotNull = JetBrains.Annotations.NotNullAttribute;

namespace Unity.Services.Core.Internal
{
    /// <summary>
    /// A container to store all available <see cref="IInitializablePackage"/> in the project.
    /// </summary>
#if UNITY_6000_7_OR_NEWER
    [NoAutoStaticsCleanup]
#endif
    public sealed class CorePackageRegistry
    {
        /// <summary>
        /// Get the unique package registry of this project.
        /// </summary>
        public static CorePackageRegistry Instance
        {
            get;
            internal set;
        }

        internal IPackageRegistry Registry { get; set; }

        /// <summary>
        /// Constructor for package registry container
        /// </summary>
        internal CorePackageRegistry()
        {
            Registry = new PackageRegistry(new DependencyTree());
        }

        /// <summary>
        /// Constructor for package registry container
        /// </summary>
        /// <param name="registry">The registry</param>
        internal CorePackageRegistry(IPackageRegistry registry)
        {
            Registry = registry;
        }

        internal static void ResetStaticsOnLoad()
        {
            Instance = null;
        }

        /// <summary>
        /// Register a package initializer to be executed during services initialization.
        /// </summary>
        /// <typeparam name="TPackage">Type of package</typeparam>
        /// <param name="package">The package</param>
        /// <returns>Fluent interface on registration</returns>
        public CoreRegistration Register<TPackage>(
            [NotNull] TPackage package)
            where TPackage : IInitializablePackage
        {
            return Registry.RegisterPackage(package);
        }

        internal void Lock()
        {
            if (Registry is LockedPackageRegistry)
            {
                return;
            }

            Registry = new LockedPackageRegistry(Registry);
        }
    }
}
