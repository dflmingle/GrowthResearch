package com.yandex.mobile.ads.interstitial

import android.app.Activity
import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdInfo

/**
 * Full-screen interstitial ad.
 */
@MainThread
interface InterstitialAd {

    /**
     * @return [AdInfo] information about loaded Ad.
     */
    val adInfo: AdInfo

    /**
     * Sets an [InterstitialAdEventListener].
     *
     * @param interstitialAdEventListener [InterstitialAdEventListener].
     */
    fun setAdEventListener(interstitialAdEventListener: InterstitialAdEventListener?)

    /**
     * Shows the interstitial ad. Single interstitial ad can be showed just once.
     *
     * @param activity [Activity].
     */
    fun show(activity: Activity)
}
