package com.yandex.mobile.ads.video.playback.model

/**
 * This class provides information about video ad
 */
interface VideoAd {

    /**
     * Gets video ad skip information
     *
     * @return video ad skip information or null if video ad not skippable
     */
    val skipInfo: SkipInfo?

    /**
     * Gets video ad playback information about the recommended mediafile based on its type and bitrate
     *
     * @return video ad playback information about the recommended mediafile
     */
    val mediaFile: MediaFile

    /**
     * Gets video ad playback information about all mediafiles
     *
     * @return video ad playback information about all mediafiles
     */
    val mediaFiles: List<MediaFile>

    /**
     * Gets ad pod information
     *
     * @return ad pod information
     */
    val adPodInfo: AdPodInfo

    /**
     * Gets video ad additional information
     *
     * @return video ad additional information
     */
    @Deprecated("Use VideoAd.adInfo.data")
    val info: String?

    /**
     * Gets video ad additional information
     *
     * @return video ad additional information
     */
    val adInfo: VideoAdInfo

    /**
     * Gets video ad duration in milliseconds
     *
     * @return video ad duration in milliseconds
     */
    val duration: Long

    /**
     * Gets video ad extensions
     *
     * @return video ad extensions
     */
    val extensions: VideoAdExtensions
}
