package com.yandex.mobile.ads.nativeads

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.ImpressionData

/**
 * A listener for receiving notifications during the lifecycle of a native ad.
 */
@MainThread
interface NativeAdEventListener {

    /**
     * Called when user clicked on the ad.
     */
    fun onAdClicked()

    /**
     * Called when an impression was observed
     *
     * @param impressionData - impression level revenue data
     */
    fun onImpression(impressionData: ImpressionData?)
}
