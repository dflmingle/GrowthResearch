package com.yandex.mobile.ads.common

/**
 * Container for base Ad information
 *
 * @property adUnitId Getter for Ad's unit ID
 * @property extraData Getter for extra information about Ad
 * @property partnerText Getter for text specified in the partner interface
 * @property creatives Getter for list of Creative objects
 */
class AdInfo internal constructor(
    val adUnitId: String,
    val extraData: String?,
    val partnerText: String?,
    val creatives: List<Creative>
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as AdInfo

        if (adUnitId != other.adUnitId) return false
        if (extraData != other.extraData) return false
        if (partnerText != other.partnerText) return false
        if (creatives != other.creatives) return false

        return true
    }

    override fun hashCode(): Int {
        var result = adUnitId.hashCode()
        result = 31 * result + (extraData?.hashCode() ?: 0)
        result = 31 * result + (partnerText?.hashCode() ?: 0)
        result = 31 * result + creatives.hashCode()
        return result
    }

    override fun toString(): String {
        return "AdInfo(adUnitId='$adUnitId', extraData=$extraData, partnerText=$partnerText, creatives=$creatives)"
    }
}
