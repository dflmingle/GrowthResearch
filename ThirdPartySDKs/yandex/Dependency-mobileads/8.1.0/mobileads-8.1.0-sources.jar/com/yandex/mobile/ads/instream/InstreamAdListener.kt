package com.yandex.mobile.ads.instream

import androidx.annotation.MainThread

/**
 * This interface is used to notify about events occuring during instream ad playback.
 */
@MainThread
interface InstreamAdListener {

    /**
     * Notifies about completion of instream ad playback.
     */
    fun onInstreamAdCompleted()

    /**
     * Notifies that preroll (if it exists in ad) is prepared.
     * If no preroll exists, callback will be fired immediately after prepare() call.
     */
    fun onInstreamAdPrepared()

    /**
     * Notifies about error occured during instream ad playback.
     *
     * @param reason Describes error
     */
    fun onError(reason: String)
}
