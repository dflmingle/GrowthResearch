package com.yandex.mobile.ads.rewarded

/**
 * Interface provides information about the reward given to the user.
 */
interface Reward {

    /**
     * Returns the amount of reward.
     *
     * @return Amount of reward.
     */
    val amount: Int

    /**
     * Returns the type of reward.
     *
     * @return Type of reward.
     */
    val type: String
}
