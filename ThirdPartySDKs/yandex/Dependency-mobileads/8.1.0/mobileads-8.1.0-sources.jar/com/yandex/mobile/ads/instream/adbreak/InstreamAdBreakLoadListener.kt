package com.yandex.mobile.ads.instream.adbreak

/**
 * Class that is implemented to determine when the Instream Ad Break loading has completed or failed.
 */
interface InstreamAdBreakLoadListener {

    /**
     * Notifies that [InstreamAdBreak] was loaded.
     *
     * @param instreamAdBreak [InstreamAdBreak] Result of successful response.
     */
    fun onAdLoaded(instreamAdBreak: InstreamAdBreak)

    /**
     * Notifies that [InstreamAdBreak] failed to load.
     *
     * @param error [InstreamAdBreakRequestError] Reason describing problem encountered while loading [InstreamAdBreak].
     */
    fun onAdFailedToLoad(error: InstreamAdBreakRequestError)
}
