package com.yandex.mobile.ads.instream.player.ad

import android.widget.FrameLayout
import androidx.annotation.MainThread
import com.yandex.mobile.ads.video.playback.model.VideoAd

/**
 * This interface is used for playing instream ad
 */
@MainThread
interface InstreamAdPlayer {

    /**
     * List of MIME types supported by the player.
     *
     * The SDK will use this list to select a compatible video file from the ad response.
     * Use [InstreamAdMimeTypes] constants to populate this list.
     */
    val supportedMimeTypes: List<String>

    /**
     * Provides a [FrameLayout] container for ad video playback.
     *
     * Implementations should attach their player's view or video surface to this container.
     *
     * @param container A [FrameLayout] that will host the ad video content.
     */
    fun bindPlayerView(container: FrameLayout)

    /**
     * Prepares player for playing video ad. Implement only this method for prepare Ad.
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun prepareAd(videoAd: VideoAd)

    /**
     * Starts playing ad
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun playAd(videoAd: VideoAd)

    /**
     * Pauses playing ad
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun pauseAd(videoAd: VideoAd)

    /**
     * Resumes playing ad
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun resumeAd(videoAd: VideoAd)

    /**
     * Stops playing ad
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun stopAd(videoAd: VideoAd)

    /**
     * Skips playing ad
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun skipAd(videoAd: VideoAd)

    /**
     * Sets ad player volume, with 0 being silence and 1 being maximum volume level
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     * @param volume  volume level in range [0.0, 1.0]
     */
    fun setVolume(
        videoAd: VideoAd,
        volume: Float
    )

    /**
     * Gets player volume level in range [0.0, 1.0]
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     * @return player volume level in range [0.0, 1.0]
     */
    fun getVolume(videoAd: VideoAd): Float

    /**
     * Releases ad player object
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     */
    fun releaseAd(videoAd: VideoAd)

    /**
     * Sets listener for ad player events. For each event of the instream ad player,
     * the corresponding callback must be called on this object.
     *
     * @param instreamAdPlayerListener Listener for ad player events
     */
    fun setInstreamAdPlayerListener(instreamAdPlayerListener: InstreamAdPlayerListener?)

    /**
     * Gets ad video duration
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     * @return ad video position in millis
     */
    fun getAdDuration(videoAd: VideoAd): Long

    /**
     * Gets current ad video position
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     * @return current ad video duration in millis
     */
    fun getAdPosition(videoAd: VideoAd): Long

    /**
     * Gets value indicating whether player is playing ad
     *
     * @param videoAd object providing information about the advertising video file to be played.
     * videoAd should be passed back in all callbacks to [InstreamAdPlayerListener]
     * @return value indicating whether player is playing ad
     */
    fun isPlayingAd(videoAd: VideoAd): Boolean
}
