package com.yandex.mobile.ads.interstitial

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdError
import com.yandex.mobile.ads.common.ImpressionData

/**
 * A listener for receiving notifications during the lifecycle of an interstitial ad.
 */
@MainThread
interface InterstitialAdEventListener {

    /**
     * Called when an interstitial ad has been shown.
     */
    fun onAdShown()

    /**
     * Called when an interstitial ad failed to show.
     */
    fun onAdFailedToShow(adError: AdError)

    /**
     * Called when an interstitial ad has been dismissed.
     */
    fun onAdDismissed()

    /**
     * Called when user clicked on the ad.
     */
    fun onAdClicked()

    /**
     * Called when an impression was observed
     *
     * @param impressionData - impression level revenue data
     */
    fun onAdImpression(impressionData: ImpressionData?)
}
