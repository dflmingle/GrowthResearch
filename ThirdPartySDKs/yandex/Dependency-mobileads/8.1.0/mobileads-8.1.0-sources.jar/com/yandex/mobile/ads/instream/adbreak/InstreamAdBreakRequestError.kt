package com.yandex.mobile.ads.instream.adbreak

/**
 * Class containing errors that can occur during an ad break request.
 *
 * @property description An error description
 */
class InstreamAdBreakRequestError(
    val description: String
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as InstreamAdBreakRequestError

        return description == other.description
    }

    override fun hashCode(): Int {
        return description.hashCode()
    }

    override fun toString(): String {
        return "InstreamAdBreakRequestError(description='$description')"
    }
}
