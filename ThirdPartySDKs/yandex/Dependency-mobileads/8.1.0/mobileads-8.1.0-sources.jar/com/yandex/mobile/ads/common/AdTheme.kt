package com.yandex.mobile.ads.common

enum class AdTheme(val value: String) {
    LIGHT("light"),
    DARK("dark")
}
