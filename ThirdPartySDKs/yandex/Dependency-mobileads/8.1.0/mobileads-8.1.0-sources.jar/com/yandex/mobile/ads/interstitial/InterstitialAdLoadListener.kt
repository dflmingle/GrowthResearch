package com.yandex.mobile.ads.interstitial

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * A listener for receiving notifications during the lifecycle of an interstitial ad.
 */
@MainThread
interface InterstitialAdLoadListener {

    /**
     * Notifies when ad is loaded.
     *
     * @param interstitialAd interstitial ad, which is ready to be shown.
     */
    fun onAdLoaded(interstitialAd: InterstitialAd)

    /**
     * Called when an interstitial ad request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdFailedToLoad(error: AdRequestError)
}
