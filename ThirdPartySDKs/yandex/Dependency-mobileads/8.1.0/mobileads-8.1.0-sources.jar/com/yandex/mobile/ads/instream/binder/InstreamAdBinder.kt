package com.yandex.mobile.ads.instream.binder

import android.content.Context
import androidx.annotation.MainThread
import com.monetization.ads.instream.CoreInstreamAdBinder
import com.monetization.ads.instream.InstreamAdBinderEventListener
import com.monetization.ads.instream.binder.UnifiedInstreamAdBinder
import com.monetization.ads.instream.player.content.CoreVideoPlayer
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.instream.InstreamAd
import com.yandex.mobile.ads.instream.InstreamAdListener
import com.yandex.mobile.ads.instream.binder.adapter.YandexInstreamAdListenerAdapter
import com.yandex.mobile.ads.instream.player.ad.InstreamAdPlayer
import com.yandex.mobile.ads.instream.player.ad.InstreamAdView
import com.yandex.mobile.ads.instream.player.ad.adapter.YandexInstreamAdPlayerAdapter
import com.yandex.mobile.ads.instream.player.ad.adapter.YandexInstreamVideoAdAdapterCache
import com.yandex.mobile.ads.instream.player.ad.adapter.YandexVideoPlayerAdapter
import com.yandex.mobile.ads.instream.player.content.VideoPlayer
import com.yandex.mobile.ads.video.playback.VideoAdPlaybackListener
import com.yandex.mobile.ads.video.playback.adapter.YandexVideoAdPlaybackListenerAdapter

/**
 * InstreamAdBinder allows automatic presenting of instream ads
 */
@MainThread
class InstreamAdBinder private constructor(
    context: Context,
    instreamAd: InstreamAd,
    instreamAdPlayer: InstreamAdPlayer?,
    videoPlayer: VideoPlayer
) : UnifiedInstreamAdBinder {

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val videoAdAdapterCache = YandexInstreamVideoAdAdapterCache()
    private val coreInstreamAdPlayer = instreamAdPlayer?.let {
        YandexInstreamAdPlayerAdapter(it, videoAdAdapterCache)
    }
    private val coreInstreamAd = CoreInstreamAdProvider().getInstreamVideoAd(instreamAd)
    private val coreVideoPlayer: CoreVideoPlayer = YandexVideoPlayerAdapter(videoPlayer)
    private val coreInstreamAdBinder = CoreInstreamAdBinder(
        context = context,
        sdkEnvironmentModule = sdkEnvironmentModule,
        instreamAd = coreInstreamAd,
        instreamAdPlayer = coreInstreamAdPlayer,
        videoPlayer = coreVideoPlayer,
    )

    constructor(
        context: Context,
        instreamAd: InstreamAd,
        videoPlayer: VideoPlayer,
        instreamAdPlayer: InstreamAdPlayer
    ) : this(context, instreamAd, instreamAdPlayer, videoPlayer)

    constructor(
        context: Context,
        instreamAd: InstreamAd,
        videoPlayer: VideoPlayer
    ) : this(context, instreamAd, null, videoPlayer)

    /**
     * Starts instream ad playback
     *
     * @param instreamAdView the view in which instream ad breaks will be displayed
     */
    fun bind(instreamAdView: InstreamAdView) {
        coreInstreamAdBinder.bind(instreamAdView, emptyList())
    }

    /**
     * Invalidates video playback. Call this method right before video player is invalidated.
     */
    fun invalidateVideoPlayer() {
        coreInstreamAdBinder.invalidateVideoPlayer()
    }

    /**
     * Invalidates ad playback. Call this method right before ad player is invalidated.
     */
    override fun invalidateAdPlayer() {
        coreInstreamAdBinder.invalidateAdPlayer()
    }

    /**
     * Register a callback for listening InstreamAdBinder.
     *
     * @param listener an [InstreamAdListener] object that handles lifecycle of instream ad.
     */
    fun setInstreamAdListener(listener: InstreamAdListener?) {
        val eventListener: InstreamAdBinderEventListener? = listener?.let { YandexInstreamAdListenerAdapter(it) }
        coreInstreamAdBinder.setInstreamAdListener(eventListener)
    }

    /**
     * Unbinds binder from passed view and pauses ad playback
     */
    fun unbind() {
        coreInstreamAdBinder.unbind()
    }

    /**
     * Prepare preroll (if it exists in ad)
     */
    fun prepareAd() {
        coreInstreamAdBinder.prepareAd()
    }

    /**
     * Sets listener for single video ad creative playback events.
     *
     * @param listener A [VideoAdPlaybackListener] that will be triggered on video events.
     */
    fun setVideoAdPlaybackListener(listener: VideoAdPlaybackListener?) {
        val creativeListener = listener?.let { YandexVideoAdPlaybackListenerAdapter(it, videoAdAdapterCache) }
        coreInstreamAdBinder.setAdCreativePlaybackListener(creativeListener)
    }
}
