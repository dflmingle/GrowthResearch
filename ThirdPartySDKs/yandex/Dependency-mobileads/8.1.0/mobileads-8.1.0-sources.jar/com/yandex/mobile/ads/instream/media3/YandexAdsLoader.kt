package com.yandex.mobile.ads.instream.media3

import android.content.Context
import android.view.ViewGroup
import androidx.annotation.MainThread
import androidx.media3.common.AdViewProvider
import androidx.media3.common.Player
import androidx.media3.datasource.DataSpec
import androidx.media3.exoplayer.source.ads.AdsLoader
import androidx.media3.exoplayer.source.ads.AdsMediaSource
import com.monetization.ads.instream.media3.InstreamAdsLoaderManager
import com.monetization.ads.instream.media3.creator.AdsLoaderManagerCreator
import com.monetization.ads.video.loader.VideoLoaderType
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.instream.InstreamAdRequest
import com.yandex.mobile.ads.instream.adapter.load.YandexInstreamAdRequestAdapter
import com.yandex.mobile.ads.instream.player.ad.adapter.YandexInstreamVideoAdAdapterCache
import com.yandex.mobile.ads.instream.player.ad.adapter.YandexVideoAdCreativeUiElementsProvider
import com.yandex.mobile.ads.video.playback.VideoAdPlaybackListener
import com.yandex.mobile.ads.video.playback.adapter.YandexVideoAdPlaybackListenerAdapter
import com.yandex.mobile.ads.video.playback.view.InstreamAdViewBinderProvider
import java.io.IOException

/**
 * This class is implementation of Media3 ExoPlayer's AdsLoader interface. It can be used for
 * simplified integration of Yandex Instream Ads to Exoplayer. Note that all methods of this
 * class must be called on main thread.
 */
@MainThread
class YandexAdsLoader(
    context: Context,
    requestConfiguration: InstreamAdRequest
) : PrivateYandexAdsLoader() {

    private val vmapRequestConfig =
        YandexInstreamAdRequestAdapter(requestConfiguration, VideoLoaderType.EXO)
    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val managerCreator = AdsLoaderManagerCreator(context, sdkEnvironmentModule, vmapRequestConfig)
    private val instreamAdsLoaderManager = managerCreator.createManager()
    private val instreamVideoAdAdapterCache = YandexInstreamVideoAdAdapterCache()

    /**
     * Requests ads, if they have not already been requested.
     * Ads will be requested automatically when the player is prepared if this method has not been
     * called, so it is only necessary to call this method if you want to request ads before preparing
     * the player.
     *
     * @param adViewGroup A [ViewGroup] on top of the player that will show any ad UI.
     */
    fun requestAds(adViewGroup: ViewGroup?) {
        instreamAdsLoaderManager.loadAd(adViewGroup, emptyList())
    }

    /**
     * Sets listener for single video ad creative playback events.
     *
     * @param listener A [VideoAdPlaybackListener] that will be triggered on video events.
     */
    fun setVideoAdPlaybackListener(listener: VideoAdPlaybackListener?) {
        val coreListener =
            listener?.let { YandexVideoAdPlaybackListenerAdapter(it, instreamVideoAdAdapterCache) }
        instreamAdsLoaderManager.setAdCreativePlaybackListener(coreListener)
    }

    override fun privateSetViewBinderProvider(viewBinderProvider: InstreamAdViewBinderProvider?) {
        val coreAssetsBinderProvider = viewBinderProvider?.let { YandexVideoAdCreativeUiElementsProvider(it) }
        instreamAdsLoaderManager.setAdUiElementsProvider(coreAssetsBinderProvider)
    }

    override fun setPlayer(player: Player?) {
        instreamAdsLoaderManager.setPlayer(player)
    }

    override fun release() {
        instreamAdsLoaderManager.release()
    }

    override fun setSupportedContentTypes(vararg contentTypes: Int) {
        // do nothing (we don't support types setting)
    }

    override fun start(
        adsMediaSource: AdsMediaSource,
        adTagDataSpec: DataSpec,
        adPlaybackId: Any,
        adViewProvider: AdViewProvider,
        eventListener: AdsLoader.EventListener
    ) {
        instreamAdsLoaderManager.start(eventListener, adViewProvider, adPlaybackId)
    }

    override fun stop(adsMediaSource: AdsMediaSource, eventListener: AdsLoader.EventListener) {
        instreamAdsLoaderManager.stop()
    }

    override fun handlePrepareComplete(adsMediaSource: AdsMediaSource, adGroupIndex: Int, adIndexInAdGroup: Int) {
        instreamAdsLoaderManager.handlePrepareComplete(adGroupIndex, adIndexInAdGroup)
    }

    override fun handlePrepareError(
        adsMediaSource: AdsMediaSource,
        adGroupIndex: Int,
        adIndexInAdGroup: Int,
        exception: IOException
    ) {
        instreamAdsLoaderManager.handlePrepareError(adGroupIndex, adIndexInAdGroup, exception)
    }

    override fun getInstreamAdsLoaderManager(): InstreamAdsLoaderManager {
        return instreamAdsLoaderManager
    }

    @Suppress("ClassNaming")
    companion object a {

        const val AD_TAG_URI = "yandex://ad_tag"
    }
}
