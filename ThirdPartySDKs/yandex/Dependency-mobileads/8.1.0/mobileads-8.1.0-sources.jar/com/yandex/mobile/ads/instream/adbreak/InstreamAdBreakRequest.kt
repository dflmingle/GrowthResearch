package com.yandex.mobile.ads.instream.adbreak

/**
 * Class defines configuration for [InstreamAdBreakLoader].
 */
class InstreamAdBreakRequest private constructor(
    val pageId: String,
    val impId: String,
    val parameters: Map<String, String>?
) {

    /**
     * Builder for creating new [InstreamAdBreakRequest] object.
     */
    class Builder(private val pageId: String, private val impId: String) {

        private var parameters: Map<String, String>? = null

        /**
         * Constructs a [InstreamAdBreakRequest] with specified configurations.
         *
         * @return [InstreamAdBreakRequest].
         */
        fun build(): InstreamAdBreakRequest {
            return InstreamAdBreakRequest(
                pageId = pageId,
                impId = impId,
                parameters = parameters
            )
        }

        /**
         * Sets custom request parameters.
         *
         * @param parameters custom parameters.
         * @return [Builder] with custom parameters.
         */
        fun setParameters(parameters: Map<String, String>): Builder {
            this.parameters = parameters
            return this
        }
    }
}
