package com.yandex.mobile.ads.appopenad

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdError
import com.yandex.mobile.ads.common.ImpressionData

/**
 * A listener for receiving notifications during the lifecycle of an app open ad.
 */
@MainThread
interface AppOpenAdEventListener {

    /**
     * Called when an app open ad has been shown.
     */
    fun onAdShown()

    /**
     * Called when an app open ad failed to show.
     */
    fun onAdFailedToShow(adError: AdError)

    /**
     * Called when an app open ad has been dismissed.
     */
    fun onAdDismissed()

    /**
     * Called when user clicked on the ad.
     */
    fun onAdClicked()

    /**
     * Called when an impression was observed
     *
     * @param impressionData - impression level revenue data
     */
    fun onAdImpression(impressionData: ImpressionData?)
}
