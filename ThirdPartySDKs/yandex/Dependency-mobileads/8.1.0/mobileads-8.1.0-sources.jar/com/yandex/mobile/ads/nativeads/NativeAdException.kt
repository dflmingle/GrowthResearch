package com.yandex.mobile.ads.nativeads

/**
 * This exception is thrown when for some reason was unable to parse the native ad response.
 */
class NativeAdException
/**
 * Constructs a new `NativeAdException` with the current stack trace and the
 * specified detail message.
 *
 * @param detailMessage the detail message for this exception.
 */
internal constructor(detailMessage: String, exception: Throwable) : Exception(detailMessage, exception)
