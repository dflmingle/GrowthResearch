package com.yandex.mobile.ads.video.playback.model

/**
 * This class provides data about video ad skip information
 */
interface SkipInfo {

    /**
     * Returns the number of milliseconds of ad creative playback before the it becomes skippable
     *
     * @return Number of milliseconds of ad video playback before the it becomes skippable
     * or ad break duration if it's not skippable
     */
    val skipOffset: Long
}
