package com.yandex.mobile.ads.nativeads

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * Interface that is implemented to determine when the loading of native advertising has completed or failed.
 */
@MainThread
interface NativeAdLoadListener {

    /**
     * Notifies when native ad is loaded.
     *
     * @param nativeAd Native ad, which is ready to be bound to view.
     */
    fun onAdLoaded(nativeAd: NativeAd)

    /**
     * Called when a native ad request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdFailedToLoad(error: AdRequestError)
}
