package com.yandex.mobile.ads.nativeads

import android.content.Context
import android.util.AttributeSet

/**
 * MediaView displays native ad media content such as image or video.
 */
class MediaView : PrivateMediaView {

    constructor(context: Context) : this(context, null)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs, 0)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr)
}
