package com.yandex.mobile.ads.common

import android.content.Context
import com.monetization.ads.base.bidder.SdkBidderTokenLoader
import com.yandex.mobile.ads.common.adapter.YandexBidderTokenLoadListenerAdapter
import com.yandex.mobile.ads.common.converter.YandexBidderTokenRequestConverter
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule

/**
 * Class that creates a bidder token to be used in the mediation.
 * Bidder token is generated asynchronously.
 *
 * @param context The context used for SDK operations.
 */
class BidderTokenLoader(private val context: Context) {

    /**
     * Creates bidder token via request parameters and dispatches results into listener.
     *
     * @param request The request object contains parameters to fetch a bidder token.
     * @param listener Listener to receive result of token generation.
     */
    fun loadBidderToken(
        request: BidderTokenRequest,
        listener: BidderTokenLoadListener
    ) {
        val sdkModule = YandexSdkEnvironmentModule(context)
        val adapter = YandexBidderTokenLoadListenerAdapter(listener)
        val requestData = YandexBidderTokenRequestConverter()
            .convertToBidderTokenRequestData(request)
        SdkBidderTokenLoader(context, sdkModule).loadBidderToken(requestData, adapter)
    }
}
