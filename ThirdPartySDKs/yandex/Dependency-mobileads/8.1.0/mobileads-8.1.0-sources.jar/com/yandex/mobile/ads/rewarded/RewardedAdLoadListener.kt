package com.yandex.mobile.ads.rewarded

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * A listener for receiving notifications during the lifecycle of an rewarded ad.
 */
@MainThread
interface RewardedAdLoadListener {

    /**
     * Notifies when ad is loaded.
     *
     * @param rewarded rewarded ad, which is ready to be shown.
     */
    fun onAdLoaded(rewarded: RewardedAd)

    /**
     * Called when an rewarded ad request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdFailedToLoad(error: AdRequestError)
}
