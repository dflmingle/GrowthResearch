package com.yandex.mobile.ads.banner

import android.content.Context
import android.util.AttributeSet
import androidx.annotation.MainThread
import com.monetization.ads.banner.BannerAdListener
import com.monetization.ads.banner.BannerAdLoadController
import com.monetization.ads.banner.InternalAdView
import com.monetization.ads.base.CoreAdType
import com.monetization.ads.base.time.AdLoadingPhasesManager
import com.monetization.ads.core.model.AdConfiguration
import com.monetization.ads.utils.logger.IntegrationLogger.logE
import com.yandex.mobile.ads.banner.BannerAdSizeAdapter.convert
import com.yandex.mobile.ads.banner.YandexBannerAdSizeAdapter.convert
import com.yandex.mobile.ads.banner.adapter.YandexBannerAdEventListenerAdapter
import com.yandex.mobile.ads.common.AdInfo
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.common.VideoController
import com.yandex.mobile.ads.common.converter.YandexAdRequestConverter
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.rewarded.converter.YandexAdInfoConverter

/**
 * The view to display banner ads.
 */
@MainThread
class BannerAdView : InternalAdView {

    private val adRequestConverter = YandexAdRequestConverter()
    private val adInfoConverter: YandexAdInfoConverter = YandexAdInfoConverter()

    /**
     * Returns the [VideoController] that provides playback control for video ads.
     *
     * @return [VideoController].
     */
    val videoController = VideoController(super.videoEventController)

    /**
     * Returns actual size after Ad was loaded [BannerAdEventListener.onAdLoaded]
     * or AdSize from [.setAdSize]
     *
     * @return [BannerAdSize] current value of banner AdSize.
     * null if AdSize wasn't set
     */
    val adSize: BannerAdSize?
        get() {
            return super.bannerAdSize?.let { convert(it) }
        }

    /**
     * Returns information about loaded Ad.
     *
     * @return [AdInfo] information about loaded Ad.
     */
    val adInfo: AdInfo
        get() {
            val coreAdInfo = super.getCoreAdInfo()
            return adInfoConverter.convertToAdInfo(coreAdInfo)
        }

    /**
     * Constructs a new [BannerAdView] programmatically.
     *
     * @property context The activity context the view is running in, through which it can
     * access the current theme, resources, etc. In particular, it
     * uses the window manager and theme in this context to present its UI.
     */
    constructor(context: Context) : this(context, null)

    /**
     * Constructs a new [BannerAdView] from `XML` layout file.
     *
     * @property context The Context the view is running in, through which it can
     * access the current theme, resources, etc.
     * @property attrs   The attributes of the XML tag that is inflating the view.
     */
    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)

    /**
     * Constructs a new [BannerAdView] from `XML` layout file.
     *
     * @property context      The Context the view is running in, through which it can
     * access the current theme, resources, etc.
     * @property attrs        The attributes of the XML tag that is inflating the view.
     * @property defStyleAttr An attribute in the current theme that contains a
     * reference to a style resource that supplies default values for
     * the view. Can be 0 to not look for defaults.
     */
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) :
        super(
            context = context,
            attrs = attrs,
            defStyle = defStyleAttr,
            adConfiguration = AdConfiguration(CoreAdType.BANNER),
            sdkEnvironmentModule = YandexSdkEnvironmentModule(context),
        )

    /**
     * Starts loading the ad on a background thread.
     * `NOTE: ` The ad size must be set before calling this method.
     *
     * @param adRequest [AdRequest] with targeting information.
     */
    fun loadAd(adRequest: AdRequest) {
        if (adRequest.adUnitId.isNotEmpty()) {
            val adRequestData = adRequestConverter.convertToAdRequestData(adRequest)
            super.loadAd(adRequestData)
        } else {
            logE("Failed to load ad with empty ad unit id")
        }
    }

    /**
     * Sets an [BannerAdEventListener].
     *
     * @param bannerAdEventListener [BannerAdEventListener].
     */
    fun setBannerAdEventListener(bannerAdEventListener: BannerAdEventListener?) {
        val eventListenerAdapter = bannerAdEventListener?.let {
            YandexBannerAdEventListenerAdapter(bannerAdEventListener)
        }
        super.setBannerAdEventListener(eventListenerAdapter)
    }

    /**
     * Sets an [BannerAdSize]. [BannerAdSize] can be set only once.
     *
     * @param adSize [BannerAdSize].
     */
    fun setAdSize(adSize: BannerAdSize) {
        super.bannerAdSize = convert(adSize)
    }

    /**
     * Destroys this [BannerAdView] entirely and cleans up resources.
     * `NOTE: ` Don't work with this [BannerAdView] thereafter.
     */
    public override fun destroy() {
        super.destroy()
    }

    override fun createViewController(
        context: Context,
        adConfiguration: AdConfiguration,
        bannerAdListener: BannerAdListener,
        phasesManager: AdLoadingPhasesManager
    ): BannerAdLoadController {
        return BannerAdLoadController(context, adConfiguration, this, bannerAdListener, phasesManager)
    }
}
