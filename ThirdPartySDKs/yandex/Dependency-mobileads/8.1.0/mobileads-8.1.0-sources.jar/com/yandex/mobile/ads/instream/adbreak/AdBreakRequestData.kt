package com.yandex.mobile.ads.instream.adbreak

interface AdBreakRequestData : PrivateAdBreakRequestData {

    /**
     * Provides page id
     *
     * @return page id
     */
    val pageId: String?

    /**
     * Provides imp id
     *
     * @return imp id
     */
    val impId: String?
}
