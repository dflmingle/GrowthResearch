package com.yandex.mobile.ads.instream

/**
 * Class containing errors that can occur during an ad request.
 *
 * @property description An error description
 */
class InstreamAdRequestError(
    val description: String
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as InstreamAdRequestError

        return description == other.description
    }

    override fun hashCode(): Int {
        return description.hashCode()
    }

    override fun toString(): String {
        return "InstreamAdRequestError(description='$description')"
    }
}
