package com.yandex.mobile.ads.instream

import androidx.annotation.MainThread

/**
 * This interface is used to notify about events occuring during instream ad break playback.
 */
@MainThread
interface InstreamAdBreakEventListener {

    /**
     * Notifies that ad break is prepared.
     */
    fun onInstreamAdBreakPrepared()

    /**
     * Notifies that ad break is started.
     */
    fun onInstreamAdBreakStarted()

    /**
     * Notifies about completion of instream ad break playback.
     */
    fun onInstreamAdBreakCompleted()

    /**
     * Notifies about error occured during instream ad break playback.
     *
     * @param reason Describes error
     */
    fun onInstreamAdBreakError(reason: String)
}
