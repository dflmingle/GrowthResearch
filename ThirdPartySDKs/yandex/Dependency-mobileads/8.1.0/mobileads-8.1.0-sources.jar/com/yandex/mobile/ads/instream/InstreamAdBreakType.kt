package com.yandex.mobile.ads.instream

object InstreamAdBreakType {

    const val INROLL = "inroll"

    const val MIDROLL = "midroll"

    const val PAUSEROLL = "pauseroll"

    const val POSTROLL = "postroll"

    const val PREROLL = "preroll"
}
