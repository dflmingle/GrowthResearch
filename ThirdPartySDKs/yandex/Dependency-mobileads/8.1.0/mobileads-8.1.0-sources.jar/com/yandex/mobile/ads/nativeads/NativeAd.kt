package com.yandex.mobile.ads.nativeads

import androidx.annotation.CheckResult
import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdBindingResult
import com.yandex.mobile.ads.common.AdInfo

/**
 * Interface allows to set [NativeAdEventListener] and
 * to define whether web links are opened by in-app browser or by third-party browsers.
 */
@MainThread
interface NativeAd {

    /**
     * Returns ad assets.
     *
     * @return Ad assets.
     */
    val adAssets: NativeAdAssets

    /**
     * Returns native ad type [NativeAdType].
     *
     * @return Native ad type.
     */
    val adType: NativeAdType

    /**
     * @return Returns information [AdInfo] about loaded Ad.
     *
     * @return information about loaded Ad.
     */
    val adInfo: AdInfo

    /**
     * Bind view with native ad's content.
     *
     * Returns [AdBindingResult.Success] if binding was successful, or
     * [AdBindingResult.Failure] if binding failed (e.g., a required asset view is missing).
     *
     * @param viewBinder An [NativeAdViewBinder] object.
     * @return [AdBindingResult] indicating success or failure.
     */
    @CheckResult
    fun bindNativeAd(viewBinder: NativeAdViewBinder): AdBindingResult

    /**
     * Sets an [NativeAdEventListener].
     *
     * @param eventListener [NativeAdEventListener].
     */
    fun setNativeAdEventListener(eventListener: NativeAdEventListener?)

    /**
     * Asynchronously loads ad's images. Every loaded image is set to corresponding ImageView.
     * Images are not persisted in memory and should be loaded each time ad is being bound.
     */
    fun loadImages()

    /**
     * Adds listener for receiving notifications about images loading progress.
     *
     * @param listener Image loading listener.
     */
    fun addImageLoadingListener(listener: NativeAdImageLoadingListener)

    /**
     * Removes listener, so it's no longer notified about images loading progress.
     *
     * @param listener Image loading listener.
     */
    fun removeImageLoadingListener(listener: NativeAdImageLoadingListener)
}
