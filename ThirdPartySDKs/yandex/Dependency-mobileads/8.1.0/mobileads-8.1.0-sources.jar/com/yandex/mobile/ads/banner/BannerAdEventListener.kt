package com.yandex.mobile.ads.banner

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError
import com.yandex.mobile.ads.common.ImpressionData

/**
 * A listener for receiving notifications during the lifecycle of an ad.
 */
@MainThread
interface BannerAdEventListener {
    /**
     * Called when an ad is received.
     */
    fun onAdLoaded()

    /**
     * Called when an banner ad request failed
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdFailedToLoad(error: AdRequestError)

    /**
     * Called when user clicked on the ad.
     */
    fun onAdClicked()

    /**
     * Called when an impression was observed
     *
     * @param impressionData - impression level revenue data
     */
    fun onImpression(impressionData: ImpressionData?)
}
