package com.yandex.mobile.ads.common

import android.location.Location

/**
 * Contains targeting information used for ad requests.
 *
 * Use the constructor directly from Kotlin:
 * ```kotlin
 * val targeting = AdTargeting(age = "25", gender = Gender.MALE)
 * ```
 *
 * Use [Builder] from Java:
 * ```java
 * AdTargeting targeting = new AdTargeting.Builder()
 *     .setAge("25")
 *     .setGender(Gender.MALE)
 *     .build();
 * ```
 *
 * @property age User's age
 * @property gender User's gender
 * @property location User's location for targeting process
 * @property contextQuery User's query entered inside the app
 * @property contextTags Tags describing current user context inside the app
 */
class AdTargeting(
    val age: String? = null,
    val gender: String? = null,
    val location: Location? = null,
    val contextQuery: String? = null,
    val contextTags: List<String>? = null
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || javaClass != other.javaClass) return false
        val that = other as AdTargeting
        if (age != that.age) return false
        if (gender != that.gender) return false
        if (location != that.location) return false
        if (contextQuery != that.contextQuery) return false
        return contextTags == that.contextTags
    }

    override fun hashCode(): Int {
        var result = age?.hashCode() ?: 0
        result = 31 * result + (gender?.hashCode() ?: 0)
        result = 31 * result + (location?.hashCode() ?: 0)
        result = 31 * result + (contextQuery?.hashCode() ?: 0)
        result = 31 * result + (contextTags?.hashCode() ?: 0)
        return result
    }

    /**
     * Builds an [AdTargeting].
     */
    class Builder {

        private var age: String? = null
        private var gender: String? = null
        private var location: Location? = null
        private var contextQuery: String? = null
        private var contextTags: List<String>? = null

        /**
         * Constructs an [AdTargeting] with the specified attributes.
         *
         * @return [AdTargeting].
         */
        fun build(): AdTargeting {
            return AdTargeting(
                age = age,
                gender = gender,
                location = location,
                contextQuery = contextQuery,
                contextTags = contextTags
            )
        }

        /**
         * Sets current user age entered inside the app. Used for targeting.
         *
         * @param age for targeting process.
         * @return Builder with user age.
         */
        fun setAge(age: String?): Builder {
            this.age = age
            return this
        }

        /**
         * Sets user gender entered inside the app. Used for targeting.
         *
         * @param gender for targeting process.
         * @return Builder with user gender.
         */
        fun setGender(gender: String?): Builder {
            this.gender = gender
            return this
        }

        /**
         * Sets the user's location for targeting process.
         *
         * @param location for targeting process.
         * @return Builder with user's location.
         */
        fun setLocation(location: Location?): Builder {
            this.location = location
            return this
        }

        /**
         * Sets current user query entered inside the app. Used for targeting.
         *
         * @param contextQuery for targeting process.
         * @return Builder with user query.
         */
        fun setContextQuery(contextQuery: String?): Builder {
            this.contextQuery = contextQuery
            return this
        }

        /**
         * Sets tags describing current user context inside the app. Used for targeting.
         *
         * @param contextTags for targeting process.
         * @return Builder with user tags.
         */
        fun setContextTags(contextTags: List<String>?): Builder {
            this.contextTags = contextTags
            return this
        }
    }
}
