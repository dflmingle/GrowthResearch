package com.yandex.mobile.ads.nativeads

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.monetization.ads.common.AssetViews
import com.monetization.ads.nativeads.parser.json.AssetName

/**
 * NativeAdViewBinder allows bind native ad view [View] with native ad&#39;s content.
 * It contains view for all of native ad assets.
 * Views for all of the required assets should be set,
 * although ad may not contain age restrictions, icon, warning or call to action.
 * If any of the required views is not provided for ad which contains corresponding assets, binding fails.
 * Optional views may be provided to increase CTR.
 */
class NativeAdViewBinder private constructor(
    val nativeAdView: View,
    override val assetViews: Map<String, View?>
) : AssetViews {

    override val ageView: TextView?
        get() = assetViews[AssetName.ASSET_AGE] as? TextView

    override val bodyView: TextView?
        get() = assetViews[AssetName.ASSET_BODY] as? TextView

    override val callToActionView: TextView?
        get() = assetViews[AssetName.ASSET_CALL_TO_ACTION] as? TextView

    override val domainView: TextView?
        get() = assetViews[AssetName.ASSET_DOMAIN] as? TextView

    override val faviconView: ImageView?
        get() = assetViews[AssetName.ASSET_FAVICON] as? ImageView

    override val feedbackView: ImageView?
        get() = assetViews[AssetName.ASSET_FEEDBACK] as? ImageView

    override val iconView: ImageView?
        get() = assetViews[AssetName.ASSET_ICON] as? ImageView

    override val mediaView: MediaView?
        get() = assetViews[AssetName.ASSET_MEDIA] as? MediaView

    override val priceView: TextView?
        get() = assetViews[AssetName.ASSET_PRICE] as? TextView

    override val ratingView: View?
        get() = assetViews[AssetName.ASSET_RATING]

    override val reviewCountView: TextView?
        get() = assetViews[AssetName.ASSET_REVIEW_COUNT] as? TextView

    override val sponsoredView: TextView?
        get() = assetViews[AssetName.ASSET_SPONSORED] as? TextView

    override val titleView: TextView?
        get() = assetViews[AssetName.ASSET_TITLE] as? TextView

    override val warningView: TextView?
        get() = assetViews[AssetName.ASSET_WARNING] as? TextView

    /**
     * Builds a [NativeAdViewBinder].
     */
    class Builder
    @Deprecated("Use constructor with passing [NativeAdView] type")
    constructor(
        private val nativeAdView: View
    ) {

        private val assetViews = mutableMapOf<String, View?>()

        /**
         * Creates a new [Builder]
         * for constructing a [NativeAdViewBinder]
         *
         * @param nativeAdView View represents view for native ad.
         */
        constructor(nativeAdView: NativeAdView) : this(nativeAdView as View)

        /**
         * Constructs a [NativeAdViewBinder] contains views for all of native ad assets.
         *
         * @return [NativeAdViewBinder].
         */
        fun build(): NativeAdViewBinder {
            return NativeAdViewBinder(nativeAdView, assetViews)
        }

        /**
         * Sets view for age.
         *
         * @param ageView TextView for native ad age.
         * @return [Builder] contains views for native ad assets.
         */
        fun setAgeView(ageView: TextView?): Builder {
            setAssetView(AssetName.ASSET_AGE, ageView)
            return this
        }

        /**
         * Sets view for body.
         *
         * @param bodyView TextView for native ad body.
         * @return [Builder] contains views for native ad assets.
         */
        fun setBodyView(bodyView: TextView?): Builder {
            setAssetView(AssetName.ASSET_BODY, bodyView)
            return this
        }

        /**
         * Sets TextView for call to action
         *
         * @param callToActionView TextView for call to action.
         * @return [Builder] contains views for native ad assets.
         */
        fun setCallToActionView(callToActionView: TextView?): Builder {
            setAssetView(AssetName.ASSET_CALL_TO_ACTION, callToActionView)
            return this
        }

        /**
         * Sets view for domain.
         *
         * @param domainView TextView for native ad domain.
         * @return [Builder] contains views for native ad assets.
         */
        fun setDomainView(domainView: TextView?): Builder {
            setAssetView(AssetName.ASSET_DOMAIN, domainView)
            return this
        }

        /**
         * Sets view for app favicon.
         *
         * @param faviconView ImageView for app favicon.
         * @return [Builder] contains views for native ad assets.
         */
        fun setFaviconView(faviconView: ImageView?): Builder {
            setAssetView(AssetName.ASSET_FAVICON, faviconView)
            return this
        }

        /**
         * Sets view for feedback.
         *
         * @param feedbackView ImageView for feedback.
         * @return [Builder] contains views for native ad assets.
         */
        fun setFeedbackView(feedbackView: ImageView?): Builder {
            setAssetView(AssetName.ASSET_FEEDBACK, feedbackView)
            return this
        }

        /**
         * Sets view for app icon.
         *
         * @param iconView ImageView for app icon.
         * @return [Builder] contains views for native ad assets.
         */
        fun setIconView(iconView: ImageView?): Builder {
            setAssetView(AssetName.ASSET_ICON, iconView)
            return this
        }

        /**
         * Sets view for media content.
         *
         * @param mediaView MediaView for media content.
         */
        fun setMediaView(mediaView: MediaView?): Builder {
            setAssetView(AssetName.ASSET_MEDIA, mediaView)
            return this
        }

        /**
         * Sets view for app price.
         *
         * @param priceView TextView for app price.
         * @return [Builder] contains views for native ad assets.
         */
        fun setPriceView(priceView: TextView?): Builder {
            setAssetView(AssetName.ASSET_PRICE, priceView)
            return this
        }

        /**
         * Sets view for app star rating.
         *
         * @param ratingView View implements [Rating] for app star rating.
         * @return [Builder] contains views for native ad assets.
         */
        fun <T> setRatingView(ratingView: T?): Builder where T : View, T : Rating {
            setAssetView(AssetName.ASSET_RATING, ratingView)
            return this
        }

        /**
         * Sets view for number of app reviews.
         *
         * @param reviewCountView TextView for number of app reviews.
         * @return [Builder] contains views for native ad assets.
         */
        fun setReviewCountView(reviewCountView: TextView?): Builder {
            setAssetView(AssetName.ASSET_REVIEW_COUNT, reviewCountView)
            return this
        }

        /**
         * Sets view for sponsored by
         *
         * @param sponsoredView TextView for sponsored by.
         * @return [Builder] contains views for native ad assets.
         */
        fun setSponsoredView(sponsoredView: TextView?): Builder {
            setAssetView(AssetName.ASSET_SPONSORED, sponsoredView)
            return this
        }

        /**
         * Sets view for title.
         *
         * @param titleView TextView for native ad title.
         * @return [Builder] contains views for native ad assets.
         */
        fun setTitleView(titleView: TextView?): Builder {
            setAssetView(AssetName.ASSET_TITLE, titleView)
            return this
        }

        /**
         * Sets view for warning.
         *
         * @param warningView TextView for native ad warning.
         * @return [Builder] contains views for native ad assets.
         */
        fun setWarningView(warningView: TextView?): Builder {
            setAssetView(AssetName.ASSET_WARNING, warningView)
            return this
        }

        private fun setAssetView(assetName: String, view: View?) = apply { assetViews[assetName] = view }
    }
}
