package com.yandex.mobile.ads.interstitial

import android.content.Context
import androidx.annotation.MainThread
import com.monetization.ads.interstitial.CoreInterstitialAdLoader
import com.monetization.ads.utils.api.ApiExternal
import com.monetization.ads.utils.api.ApiInternal
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.common.YandexAdRequestConfigurationConverter
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.interstitial.adapter.YandexInterstitialAdLoadListenerAdapter
import com.yandex.mobile.ads.interstitial.converter.InterstitialAdLoadResultConverter

/**
 * Full-screen interstitial ads.
 *
 * @param context The context through which can be accessible
 * the current theme, resources, etc. In particular, it
 * uses the window manager and theme in this context to present its UI.
 */
@MainThread
class InterstitialAdLoader @ApiExternal constructor(context: Context) {

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val adRequestConfigurationConverter = YandexAdRequestConfigurationConverter()
    private val coreInterstitialAdLoader = CoreInterstitialAdLoader(context, sdkEnvironmentModule)
    private val adLoadResultConverter = InterstitialAdLoadResultConverter()

    /**
     * Starts loading the ad on a background thread.
     *
     * @param adRequest Data for targeting and ad configuration.
     * @param listener [InterstitialAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(adRequest: AdRequest, listener: InterstitialAdLoadListener) {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adRequest)
        val coreListener = YandexInterstitialAdLoadListenerAdapter(listener)
        coreInterstitialAdLoader.loadAd(coreAdRequestData, coreListener)
    }

    /**
     * Starts loading the ad on a background thread. Suspends until the result is available.
     *
     * @param adRequest Data for targeting and ad configuration.
     * @return [InterstitialAdLoadResult.Success] with [InterstitialAd] or [InterstitialAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(adRequest: AdRequest): InterstitialAdLoadResult {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adRequest)
        val coreAdLoadResult = coreInterstitialAdLoader.loadAd(coreAdRequestData)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Starts loading the ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param listener [InterstitialAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(adUnitId: String, readyResponse: String, listener: InterstitialAdLoadListener) {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adUnitId, readyResponse)
        val coreListener = YandexInterstitialAdLoadListenerAdapter(listener)
        coreInterstitialAdLoader.loadAd(coreAdRequestData, coreListener)
    }

    /**
     * Starts loading the ad on a background thread with ready response. Suspends until the result is available.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @return [InterstitialAdLoadResult.Success] with [InterstitialAd] or [InterstitialAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(adUnitId: String, readyResponse: String): InterstitialAdLoadResult {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adUnitId, readyResponse)
        val coreAdLoadResult = coreInterstitialAdLoader.loadAd(coreAdRequestData)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel active loading of the interstitial ads.
     */
    @ApiExternal
    fun cancelLoading() {
        coreInterstitialAdLoader.cancelLoading()
    }
}
