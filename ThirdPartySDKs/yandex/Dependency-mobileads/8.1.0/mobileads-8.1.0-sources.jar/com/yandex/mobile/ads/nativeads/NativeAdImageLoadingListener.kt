package com.yandex.mobile.ads.nativeads

import androidx.annotation.MainThread

/**
 * A listener for receiving notifications about images loading progress.
 */
@MainThread
interface NativeAdImageLoadingListener {

    /**
     * Notifies when ad finishes loading images.
     */
    fun onFinishLoadingImages()
}
