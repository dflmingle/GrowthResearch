package com.yandex.mobile.ads.instream

import androidx.annotation.MainThread
import com.monetization.ads.instream.state.InstreamSettings

@MainThread
object YandexInstreamAds {

    /**
     * A boolean value indicating whether ad group preloading is enabled.
     *
     * @param enabled If set to `true`, preloading in ad group will be enabled.
     * Default param is `false`.
     */
    @JvmStatic
    fun setAdGroupPreloading(enabled: Boolean) {
        val settings = InstreamSettings.getInstance()
        settings.isAdGroupPreloading = enabled
    }
}
