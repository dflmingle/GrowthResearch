package com.yandex.mobile.ads.instream.player.content

import androidx.annotation.MainThread

/**
 * This interface is used to control content playback while playing ads
 */
@MainThread
interface VideoPlayer {

    /**
     * Gets current content video volume with 0 being silence and 1 being maximum volume level
     *
     * @return volume level in range [0.0, 1.0]
     */
    val volume: Float

    /**
     * Gets current content video position
     *
     * @return current content video position in millis
     */
    val videoPosition: Long

    /**
     * Gets content video duration
     *
     * @return content video duration
     */
    val videoDuration: Long

    /**
     * Prepares content video
     */
    fun prepareVideo()

    /**
     * Pauses playing content video
     */
    fun pauseVideo()

    /**
     * Resumes playing content video
     */
    fun resumeVideo()

    /**
     * Sets listener for content player events. For each event of the content video player,
     * the corresponding callback must be called on this object.
     *
     * @param listener Listener for content player events
     */
    fun setVideoPlayerListener(listener: VideoPlayerListener?)
}
