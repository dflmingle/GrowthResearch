package com.yandex.mobile.ads.common

import com.yandex.mobile.ads.banner.BannerAdSize

/**
 * Configuration for requesting a bidder token.
 *
 * Use factory methods in companion object to create instances:
 * - [banner] for banner ads
 * - [interstitial] for interstitial ads
 * - [rewarded] for rewarded ads
 * - [native] for native ads
 * - [appOpenAd] for app open ads
 *
 * @property adType Type of the ad.
 * @property bannerAdSize Size of the banner ad (only for banner type).
 * @property targeting Targeting information for the request.
 * @property parameters Additional custom parameters for the request.
 */
class BidderTokenRequest internal constructor(
    val adType: AdType,
    val bannerAdSize: BannerAdSize? = null,
    val targeting: AdTargeting? = null,
    val parameters: Map<String, String> = emptyMap()
) {

    init {
        require(adType != AdType.BANNER || bannerAdSize != null) {
            "bannerAdSize is required for Banner configuration"
        }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || javaClass != other.javaClass) return false
        val that = other as BidderTokenRequest
        if (adType != that.adType) return false
        if (bannerAdSize != that.bannerAdSize) return false
        if (targeting != that.targeting) return false
        if (parameters != that.parameters) return false
        return true
    }

    override fun hashCode(): Int {
        var result = adType.hashCode()
        result = 31 * result + (bannerAdSize?.hashCode() ?: 0)
        result = 31 * result + (targeting?.hashCode() ?: 0)
        result = 31 * result + parameters.hashCode()
        return result
    }

    @Suppress("ClassNaming")
    companion object a {

        /**
         * Creates a banner ad configuration.
         *
         * @param bannerAdSize Size of the banner ad.
         * @param targeting Targeting information for the request.
         * @param parameters Additional custom parameters.
         * @return Configuration for banner ad bidder token request.
         */
        @JvmStatic
        @JvmOverloads
        fun banner(
            bannerAdSize: BannerAdSize,
            targeting: AdTargeting? = null,
            parameters: Map<String, String> = emptyMap()
        ): BidderTokenRequest = BidderTokenRequest(
            adType = AdType.BANNER,
            bannerAdSize = bannerAdSize,
            targeting = targeting,
            parameters = parameters
        )

        /**
         * Creates an interstitial ad configuration.
         *
         * @param targeting Targeting information for the request.
         * @param parameters Additional custom parameters.
         * @return Configuration for interstitial ad bidder token request.
         */
        @JvmStatic
        @JvmOverloads
        fun interstitial(
            targeting: AdTargeting? = null,
            parameters: Map<String, String> = emptyMap()
        ): BidderTokenRequest = BidderTokenRequest(
            adType = AdType.INTERSTITIAL,
            bannerAdSize = null,
            targeting = targeting,
            parameters = parameters
        )

        /**
         * Creates a rewarded ad configuration.
         *
         * @param targeting Targeting information for the request.
         * @param parameters Additional custom parameters.
         * @return Configuration for rewarded ad bidder token request.
         */
        @JvmStatic
        @JvmOverloads
        fun rewarded(
            targeting: AdTargeting? = null,
            parameters: Map<String, String> = emptyMap()
        ): BidderTokenRequest = BidderTokenRequest(
            adType = AdType.REWARDED,
            bannerAdSize = null,
            targeting = targeting,
            parameters = parameters
        )

        /**
         * Creates a native ad configuration.
         *
         * @param targeting Targeting information for the request.
         * @param parameters Additional custom parameters.
         * @return Configuration for native ad bidder token request.
         */
        @JvmStatic
        @JvmName("nativeAd")
        @JvmOverloads
        fun native(
            targeting: AdTargeting? = null,
            parameters: Map<String, String> = emptyMap()
        ): BidderTokenRequest = BidderTokenRequest(
            adType = AdType.NATIVE,
            bannerAdSize = null,
            targeting = targeting,
            parameters = parameters
        )

        /**
         * Creates an app open ad configuration.
         *
         * @param targeting Targeting information for the request.
         * @param parameters Additional custom parameters.
         * @return Configuration for app open ad bidder token request.
         */
        @JvmStatic
        @JvmOverloads
        fun appOpenAd(
            targeting: AdTargeting? = null,
            parameters: Map<String, String> = emptyMap()
        ): BidderTokenRequest = BidderTokenRequest(
            adType = AdType.APP_OPEN_AD,
            bannerAdSize = null,
            targeting = targeting,
            parameters = parameters
        )
    }
}
