package com.yandex.mobile.ads.instream.player.ad

import com.monetization.ads.utils.api.ApiExternal

@ApiExternal
object InstreamAdMimeTypes {
    const val MP4 = "video/mp4"
    const val WEBM = "video/webm"
    const val DASH = "application/dash+xml"
}
