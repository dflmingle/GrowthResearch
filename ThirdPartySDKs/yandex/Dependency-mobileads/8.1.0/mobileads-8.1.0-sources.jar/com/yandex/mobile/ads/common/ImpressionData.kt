package com.yandex.mobile.ads.common

/**
 * An interface with impression-level revenue data.
 */
interface ImpressionData {

    /**
     * Return a raw impression-level revenue data, string with json.
     */
    val rawData: String
}
