package com.yandex.mobile.ads.common

import androidx.annotation.MainThread

/**
 * Listener to obtain results of bidder token generation
 * from [BidderTokenLoader.loadBidderToken]
 */
interface BidderTokenLoadListener {

    /**
     * Method to receive successfully loaded token.
     *
     * @param bidderToken loaded bidder token.
     */
    @MainThread
    fun onBidderTokenLoaded(bidderToken: String)

    /**
     * Method to receive error during token loading.
     *
     * @param failureReason bidder token loading failure reason.
     */
    @MainThread
    fun onBidderTokenFailedToLoad(failureReason: String)
}
