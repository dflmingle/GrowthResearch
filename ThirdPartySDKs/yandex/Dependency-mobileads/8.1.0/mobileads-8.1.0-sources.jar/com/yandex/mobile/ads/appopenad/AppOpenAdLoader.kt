package com.yandex.mobile.ads.appopenad

import android.content.Context
import androidx.annotation.MainThread
import com.monetization.ads.appopenad.CoreAppOpenAdLoader
import com.monetization.ads.utils.api.ApiExternal
import com.monetization.ads.utils.api.ApiInternal
import com.yandex.mobile.ads.appopenad.adapter.YandexAppOpenAdLoadListenerAdapter
import com.yandex.mobile.ads.appopenad.converter.AppOpenAdLoadResultConverter
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.common.YandexAdRequestConfigurationConverter
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule

/**
 * Full-screen app open ads.
 *
 * @param context The activity context the view is running in, through which it can
 * access the current theme, resources, etc. In particular, it
 * uses the window manager and theme in this context to present its UI.
 */
@MainThread
class AppOpenAdLoader @ApiExternal constructor(context: Context) {

    private val sdkModule = YandexSdkEnvironmentModule(context)
    private val coreAppOpenAdLoader = CoreAppOpenAdLoader(context, sdkModule)
    private val adRequestConfigurationConverter = YandexAdRequestConfigurationConverter()
    private val adLoadResultConverter = AppOpenAdLoadResultConverter()

    /**
     * Starts loading the ad on a background thread.
     *
     * @param adRequest Data for targeting and ad configuration.
     * @param listener [AppOpenAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(adRequest: AdRequest, listener: AppOpenAdLoadListener) {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adRequest)
        val coreListener = YandexAppOpenAdLoadListenerAdapter(listener)
        coreAppOpenAdLoader.loadAd(coreAdRequestData, coreListener)
    }

    /**
     * Starts loading the ad on a background thread. Suspends until the result is available.
     *
     * @param adRequest Data for targeting and ad configuration.
     * @return [AppOpenAdLoadResult.Success] with [AppOpenAd] or [AppOpenAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(adRequest: AdRequest): AppOpenAdLoadResult {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adRequest)
        val coreAdLoadResult = coreAppOpenAdLoader.loadAd(coreAdRequestData)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Starts loading the ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param listener [AppOpenAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(adUnitId: String, readyResponse: String, listener: AppOpenAdLoadListener) {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adUnitId, readyResponse)
        val coreListener = YandexAppOpenAdLoadListenerAdapter(listener)
        coreAppOpenAdLoader.loadAd(coreAdRequestData, coreListener)
    }

    /**
     * Starts loading the ad on a background thread with ready response. Suspends until the result is available.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @return [AppOpenAdLoadResult.Success] with [AppOpenAd] or [AppOpenAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(adUnitId: String, readyResponse: String): AppOpenAdLoadResult {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adUnitId, readyResponse)
        val coreAdLoadResult = coreAppOpenAdLoader.loadAd(coreAdRequestData)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel active loading of the app open ads.
     */
    @ApiExternal
    fun cancelLoading() {
        coreAppOpenAdLoader.cancelLoading()
    }
}
