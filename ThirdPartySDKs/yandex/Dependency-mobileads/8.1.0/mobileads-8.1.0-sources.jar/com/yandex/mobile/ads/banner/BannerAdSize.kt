package com.yandex.mobile.ads.banner

import android.content.Context
import com.monetization.ads.banner.StickyAdSizeProvider
import com.monetization.ads.base.FixedSizeInfo
import com.monetization.ads.base.SizeInfo

/**
 * The size of a banner ad.
 *
 * @property width    The width of the ad in density-independent pixels (dp).
 * @property height   The height of the ad in density-independent pixels (dp).
 */
class BannerAdSize internal constructor(
    private val sizeInfo: SizeInfo
) : PrivateBannerAdSize() {

    /**
     * Returns the height of this [BannerAdSize] in density-independent pixels (dp).
     *
     * @return Height in density-independent pixels (dp).
     */
    val height: Int
        get() = sizeInfo.height

    /**
     * Returns the width of this [BannerAdSize] in density-independent pixels (dp).
     *
     * @return Width in density-independent pixels (dp).
     */
    val width: Int
        get() = sizeInfo.width

    /**
     * Returns the actual height of this [BannerAdSize] in physical pixels.
     * AdSize created with FULL_HEIGHT will return height of the screen.
     *
     * @param context Any [Context].
     * @return Height in physical pixels.
     */
    fun getHeightInPixels(context: Context): Int {
        return sizeInfo.getHeightInPixels(context)
    }

    /**
     * Returns the actual width of this [BannerAdSize] in physical pixels.
     * AdSize created with FULL_WIDTH will return width of the screen.
     *
     * @param context Any [Context].
     * @return Width in physical pixels.
     */
    fun getWidthInPixels(context: Context): Int {
        return sizeInfo.getWidthInPixels(context)
    }

    /**
     * Returns the actual height of this [BannerAdSize] in density-independent pixels (dp).
     * AdSize created with FULL_HEIGHT will return height of the screen.
     *
     * @param context Any [Context].
     * @return Weight in density-independent pixels (dp).
     */
    fun getHeight(context: Context): Int {
        return sizeInfo.getHeight(context)
    }

    /**
     * Returns the actual width of this [BannerAdSize] in density-independent pixels (dp).
     * AdSize created with FULL_WIDTH will return width of the screen.
     *
     * @param context Any [Context].
     * @return Width in density-independent pixels (dp).
     */
    fun getWidth(context: Context): Int {
        return sizeInfo.getWidth(context)
    }

    override fun getPrivateSizeInfo(): SizeInfo {
        return sizeInfo
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) {
            return true
        }
        if (other == null || javaClass != other.javaClass) {
            return false
        }
        val that = other as BannerAdSize
        return sizeInfo == that.sizeInfo
    }

    override fun hashCode(): Int {
        return sizeInfo.hashCode()
    }

    override fun toString(): String {
        return sizeInfo.toString()
    }

    /**
     * @suspress
     */
    @Suppress("ClassNaming")
    companion object a {

        /**
         * Returns fixed banner size.
         *
         * @param context The [Context].
         * @param width  The width of the ad container in density-independent pixels (dp).
         * @param height The height of the ad container in density-independent pixels (dp).
         * @return Fixed banner size.
         *
         * Creates an object of the BannerAdSize class with the specified width and height of the banner.
         * The method is intended for use in Third-Party Mediation.
         * For receiving an adaptive anchor banner located at the top or bottom of the screen use [sticky],
         * for banner in the feed use [inline].
         */
        @JvmStatic
        @Suppress("UnusedPrivateMember")
        fun fixed(context: Context, width: Int, height: Int): BannerAdSize {
            val fixedSizeInfo = FixedSizeInfo(width, height, SizeInfo.SizeType.FIXED)
            return BannerAdSize(fixedSizeInfo)
        }

        /**
         * Returns sticky banner size with the given width.
         *
         * @param context The [Context].
         * @param width The width of the ad container in density-independent pixels (dp).
         * @return Sticky banner AdSize.
         */
        @JvmStatic
        fun sticky(context: Context, width: Int): BannerAdSize {
            val coreBannerAdSize = StickyAdSizeProvider.calculateStickyAdSize(context, width)
            return BannerAdSizeAdapter.convert(coreBannerAdSize)
        }

        /**
         * Returns inline adaptive banner size.
         * Banners with inline sizes stretch to container width and height when possible.
         *
         * @param width  The width of the ad container in density-independent pixels (dp).
         * @param maxHeight The maximum height of the ad container in density-independent pixels (dp).
         * @return Inline banner size.
         */
        @JvmStatic
        @Suppress("unused")
        fun inline(context: Context, width: Int, maxHeight: Int): BannerAdSize {
            val fixedSizeInfo = FixedSizeInfo(width, maxHeight, SizeInfo.SizeType.FLEXIBLE)
            return BannerAdSize(fixedSizeInfo)
        }
    }
}
