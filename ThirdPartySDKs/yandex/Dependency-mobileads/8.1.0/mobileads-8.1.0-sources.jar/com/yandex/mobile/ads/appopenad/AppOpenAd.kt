package com.yandex.mobile.ads.appopenad

import android.app.Activity
import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdInfo

/**
 * Full-screen app open ad.
 */
@MainThread
interface AppOpenAd {

    /**
     * @return [AdInfo] information about loaded Ad.
     */
    val adInfo: AdInfo

    /**
     * Sets an [AppOpenAdEventListener].
     *
     * @param appOpenAdEventListener [AppOpenAdEventListener].
     */
    fun setAdEventListener(appOpenAdEventListener: AppOpenAdEventListener?)

    /**
     * Shows the app open ad. Single app open ad can be showed just once.
     *
     * @param activity [Activity].
     */
    fun show(activity: Activity)
}
