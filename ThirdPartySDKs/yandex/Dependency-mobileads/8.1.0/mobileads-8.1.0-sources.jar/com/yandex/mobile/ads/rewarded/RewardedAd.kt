package com.yandex.mobile.ads.rewarded

import android.app.Activity
import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdInfo

/**
 * Full-screen rewarded ad.
 */
@MainThread
interface RewardedAd {

    /**
     * @return [AdInfo] information about loaded Ad.
     */
    val adInfo: AdInfo

    /**
     * Sets an [RewardedAdEventListener].
     *
     * @param rewardedAdEventListener [RewardedAdEventListener].
     */
    fun setAdEventListener(rewardedAdEventListener: RewardedAdEventListener?)

    /**
     * Shows the rewarded ad. Single rewarded ad can be showed just once.
     *
     * @param activity [Activity].
     */
    fun show(activity: Activity)
}
