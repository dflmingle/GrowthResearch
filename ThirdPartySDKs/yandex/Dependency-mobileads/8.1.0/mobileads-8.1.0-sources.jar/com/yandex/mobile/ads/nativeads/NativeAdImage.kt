package com.yandex.mobile.ads.nativeads

import android.graphics.drawable.Drawable

/**
 * NativeAdImage represents image asset.
 * Height and width is always available. Drawable is unavailable until loaded.
 */
interface NativeAdImage {

    /**
     * Returns drawable.
     *
     * @return drawable.
     */
    val drawable: Drawable?

    /**
     * Returns height of image in physical pixels.
     *
     * @return height in physical pixels.
     */
    val height: Int

    /**
     * Returns width of image in physical pixels.
     *
     * @return width in physical pixels.
     */
    val width: Int
}
