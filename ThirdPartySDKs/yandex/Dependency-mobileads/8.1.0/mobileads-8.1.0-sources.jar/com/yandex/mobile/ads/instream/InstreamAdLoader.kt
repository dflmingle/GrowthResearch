package com.yandex.mobile.ads.instream

import android.content.Context
import androidx.annotation.MainThread
import com.monetization.ads.base.utils.context.applicationContextOrThis
import com.monetization.ads.instream.loader.InstreamAdLoadingController
import com.monetization.ads.video.loader.VideoLoaderType
import com.monetization.ads.video.loader.VmapRequestConfig
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.instream.adapter.load.YandexInstreamAdLoadListenerAdapter
import com.yandex.mobile.ads.instream.adapter.load.YandexInstreamAdRequestAdapter
import com.yandex.mobile.ads.instream.converter.InstreamAdLoadResultConverter

/**
 * This class can be used for loading instream ads
 */
@MainThread
class InstreamAdLoader(context: Context) {

    private val applicationContext = context.applicationContextOrThis

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val adLoadingController = InstreamAdLoadingController(context, sdkEnvironmentModule)
    private val adLoadResultConverter = InstreamAdLoadResultConverter(applicationContext)

    /**
     * Loads instream ad object.
     *
     * @param configuration Request configuration
     * @param listener [InstreamAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    fun loadAd(
        configuration: InstreamAdRequest,
        listener: InstreamAdLoadListener,
    ) {
        val requestConfig: VmapRequestConfig =
            YandexInstreamAdRequestAdapter(configuration, VideoLoaderType.INSTREAM_AD)
        val coreListener = YandexInstreamAdLoadListenerAdapter(applicationContext, listener)
        adLoadingController.loadInstreamAd(requestConfig, coreListener)
    }

    /**
     * Loads instream ad object. Suspends until the result is available.
     *
     * @param configuration Request configuration
     * @return [InstreamAdLoadResult.Success] with [InstreamAd] or [InstreamAdLoadResult.Failure]
     * with [InstreamAdRequestError].
     */
    @JvmSynthetic
    suspend fun loadAd(
        configuration: InstreamAdRequest
    ): InstreamAdLoadResult {
        val requestConfig: VmapRequestConfig =
            YandexInstreamAdRequestAdapter(configuration, VideoLoaderType.INSTREAM_AD)
        val coreAdLoadResult = adLoadingController.loadInstreamAd(requestConfig)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel loading the instream ad.
     */
    fun cancelLoading() {
        adLoadingController.cancelLoading()
    }
}
