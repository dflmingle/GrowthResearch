package com.yandex.mobile.ads.feed

import com.monetization.ads.base.video.VideoEventController
import com.monetization.ads.common.AdImpressionData
import com.monetization.ads.core.utils.CallbackStackTraceMarker
import com.monetization.ads.feed.ui.FeedAdapterInternal
import com.monetization.ads.nativeads.CoreNativeAdEventListener
import com.yandex.mobile.ads.common.adapter.YandexImpressionDataAdapter

/**
 *  Adapter for displaying feed ads. Class allows to set [FeedAdEventListener].
 *
 *  @property feedAd feed ad to display
 */
class FeedAdAdapter(
    feedAd: FeedAd
) : FeedAdapterInternal(feedAd.feedViewModel) {

    /**
     * Sets an [FeedAdEventListener].
     */
    var eventListener: FeedAdEventListener? = null

    override val feedItemAdEventListener: CoreNativeAdEventListener = FeedItemAdEventListener()

    override val videoEventController: VideoEventController = VideoEventController()

    private inner class FeedItemAdEventListener : CoreNativeAdEventListener {

        override fun onAdClicked() {
            CallbackStackTraceMarker {
                eventListener?.onAdClicked()
            }
        }

        override fun onImpression(impressionData: AdImpressionData?) {
            val impressionDataAdapter = impressionData?.let { YandexImpressionDataAdapter(it) }
            CallbackStackTraceMarker {
                eventListener?.onImpression(impressionDataAdapter)
            }
        }

        override fun onLeftApplication() {
            // do nothing
        }

        override fun onReturnedToApplication() {
            // do nothing
        }

        override fun closeNativeAd() {
            // do nothing
        }
    }
}
