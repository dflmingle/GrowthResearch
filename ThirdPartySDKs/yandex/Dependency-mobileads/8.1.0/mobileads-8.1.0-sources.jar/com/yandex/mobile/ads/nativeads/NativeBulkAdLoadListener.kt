package com.yandex.mobile.ads.nativeads

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * Interface that is implemented to determine when the loading of bulk ad request has completed or failed.
 */
@MainThread
interface NativeBulkAdLoadListener {

    /**
     * Notifies when native ads are loaded.
     *
     * @param nativeAds List of ads, which is ready to be bound to view.
     */
    @JvmSuppressWildcards
    fun onAdsLoaded(nativeAds: List<NativeAd>)

    /**
     * Called when a slider ad request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdsFailedToLoad(error: AdRequestError)
}
