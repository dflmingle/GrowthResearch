package com.yandex.mobile.ads.rewarded

import android.content.Context
import androidx.annotation.MainThread
import com.monetization.ads.rewarded.CoreRewardedAdLoader
import com.monetization.ads.utils.api.ApiExternal
import com.monetization.ads.utils.api.ApiInternal
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.common.YandexAdRequestConfigurationConverter
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.rewarded.adapter.YandexRewardedAdLoadListenerAdapter
import com.yandex.mobile.ads.rewarded.converter.RewardedAdLoadResultConverter

/**
 * Full-screen rewarded ads.
 *
 * @param context The context through which can be accessible
 * the current theme, resources, etc. In particular, it
 * uses the window manager and theme in this context to present its UI.
 */
@MainThread
class RewardedAdLoader @ApiExternal constructor(context: Context) {

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val coreRewardedAdLoader = CoreRewardedAdLoader(context, sdkEnvironmentModule)
    private val adRequestConfigurationConverter = YandexAdRequestConfigurationConverter()
    private val adLoadResultConverter = RewardedAdLoadResultConverter()

    /**
     * Starts loading the ad on a background thread.
     *
     * @param adRequest Data for targeting and ad configuration.
     * @param listener [RewardedAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(adRequest: AdRequest, listener: RewardedAdLoadListener) {
        val adRequestData = adRequestConfigurationConverter.convertToAdRequestData(adRequest)
        val coreListener = YandexRewardedAdLoadListenerAdapter(listener)
        coreRewardedAdLoader.loadAd(adRequestData, coreListener)
    }

    /**
     * Starts loading the ad on a background thread. Suspends until the result is available.
     *
     * @param adRequest Data for targeting and ad configuration.
     * @return [RewardedAdLoadResult.Success] with [RewardedAd] or [RewardedAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(adRequest: AdRequest): RewardedAdLoadResult {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adRequest)
        val coreAdLoadResult = coreRewardedAdLoader.loadAd(coreAdRequestData)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Starts loading the ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param listener [RewardedAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(adUnitId: String, readyResponse: String, listener: RewardedAdLoadListener) {
        val adRequestData = adRequestConfigurationConverter.convertToAdRequestData(adUnitId, readyResponse)
        val coreListener = YandexRewardedAdLoadListenerAdapter(listener)
        coreRewardedAdLoader.loadAd(adRequestData, coreListener)
    }

    /**
     * Starts loading the ad on a background thread with ready response. Suspends until the result is available.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @return [RewardedAdLoadResult.Success] with [RewardedAd] or [RewardedAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(adUnitId: String, readyResponse: String): RewardedAdLoadResult {
        val coreAdRequestData = adRequestConfigurationConverter.convertToAdRequestData(adUnitId, readyResponse)
        val coreAdLoadResult = coreRewardedAdLoader.loadAd(coreAdRequestData)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel active loading of the rewarded ads.
     */
    @ApiExternal
    fun cancelLoading() {
        coreRewardedAdLoader.cancelLoading()
    }
}
