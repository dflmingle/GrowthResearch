package com.yandex.mobile.ads.common

/**
 * Contains creative information
 *
 * @property creativeId Unique identifier of the creative.
 * @property campaignId Unique identifier of the ad campaign.
 * @property placeId Identifier of the ad placement.
 * @property offerId Identifier of the offer.
 */
class Creative internal constructor(
    val creativeId: String?,
    val campaignId: String?,
    val placeId: String?,
    val offerId: String?,
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Creative

        if (creativeId != other.creativeId) return false
        if (campaignId != other.campaignId) return false
        if (placeId != other.placeId) return false
        if (offerId != other.offerId) return false

        return true
    }

    override fun hashCode(): Int {
        var result = creativeId?.hashCode() ?: 0
        result = 31 * result + (campaignId?.hashCode() ?: 0)
        result = 31 * result + (placeId?.hashCode() ?: 0)
        result = 31 * result + (offerId?.hashCode() ?: 0)
        return result
    }

    override fun toString(): String {
        return "Creative(creativeId=$creativeId, campaignId=$campaignId, placeId=$placeId, offerId=$offerId)"
    }
}
