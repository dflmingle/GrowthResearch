package com.yandex.mobile.ads.nativeads

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * Interface that is implemented to determine when the loading of slider ad has completed or failed.
 */
@MainThread
interface SliderAdLoadListener {

    /**
     * Notifies when slider ad is loaded.
     *
     * @param sliderAd Slider ad, which is ready to be bound to view.
     */
    fun onSliderAdLoaded(sliderAd: SliderAd)

    /**
     * Called when a slider ad request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onSliderAdFailedToLoad(error: AdRequestError)
}
