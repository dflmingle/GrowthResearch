package com.yandex.mobile.ads.common

import androidx.annotation.MainThread
import com.monetization.ads.base.video.VideoEventController
import com.yandex.mobile.ads.common.adapter.YandexVideoEventListenerAdapter

/**
 * An object that provides playback control for video.
 */
@MainThread
class VideoController(private val videoEventController: VideoEventController) {

    /**
     * Sets a [VideoEventListener] that will receive callbacks for video events.
     *
     * @param videoEventListener [VideoEventListener].
     */
    fun setVideoEventListener(videoEventListener: VideoEventListener?) {
        if (videoEventListener != null) {
            val adapter = YandexVideoEventListenerAdapter(videoEventListener)
            videoEventController.setVideoEventListener(adapter)
        } else {
            videoEventController.setVideoEventListener(null)
        }
    }
}
