package com.yandex.mobile.ads.appopenad

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * A listener for receiving notifications during the lifecycle of an app open ad.
 */
@MainThread
interface AppOpenAdLoadListener {

    /**
     * Notifies when ad is loaded.
     *
     * @param appOpenAd app open ad, which is ready to be shown.
     */
    fun onAdLoaded(appOpenAd: AppOpenAd)

    /**
     * Called when an app open ad request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdFailedToLoad(error: AdRequestError)
}
