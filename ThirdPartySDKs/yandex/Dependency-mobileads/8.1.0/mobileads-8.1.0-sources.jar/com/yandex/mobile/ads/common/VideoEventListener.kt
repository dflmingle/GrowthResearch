package com.yandex.mobile.ads.common

import androidx.annotation.MainThread

/**
 * A listener for receiving callbacks for video events.
 */
@MainThread
fun interface VideoEventListener {

    /**
     * Called when video playback ends.
     */
    fun onVideoComplete()
}
