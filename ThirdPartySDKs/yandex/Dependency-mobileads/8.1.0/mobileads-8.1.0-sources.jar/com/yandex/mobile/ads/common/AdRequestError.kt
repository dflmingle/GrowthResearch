package com.yandex.mobile.ads.common

import com.yandex.mobile.ads.common.AdRequestError.Code

/**
 * Class containing errors that can occur during an ad request.
 *
 * @property code An error code from the [Code]
 * @property description An error description
 * @property adUnitId Requested ad unit ID
 */
class AdRequestError @JvmOverloads constructor(
    val code: Int,
    val description: String,
    val adUnitId: String? = null
) {

    /**
     * Error codes to explain the main cause.
     */
    object Code {

        /**
         * Ad request failed with internal error.
         */
        const val INTERNAL_ERROR = 1

        /**
         * Ad request configured incorrectly.
         */
        const val INVALID_REQUEST = 2

        /**
         * Ad request failed with connection error.
         */
        const val NETWORK_ERROR = 3

        /**
         * Ad request completed successfully, but there are no ads available.
         */
        const val NO_FILL = 4

        /**
         * The ad request failed with system error.
         * For instance a WebView can't access the database file.
         * `NOTE:` Don't try to load/reload ads if you've got this error.
         */
        const val SYSTEM_ERROR = 5

        /**
         * Ad request failed with unknown error.
         */
        const val UNKNOWN_ERROR = 0
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) {
            return true
        }
        if (other == null || javaClass != other.javaClass) {
            return false
        }
        val adRequestError = other as AdRequestError
        if (code != adRequestError.code) {
            return false
        }
        return if (adUnitId != adRequestError.adUnitId) {
            false
        } else {
            description == adRequestError.description
        }
    }

    override fun hashCode(): Int {
        var result = description.hashCode()
        result = 31 * result + code
        result = 31 * result + (adUnitId?.hashCode() ?: 0)
        return result
    }

    override fun toString(): String {
        return "AdRequestError (code: $code, description: $description, adUnitId: ${adUnitId.orEmpty()})"
    }
}
