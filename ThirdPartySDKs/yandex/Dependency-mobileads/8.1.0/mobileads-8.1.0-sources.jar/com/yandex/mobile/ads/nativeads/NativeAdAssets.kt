package com.yandex.mobile.ads.nativeads

/**
 * Interface provides values for native ad assets.
 */
interface NativeAdAssets {

    /**
     * Returns age restrictions.
     * Available in content and app install ads.
     *
     * @return Age restrictions.
     */
    val age: String?

    /**
     * Returns ad body text.
     * Available in content and app install ads.
     *
     * @return Ad body text.
     */
    val body: String?

    /**
     * Returns call to action.
     * Available in content and app install ads.
     *
     * @return Call to action.
     */
    val callToAction: String?

    /**
     * Returns advertiser's domain.
     * Available in content and app install ads.
     *
     * @return Advertiser's domain.
     */
    val domain: String?

    /**
     * Returns website favicon.
     * Available in content ads.
     *
     * @return Website favicon.
     */
    val favicon: NativeAdImage?

    /**
     * Returns boolean value that indicates feedback availability.
     *
     * @return feedback availability.
     */
    val isFeedbackAvailable: Boolean

    /**
     * Returns app icon.
     * Available in app install ads.
     *
     * @return App icon.
     */
    val icon: NativeAdImage?

    /**
     * Returns main ad image.
     * Available in content, app install and image ads.
     *
     * @return Main ad image.
     */
    val image: NativeAdImage?

    /**
     * Returns media content information.
     * Available in content, app install and image ads.
     *
     * @return Ad media.
     */
    val media: NativeAdMedia?

    /**
     * Returns price.
     * Available in app install ads.
     *
     * @return Price.
     */
    val price: String?

    /**
     * Returns app rating.
     * Available in app install ads.
     *
     * @return App rating.
     */
    val rating: Float?

    /**
     * Returns app reviews number.
     * Available in app install ads.
     *
     * @return App reviews number.
     */
    val reviewCount: String?

    /**
     * Returns sponsored text.
     * Available in content and app install ads.
     *
     * @return Sponsored text.
     */
    val sponsored: String?

    /**
     * Returns ad title.
     * Available in content and app install ads.
     *
     * @return Ad title.
     */
    val title: String?

    /**
     * Returns warning asset.
     * Available in content and app install ads.
     *
     * @return Warning asset.
     */
    val warning: NativeAdWarning?
}
