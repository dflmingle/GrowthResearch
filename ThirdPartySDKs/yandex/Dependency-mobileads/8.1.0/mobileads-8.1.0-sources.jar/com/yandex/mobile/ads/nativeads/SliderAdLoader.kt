package com.yandex.mobile.ads.nativeads

import android.content.Context
import com.monetization.ads.nativeads.CoreNativeAdLoader
import com.monetization.ads.utils.api.ApiExternal
import com.monetization.ads.utils.api.ApiInternal
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.nativeads.adapter.load.YandexSliderAdLoadListenerAdapter
import com.yandex.mobile.ads.nativeads.converter.SliderAdLoadResultConverter

/**
 * Class containing controls for slider ad loading.
 *
 * @param context The activity context used to retrieve the application context.
 */
class SliderAdLoader @ApiExternal constructor(context: Context) {

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val coreNativeAdLoader = CoreNativeAdLoader(context, sdkEnvironmentModule)
    private val nativeAdRequestConfigurationConverter = YandexNativeAdRequestConfigurationConverter()
    private val adLoadResultConverter = SliderAdLoadResultConverter()

    /**
     * Start loading the slider ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a slider ad.
     * @param listener [SliderAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(adRequest: AdRequest, listener: SliderAdLoadListener) {
        loadAd(adRequest, NativeAdOptions(), listener)
    }

    /**
     * Start loading the slider ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a slider ad.
     * @return [SliderAdLoadResult.Success] with [SliderAd] or [SliderAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(adRequest: AdRequest): SliderAdLoadResult {
        return loadAd(adRequest, NativeAdOptions())
    }

    /**
     * Start loading the slider ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a slider ad.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @param listener [SliderAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(
        adRequest: AdRequest,
        options: NativeAdOptions,
        listener: SliderAdLoadListener
    ) {
        val adRequestData = nativeAdRequestConfigurationConverter.convertToAdRequestData(
            adRequest = adRequest,
            options = options
        )
        val coreListener = YandexSliderAdLoadListenerAdapter(listener)
        coreNativeAdLoader.loadSlider(adRequestData, coreListener)
    }

    /**
     * Start loading the slider ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a slider ad.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @return [SliderAdLoadResult.Success] with [SliderAd] or [SliderAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(
        adRequest: AdRequest,
        options: NativeAdOptions
    ): SliderAdLoadResult {
        val adRequestData = nativeAdRequestConfigurationConverter.convertToAdRequestData(
            adRequest = adRequest,
            options = options
        )
        val coreAdLoadResult = coreNativeAdLoader.loadSlider(adRequestData)
        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Start loading the slider ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param listener [SliderAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(adUnitId: String, readyResponse: String, listener: SliderAdLoadListener) {
        loadAd(adUnitId, readyResponse, NativeAdOptions(), listener)
    }

    /**
     * Start loading the slider ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @return [SliderAdLoadResult.Success] with [SliderAd] or [SliderAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(
        adUnitId: String,
        readyResponse: String
    ): SliderAdLoadResult {
        return loadAd(adUnitId, readyResponse, NativeAdOptions())
    }

    /**
     * Start loading the slider ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @param listener [SliderAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(
        adUnitId: String,
        readyResponse: String,
        options: NativeAdOptions,
        listener: SliderAdLoadListener
    ) {
        val adRequestData = nativeAdRequestConfigurationConverter.convertToAdRequestData(
            adUnitId = adUnitId,
            options = options,
            readyResponse = readyResponse
        )
        val coreListener = YandexSliderAdLoadListenerAdapter(listener)
        coreNativeAdLoader.loadSlider(adRequestData, coreListener)
    }

    /**
     * Start loading the slider ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @return [SliderAdLoadResult.Success] with [SliderAd] or [SliderAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(
        adUnitId: String,
        readyResponse: String,
        options: NativeAdOptions
    ): SliderAdLoadResult {
        val adRequestData = nativeAdRequestConfigurationConverter.convertToAdRequestData(
            adUnitId = adUnitId,
            options = options,
            readyResponse = readyResponse
        )
        val coreAdLoadResult = coreNativeAdLoader.loadSlider(adRequestData)
        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel loading the native ad.
     */
    @ApiExternal
    fun cancelLoading() {
        coreNativeAdLoader.cancelLoading()
    }
}
