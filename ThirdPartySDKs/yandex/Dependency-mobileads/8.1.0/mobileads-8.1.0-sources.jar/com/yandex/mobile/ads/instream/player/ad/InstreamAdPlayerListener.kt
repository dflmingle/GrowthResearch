package com.yandex.mobile.ads.instream.player.ad

import androidx.annotation.MainThread
import com.yandex.mobile.ads.instream.player.ad.error.InstreamAdPlayerError
import com.yandex.mobile.ads.video.playback.model.VideoAd

/**
 * This interface used to handle callbacks of instream ad player.
 * Callback calls on this object should respond to appropriate method calls on InstreamAdPlayer
 */
@MainThread
interface InstreamAdPlayerListener {

    /**
     * Fire this callback when instream ad player is ready to present videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdPrepared(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player started playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdStarted(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player paused playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdPaused(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player resumed playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdResumed(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player started buffering the videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdBufferingStarted(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player ended buffering the videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdBufferingFinished(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player completed playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdCompleted(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player volume was updated
     *
     * @param videoAd Video Ad for which the event occurred
     * @param volume  Volume value that was set to the player
     */
    fun onVolumeChanged(
        videoAd: VideoAd,
        volume: Float
    )

    /**
     * Fire this callback when instream ad player stopped playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdStopped(videoAd: VideoAd)

    /**
     * Fire this callback when instream ad player stopped playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     */
    fun onAdSkipped(videoAd: VideoAd)

    /**
     * Fire this callback when error occures in instream ad player while preparing or playing videoAd
     *
     * @param videoAd Video Ad for which the event occurred
     * @param error   InstreamAdPlayerError that occurred
     */
    fun onError(
        videoAd: VideoAd,
        error: InstreamAdPlayerError
    )
}
