package com.yandex.mobile.ads.common

/**
 * Gender characteristics.
 */
object Gender {

    /**
     * Female gender.
     */
    const val FEMALE = "female"

    /**
     * Male gender.
     */
    const val MALE = "male"
}
