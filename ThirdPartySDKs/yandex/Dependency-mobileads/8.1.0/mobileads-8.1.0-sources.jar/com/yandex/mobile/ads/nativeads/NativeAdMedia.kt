package com.yandex.mobile.ads.nativeads

/**
 * NativeAdMedia represents media content.
 */
interface NativeAdMedia {

    /**
     * Returns aspect ratio of media content.
     *
     * @return aspect ratio of media content.
     */
    val aspectRatio: Float

    /**
     * Returns true if media content contains video.
     *
     * @return true if media content contains video, false otherwise.
     */
    val hasVideo: Boolean
}
