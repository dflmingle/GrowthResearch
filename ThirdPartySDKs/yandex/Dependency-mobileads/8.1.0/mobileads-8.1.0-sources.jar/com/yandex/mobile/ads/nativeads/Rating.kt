package com.yandex.mobile.ads.nativeads

import com.monetization.ads.nativeads.RatingAsset

/**
 * Interface allows ad to set rating value to arbitrary view.
 */
interface Rating : RatingAsset {

    /**
     * Returns rating represented by float value in interval from 0 to 5.
     *
     * @return rating.
     */
    override fun getRating(): Float

    /**
     * Sets rating value.
     *
     * @param rating Rating represented by Float value in interval from 0 to 5.
     */
    override fun setRating(rating: Float)
}
