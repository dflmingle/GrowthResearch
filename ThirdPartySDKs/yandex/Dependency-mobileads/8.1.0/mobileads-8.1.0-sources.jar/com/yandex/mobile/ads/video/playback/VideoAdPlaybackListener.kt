package com.yandex.mobile.ads.video.playback

import androidx.annotation.MainThread

import com.yandex.mobile.ads.video.playback.model.VideoAd

/**
 * This class provides information about video ad playback
 */
@MainThread
interface VideoAdPlaybackListener {

    fun onAdPrepared(videoAd: VideoAd)

    /**
     * Fire this callback when video ad playback started
     *
     * @param videoAd video ad playback information
     */
    fun onAdStarted(videoAd: VideoAd)

    /**
     * Fire this callback when video ad playback paused
     *
     * @param videoAd video ad playback information
     */
    fun onAdPaused(videoAd: VideoAd)

    /**
     * Fire this callback when video ad playback resumed
     *
     * @param videoAd video ad information
     */
    fun onAdResumed(videoAd: VideoAd)

    /**
     * Fire this callback when video ad playback completed
     *
     * @param videoAd video ad information
     */
    fun onAdCompleted(videoAd: VideoAd)

    /**
     * Fire this callback when video ad playback skipped
     *
     * @param videoAd video ad information
     */
    fun onAdSkipped(videoAd: VideoAd)

    /**
     * Fire this callback when video ad playback stopped
     *
     * @param videoAd video ad information
     */
    fun onAdStopped(videoAd: VideoAd)

    /**
     * Fire this callback when error occurred during ad playback
     *
     * @param videoAd video ad information
     */
    fun onAdError(videoAd: VideoAd)

    /**
     * Fire this callback when video ad volume was updated
     *
     * @param videoAd video ad information
     * @param volume  volume value that was set to the player
     */
    fun onVolumeChanged(
        videoAd: VideoAd,
        volume: Float
    )

    /**
     * Fire this callback when video ad is clicked
     *
     * @param videoAd video ad information
     */
    fun onAdClicked(videoAd: VideoAd)

    /**
     * Fire this callback when impression of the ad occurred.
     *
     * @param videoAd video ad information
     */
    fun onImpression(videoAd: VideoAd)
}
