package com.yandex.mobile.ads.nativeads

/**
 * The type of native ad.
 */
enum class NativeAdType(val value: String) {

    /**
     * Content native ad type.
     */
    CONTENT("content"),

    /**
     * App install native ad type.
     */
    APP_INSTALL("app"),

    /**
     * Media native ad type.
     */
    MEDIA("media");
}
