package com.yandex.mobile.ads.instream.adbreak

import androidx.annotation.MainThread
import com.yandex.mobile.ads.instream.InstreamAdBreakEventListener
import com.yandex.mobile.ads.instream.player.ad.InstreamAdPlayer
import com.yandex.mobile.ads.instream.player.ad.InstreamAdView
import com.yandex.mobile.ads.video.playback.VideoAdPlaybackListener

/**
 * This class is used to play instream ad breaks.
 */
@MainThread
interface InstreamAdBreak {

    /**
     * Returns [AdBreakData] that's associated with this instream ad break.
     *
     * @return [AdBreakData].
     */
    val adBreakData: AdBreakData

    /**
     * Register a callback for listening instream ad break playback events.
     *
     * @param listener an [InstreamAdBreakEventListener] object that handles lifecycle of instream ad break.
     */
    fun setListener(listener: InstreamAdBreakEventListener?)

    /**
     * Register a callback for listening video playback events
     *
     * @param listener an [VideoAdPlaybackListener] object that handles video playback events.
     */
    fun setVideoAdPlaybackListener(listener: VideoAdPlaybackListener?)

    /**
     * Prepare instream ad break playback. Note that prepare() should always be called before play() method.
     *
     * @param instreamAdPlayer player to play instream ad break.
     */
    fun prepare(instreamAdPlayer: InstreamAdPlayer)

    /**
     * Prepare instream ad break playback. Note that prepare() should always be called before play() method.
     */
    fun prepare()

    /**
     * Start instream ad break playback. Note that you can call play only on a prepared instream ad break.
     *
     * @param instreamAdView the view in which instream ad break will be displayed.
     */
    fun play(instreamAdView: InstreamAdView)

    /**
     * Pause instream ad break playback.
     */
    fun pause()

    /**
     * Resume paused instream ad break playback.
     */
    fun resume()

    /**
     * Invalidate instream ad break playback. Call this method right before ad player is invalidated.
     * To resume playback after invalidation you should prepare and start instream ad break again.
     */
    fun invalidate()
}
