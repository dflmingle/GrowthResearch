package com.yandex.mobile.ads.video.playback.model

/**
 * This class provides information about adpod
 */
interface AdPodInfo {

    /**
     * Gets ads count in ad pod
     *
     * @return return size of ad pod, or 1 if there is no ad pod
     */
    val adsCount: Int

    /**
     * Gets current video position in ad pod, return 1 if there is no ad pod
     *
     * @return position
     */
    val adPosition: Int
}
