package com.yandex.mobile.ads.feed

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdRequestError

/**
 * Interface that is implemented to determine when the loading of feed advertising has completed or failed.
 */
@MainThread
interface FeedAdLoadListener {

    /**
     * Notifies when additional ads is loaded.
     */
    fun onAdLoaded()

    /**
     * Called when additional ads request failed.
     *
     * @param error see errors here [AdRequestError]
     */
    fun onAdFailedToLoad(error: AdRequestError)
}
