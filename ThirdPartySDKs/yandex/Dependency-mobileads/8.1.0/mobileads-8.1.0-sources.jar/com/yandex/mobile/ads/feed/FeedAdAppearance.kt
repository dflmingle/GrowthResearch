package com.yandex.mobile.ads.feed

class FeedAdAppearance(
    val cardWidth: Int?,
    val cardCornerRadius: Double?
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) {
            return true
        }
        if (other == null || javaClass != other.javaClass) {
            return false
        }

        other as FeedAdAppearance

        return if (cardWidth != other.cardWidth) {
            false
        } else {
            cardCornerRadius == other.cardCornerRadius
        }
    }

    override fun hashCode(): Int {
        var result = cardWidth?.hashCode() ?: 0
        result = 31 * result + cardCornerRadius.hashCode()
        return result
    }

    /**
     * Class for creating new [FeedAd] object [FeedAdAppearance].
     *
     *  * @property width Feed card width.
     */
    class Builder(private val cardWidth: Int) {

        private var cardCornerRadius: Double? = null

        fun build(): FeedAdAppearance {
            return FeedAdAppearance(
                cardWidth = cardWidth, cardCornerRadius = cardCornerRadius
            )
        }

        /**
         * Sets card corner radius
         *
         * @param radius card corner radius
         * @return FeedAdAppearance.Builder with card corner radius.
         */
        fun setCardCornerRadius(radius: Double?): Builder {
            this.cardCornerRadius = radius
            return this
        }
    }
}
