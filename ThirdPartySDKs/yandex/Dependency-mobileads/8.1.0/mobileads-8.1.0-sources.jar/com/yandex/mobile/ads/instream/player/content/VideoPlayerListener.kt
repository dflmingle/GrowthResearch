package com.yandex.mobile.ads.instream.player.content

import androidx.annotation.MainThread

/**
 * This interface used to handle callbacks of content video player.
 * Callback calls on this object should respond to appropriate method calls on VideoPlayer
 */
@MainThread
interface VideoPlayerListener {

    /**
     * Fire this callback when content video player prepared to play content video
     */
    fun onVideoPrepared()

    /**
     * Fire this callback when content video player completed playback
     */
    fun onVideoCompleted()

    /**
     * Fire this callback when content video player resumed playback
     */
    fun onVideoResumed()

    /**
     * Fire this callback when content video player paused playback
     */
    fun onVideoPaused()

    /**
     * Fire this callback when error occurs in video player
     */
    fun onVideoError()
}
