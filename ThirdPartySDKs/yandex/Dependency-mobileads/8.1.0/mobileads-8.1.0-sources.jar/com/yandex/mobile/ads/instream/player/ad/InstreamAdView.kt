package com.yandex.mobile.ads.instream.player.ad

import android.content.Context
import android.util.AttributeSet
import androidx.annotation.MainThread
import com.yandex.mobile.ads.instream.player.ad.adapter.YandexVideoAdCreativeUiElementsProvider
import com.yandex.mobile.ads.video.playback.view.InstreamAdViewBinderProvider

@MainThread
class InstreamAdView : PrivateInstreamAdView {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr)

    constructor(
        context: Context,
        attrs: AttributeSet?,
        defStyleAttr: Int,
        defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes)

    override fun privateSetViewBinderProvider(viewBinderProvider: InstreamAdViewBinderProvider?) {
        adUiElementsProvider = viewBinderProvider?.let { YandexVideoAdCreativeUiElementsProvider(it) }
    }
}
