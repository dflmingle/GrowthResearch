package com.yandex.mobile.ads.instream

/**
 * Class defines Instream ad loader configuration.
 */
class InstreamAdRequest private constructor(
    val categoryId: String,
    val pageId: String,
    val parameters: Map<String, String>?
) {

    /**
     * Class for creating new [InstreamAdRequest] object.
     */
    class Builder(private val pageId: String) {

        private var categoryId: String = DEFAULT_CATEGORY_ID
        private var parameters: Map<String, String>? = null

        /**
         * Constructs a [InstreamAdRequest] with specified configurations.
         *
         * @return [InstreamAdRequest].
         */
        fun build(): InstreamAdRequest {
            return InstreamAdRequest(categoryId = categoryId, pageId = pageId, parameters = parameters)
        }

        /**
         * Sets category id.
         *
         * @param categoryId Category identifier.
         * Can be created in the Partner interface. Default value is **0**.
         * @return [Builder] with specified category identifier
         */
        fun setCategoryId(categoryId: String?): Builder {
            this.categoryId = (categoryId ?: DEFAULT_CATEGORY_ID).ifEmpty {
                throw IllegalArgumentException("Passed categoryId is empty")
            }
            return this
        }

        /**
         * Sets custom request parameters.
         *
         * @param parameters custom parameters.
         * @return [Builder] with custom parameters.
         */
        fun setParameters(parameters: Map<String, String>): Builder {
            this.parameters = parameters
            return this
        }
    }

    private companion object {

        private const val DEFAULT_CATEGORY_ID = "0"
    }
}
