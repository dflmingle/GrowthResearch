package com.yandex.mobile.ads.feed

import com.yandex.mobile.ads.common.ImpressionData

/**
 * A listener for receiving notifications during the lifecycle of a feed ad.
 */
interface FeedAdEventListener {

    /**
     * Called when user clicked on the ad.
     */
    fun onAdClicked()

    /**
     * Called when an impression was observed
     *
     * @param impressionData - impression level revenue data
     */
    fun onImpression(impressionData: ImpressionData?)
}
