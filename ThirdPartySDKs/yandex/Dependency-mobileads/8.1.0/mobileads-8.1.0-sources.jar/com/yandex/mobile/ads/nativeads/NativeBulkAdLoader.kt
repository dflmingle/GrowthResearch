package com.yandex.mobile.ads.nativeads

import android.content.Context
import com.monetization.ads.nativeads.CoreNativeAdLoader
import com.monetization.ads.utils.api.ApiExternal
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.nativeads.adapter.load.YandexNativeBulkAdLoadListenerAdapter
import com.yandex.mobile.ads.nativeads.converter.NativeBulkAdLoadResultConverter

/**
 * Class containing controls for bulk request ad loading.
 * @param context The activity context used to retrieve the application context.
 */
@ApiExternal
class NativeBulkAdLoader(context: Context) {

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val coreNativeAdLoader = CoreNativeAdLoader(context, sdkEnvironmentModule)
    private val nativeAdRequestConfigurationConverter = YandexNativeAdRequestConfigurationConverter()
    private val adLoadResultConverter = NativeBulkAdLoadResultConverter()

    /**
     * Start loading the native ads on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch native ads.
     * @param adsCount Count of requested ads.
     * @param listener [NativeBulkAdLoadListener] to be invoked when ads are loaded or loading fails.
     */
    fun loadAds(
        adRequest: AdRequest,
        adsCount: Int,
        listener: NativeBulkAdLoadListener
    ) {
        loadAds(adRequest, adsCount, NativeAdOptions(), listener)
    }

    /**
     * Start loading the native ads on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch native ads.
     * @param adsCount Count of requested ads.
     * @return [NativeBulkAdLoadResult.Success] with List of [NativeAd] or [NativeBulkAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    suspend fun loadAds(
        adRequest: AdRequest,
        adsCount: Int
    ): NativeBulkAdLoadResult {
        return loadAds(adRequest, adsCount, NativeAdOptions())
    }

    /**
     * Start loading the native ads on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch native ads.
     * @param adsCount Count of requested ads.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @param listener [NativeBulkAdLoadListener] to be invoked when ads are loaded or loading fails.
     */
    fun loadAds(
        adRequest: AdRequest,
        adsCount: Int,
        options: NativeAdOptions,
        listener: NativeBulkAdLoadListener
    ) {
        val adRequestData = nativeAdRequestConfigurationConverter.convertToAdRequestData(
            adRequest = adRequest,
            options = options
        )
        val coreListener = YandexNativeBulkAdLoadListenerAdapter(listener)
        coreNativeAdLoader.loadAds(adRequestData, adsCount, coreListener)
    }

    /**
     * Start loading the native ads on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch native ads.
     * @param adsCount Count of requested ads.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @return [NativeBulkAdLoadResult.Success] with List of [NativeAd] or [NativeBulkAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    suspend fun loadAds(
        adRequest: AdRequest,
        adsCount: Int,
        options: NativeAdOptions
    ): NativeBulkAdLoadResult {
        val adRequestData = nativeAdRequestConfigurationConverter.convertToAdRequestData(
            adRequest = adRequest,
            options = options
        )
        val coreAdLoadResult = coreNativeAdLoader.loadAds(adRequestData, adsCount)
        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel bulk ad loading.
     */
    fun cancelLoading() {
        coreNativeAdLoader.cancelLoading()
    }
}
