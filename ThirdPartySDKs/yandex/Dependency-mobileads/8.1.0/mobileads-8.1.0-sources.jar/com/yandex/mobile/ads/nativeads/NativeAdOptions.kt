package com.yandex.mobile.ads.nativeads

/**
 * Configuration options for native ad loading.
 *
 * @property shouldLoadImagesAutomatically Flag for automatic image loading.
 *           `true` – Load automatically (default); `false` – Load manually.
 */
class NativeAdOptions internal constructor(
    val shouldLoadImagesAutomatically: Boolean = true
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || javaClass != other.javaClass) return false
        val that = other as NativeAdOptions
        return shouldLoadImagesAutomatically == that.shouldLoadImagesAutomatically
    }

    override fun hashCode(): Int = shouldLoadImagesAutomatically.hashCode()

    /**
     * Builder for [NativeAdOptions].
     * Provides API for configuring native ad loading options.
     */
    class Builder {

        private var shouldLoadImagesAutomatically: Boolean = true

        /**
         * Sets whether images should be loaded automatically.
         *
         * @param shouldLoadImagesAutomatically `true` to load images automatically (default),
         *                                      `false` to load manually.
         * @return This builder instance for method chaining.
         */
        fun setShouldLoadImagesAutomatically(shouldLoadImagesAutomatically: Boolean): Builder = apply {
            this.shouldLoadImagesAutomatically = shouldLoadImagesAutomatically
        }

        /**
         * Builds [NativeAdOptions] with the configured parameters.
         *
         * @return Configured [NativeAdOptions] instance.
         */
        fun build(): NativeAdOptions = NativeAdOptions(shouldLoadImagesAutomatically)
    }
}
