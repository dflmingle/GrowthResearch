package com.yandex.mobile.ads.instream

import androidx.annotation.MainThread

/**
 * Class that is implemented to determine when the Instream ads loading has completed or failed.
 */
@MainThread
interface InstreamAdLoadListener {

    /**
     * Notifies that [InstreamAd] was loaded.
     *
     * @param instreamAd [InstreamAd] Result of successful response.
     */
    fun onInstreamAdLoaded(instreamAd: InstreamAd)

    /**
     * Notifies that [InstreamAd] failed to load.
     *
     * @param error [InstreamAdRequestError] Reason describing problem encountered while loading [InstreamAd].
     */
    fun onInstreamAdFailedToLoad(error: InstreamAdRequestError)
}
