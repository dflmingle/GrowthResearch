package com.yandex.mobile.ads.common

/**
 * Class containing errors that can occur during an ad request.
 */
interface AdError {

    /**
     * Returns an error description.
     *
     * @return error description.
     */
    val description: String
}
