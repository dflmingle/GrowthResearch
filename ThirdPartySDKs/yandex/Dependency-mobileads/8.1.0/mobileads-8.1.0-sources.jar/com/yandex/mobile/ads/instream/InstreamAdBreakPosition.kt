package com.yandex.mobile.ads.instream

class InstreamAdBreakPosition(
    /**
     * Provides type of ad break time offset position. Allowed values see in [Type]
     *
     * @return Type of ad break time offset position
     */
    val positionType: Type,
    /**
     * Provides ad break time offset value. Units can be optained via [.getPositionType]
     *
     * @return Ad break time offset value
     */
    val value: Long
) {

    enum class Type {
        PERCENTS, MILLISECONDS, POSITION
    }
}
