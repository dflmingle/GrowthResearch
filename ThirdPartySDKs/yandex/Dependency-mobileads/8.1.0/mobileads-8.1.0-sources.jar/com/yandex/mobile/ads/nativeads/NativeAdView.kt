package com.yandex.mobile.ads.nativeads

import android.content.Context
import android.util.AttributeSet
import androidx.annotation.AttrRes
import androidx.annotation.MainThread
import androidx.annotation.StyleRes
import com.monetization.ads.nativeads.ExtendedNativeAdView

/**
 * NativeAdView represents root view for native ad.
 * Views for all of the required assets should be set.
 * If any of the required views is not provided for native ad which contains corresponding assets, binding fails.
 * Optional views may be provided to increase CTR.
 */
@MainThread
class NativeAdView : ExtendedNativeAdView {

    /**
     * Constructs a new [NativeAdView] programmatically.
     *
     * @param context The Context the view is running in, through which it can
     * access the current theme, resources, etc.
     */
    constructor(context: Context) : super(context)

    /**
     * Constructs a new [NativeAdView] from `XML` layout file.
     *
     * @param context The Context the view is running in, through which it can
     * access the current theme, resources, etc.
     * @param attrs   The attributes of the XML tag that is inflating the view.
     */
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)

    /**
     * Constructs a new [NativeAdView] from `XML` layout file.
     *
     * @param context      The Context the view is running in, through which it can
     * access the current theme, resources, etc.
     * @param attrs        The attributes of the XML tag that is inflating the view.
     * @param defStyleAttr An attribute in the current theme that contains a
     * reference to a style resource that supplies default values for
     * the view. Can be 0 to not look for defaults.
     */
    constructor(context: Context, attrs: AttributeSet?, @AttrRes defStyleAttr: Int) :
        super(context, attrs, defStyleAttr)

    constructor(
        context: Context,
        attrs: AttributeSet?,
        @AttrRes defStyleAttr: Int,
        @StyleRes defStyleRes: Int
    ) : super(context, attrs, defStyleAttr, defStyleRes)
}
