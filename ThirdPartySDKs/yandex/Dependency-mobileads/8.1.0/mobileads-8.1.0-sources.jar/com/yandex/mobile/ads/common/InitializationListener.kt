package com.yandex.mobile.ads.common

import androidx.annotation.MainThread

/**
 * A listener for receiving notifications about SDK initialization complete.
 */
@MainThread
fun interface InitializationListener {

    /**
     * Called when SDK initialization completed.
     */
    fun onInitializationCompleted()
}
