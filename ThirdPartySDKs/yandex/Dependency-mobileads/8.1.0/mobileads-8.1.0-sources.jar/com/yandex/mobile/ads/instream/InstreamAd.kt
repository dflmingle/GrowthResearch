package com.yandex.mobile.ads.instream

import com.yandex.mobile.ads.instream.adbreak.InstreamAdBreak

/**
 * This class contains info about video ads playlist for content video
 */
interface InstreamAd {

    /**
     * Provides array of InstreamAdBreak objects to be displayed in ad playlist
     *
     * @return Ad breaks to be displayed in ad playlist
     */
    val instreamAdBreaks: List<InstreamAdBreak>
}
