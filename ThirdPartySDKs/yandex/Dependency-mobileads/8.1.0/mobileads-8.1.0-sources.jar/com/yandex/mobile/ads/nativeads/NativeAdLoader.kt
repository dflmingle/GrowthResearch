package com.yandex.mobile.ads.nativeads

import android.content.Context
import com.monetization.ads.nativeads.CoreNativeAdLoader
import com.monetization.ads.utils.api.ApiExternal
import com.monetization.ads.utils.api.ApiInternal
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.nativeads.adapter.load.YandexNativeAdLoadListenerAdapter
import com.yandex.mobile.ads.nativeads.converter.NativeAdLoadResultConverter

/**
 * Class containing controls for native ad loading.
 *
 * @param context The activity context used to retrieve the application context
 */
class NativeAdLoader @ApiExternal constructor(context: Context) {

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val adLoader = CoreNativeAdLoader(context, sdkEnvironmentModule)
    private val requestConfigurationConverter = YandexNativeAdRequestConfigurationConverter()
    private val adLoadResultConverter = NativeAdLoadResultConverter()

    /**
     * Start loading the native ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a native ad.
     * @param listener [NativeAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(adRequest: AdRequest, listener: NativeAdLoadListener) {
        loadAd(adRequest, NativeAdOptions(), listener)
    }

    /**
     * Start loading the native ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a native ad.
     * @return [NativeAdLoadResult.Success] with [NativeAd] or [NativeAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(adRequest: AdRequest): NativeAdLoadResult {
        return loadAd(adRequest, NativeAdOptions())
    }

    /**
     * Start loading the native ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a native ad.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @param listener [NativeAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiExternal
    fun loadAd(
        adRequest: AdRequest,
        options: NativeAdOptions,
        listener: NativeAdLoadListener
    ) {
        val coreAdRequestData = requestConfigurationConverter.convertToAdRequestData(
            adRequest = adRequest,
            options = options
        )
        val coreListener = YandexNativeAdLoadListenerAdapter(listener)
        adLoader.loadAd(coreAdRequestData, coreListener)
    }

    /**
     * Start loading the native ad on a background thread.
     *
     * @param adRequest an [AdRequest] object contains targeting information used to fetch a native ad.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @return [NativeAdLoadResult.Success] with [NativeAd] or [NativeAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiExternal
    suspend fun loadAd(
        adRequest: AdRequest,
        options: NativeAdOptions
    ): NativeAdLoadResult {
        val coreAdRequestData = requestConfigurationConverter.convertToAdRequestData(
            adRequest = adRequest,
            options = options
        )
        val coreAdLoadResult = adLoader.loadAd(coreAdRequestData)
        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Start loading the native ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param listener [NativeAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(adUnitId: String, readyResponse: String, listener: NativeAdLoadListener) {
        loadAd(adUnitId, readyResponse, NativeAdOptions(), listener)
    }

    /**
     * Start loading the native ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @return [NativeAdLoadResult.Success] with [NativeAd] or [NativeAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(
        adUnitId: String,
        readyResponse: String
    ): NativeAdLoadResult {
        return loadAd(adUnitId, readyResponse, NativeAdOptions())
    }

    /**
     * Start loading the native ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @param listener [NativeAdLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    @ApiInternal
    fun loadAd(
        adUnitId: String,
        readyResponse: String,
        options: NativeAdOptions,
        listener: NativeAdLoadListener
    ) {
        val coreAdRequestData = requestConfigurationConverter.convertToAdRequestData(
            adUnitId = adUnitId,
            options = options,
            readyResponse = readyResponse
        )
        val coreListener = YandexNativeAdLoadListenerAdapter(listener)
        adLoader.loadAd(coreAdRequestData, coreListener)
    }

    /**
     * Start loading the native ad on a background thread with ready response.
     *
     * @param adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
     * which is assigned in the Partner interface.
     * @param readyResponse Encoded response for ad request.
     * @param options Configuration options for native ad loading. Default options load images automatically.
     * @return [NativeAdLoadResult.Success] with [NativeAd] or [NativeAdLoadResult.Failure]
     * with [com.yandex.mobile.ads.common.AdRequestError].
     */
    @JvmSynthetic
    @ApiInternal
    suspend fun loadAd(
        adUnitId: String,
        readyResponse: String,
        options: NativeAdOptions
    ): NativeAdLoadResult {
        val coreAdRequestData = requestConfigurationConverter.convertToAdRequestData(
            adUnitId = adUnitId,
            options = options,
            readyResponse = readyResponse
        )
        val coreAdLoadResult = adLoader.loadAd(coreAdRequestData)
        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Cancel loading the native ad.
     */
    @ApiExternal
    fun cancelLoading() {
        adLoader.cancelLoading()
    }
}
