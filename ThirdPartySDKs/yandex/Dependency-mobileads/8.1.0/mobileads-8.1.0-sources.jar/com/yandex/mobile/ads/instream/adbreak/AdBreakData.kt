package com.yandex.mobile.ads.instream.adbreak

import com.yandex.mobile.ads.instream.InstreamAdBreakPosition
import com.yandex.mobile.ads.instream.InstreamAdBreakType

interface AdBreakData {

    /**
     * Provides ad break type. Allowed values see in [InstreamAdBreakType]
     *
     * @return Type of the ad break
     */
    val type: String

    /**
     * Provides [InstreamAdBreakPosition] object that represents content time offset
     *
     * @return Content time offset at which ad break is scheduled
     */
    val adBreakPosition: InstreamAdBreakPosition

    /**
     * Provides [AdBreakRequestData] object with the data about the request
     *
     * @return ad break request
     */
    val requestData: AdBreakRequestData
}
