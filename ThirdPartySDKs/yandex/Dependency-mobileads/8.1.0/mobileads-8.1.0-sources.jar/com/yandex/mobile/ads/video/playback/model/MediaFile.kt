package com.yandex.mobile.ads.video.playback.model

/**
 * This interface provides information for InstreamAdPlayer about instream ad media file
 */
interface MediaFile {

    /**
     * Gets url of Media file to be presented
     *
     * @return Url of instream ad media file
     */
    val url: String

    /**
     * Gets width of Media file to be presented
     *
     * @return Width of instream ad media file
     */
    val adWidth: Int

    /**
     * Gets height of Media file to be presented
     *
     * @return Height of instream ad media file
     */
    val adHeight: Int

    /**
     * Gets media type of Media file to be presented
     *
     * @return Type of instream ad media file
     */
    val mediaType: String?

    /**
     * Gets bitrate of Media file to be presented
     *
     * @return Bitrate of instream ad media file
     */
    val bitrate: Int?

    /**
     * Gets API framework of Media file to be presented
     *
     * @return API framework of instream ad media file
     */
    val apiFramework: String?
}
