package com.yandex.mobile.ads.common

/**
 * An AdRequest contains targeting information used to fetch an ad.
 * Ad requests are created using [Builder].
 *
 * @property adUnitId The AdUnit ID is a unique identifier in the R-M-XXXXXX-Y format,
 * which is assigned in the Partner interface.
 * @property targeting Targeting information for the ad request
 * @property parameters Custom request parameters
 * @property biddingData Open Bidding bid ID
 * @property preferredTheme User's preferred app theme
 */
class AdRequest private constructor(
    val adUnitId: String,
    val targeting: AdTargeting?,
    val parameters: Map<String, String>?,
    val biddingData: String?,
    val preferredTheme: AdTheme?
) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || javaClass != other.javaClass) return false
        val adRequest = other as AdRequest
        if (adUnitId != adRequest.adUnitId) return false
        if (targeting != adRequest.targeting) return false
        if (parameters != adRequest.parameters) return false
        if (biddingData != adRequest.biddingData) return false
        return preferredTheme == adRequest.preferredTheme
    }

    override fun hashCode(): Int {
        var result = adUnitId.hashCode()
        result = 31 * result + (targeting?.hashCode() ?: 0)
        result = 31 * result + (parameters?.hashCode() ?: 0)
        result = 31 * result + (biddingData?.hashCode() ?: 0)
        result = 31 * result + (preferredTheme?.hashCode() ?: 0)
        return result
    }

    /**
     * Builds an [AdRequest].
     */
    class Builder(private val adUnitId: String) {

        private var targeting: AdTargeting? = null
        private var parameters: Map<String, String>? = null
        private var biddingData: String? = null
        private var preferredTheme: AdTheme? = null

        /**
         * Constructs an [AdRequest] with the specified attributes.
         *
         * @return [AdRequest].
         */
        fun build(): AdRequest {
            return AdRequest(
                adUnitId = adUnitId,
                targeting = targeting,
                parameters = parameters,
                biddingData = biddingData,
                preferredTheme = preferredTheme
            )
        }

        /**
         * Sets targeting information for the ad request.
         *
         * @param targeting targeting information.
         * @return AdRequest.Builder with targeting.
         */
        fun setTargeting(targeting: AdTargeting?): Builder {
            this.targeting = targeting
            return this
        }

        /**
         * Sets custom parameters.
         *
         * @param parameters custom parameters.
         * @return AdRequest.Builder with custom parameters.
         */
        fun setParameters(parameters: Map<String, String>?): Builder {
            this.parameters = parameters
            return this
        }

        /**
         * Sets bid biddingData provided by mediation.
         *
         * @param biddingData bidding data for ad loading from mediation.
         * @return AdRequest.Builder with bid biddingData.
         */
        fun setBiddingData(biddingData: String?): Builder {
            this.biddingData = biddingData
            return this
        }

        /**
         * Sets preferred theme.
         *
         * @param preferredTheme preferred ad theme.
         * @return AdRequest.Builder with preferred theme.
         */
        fun setPreferredTheme(preferredTheme: AdTheme?): Builder {
            this.preferredTheme = preferredTheme
            return this
        }
    }
}
