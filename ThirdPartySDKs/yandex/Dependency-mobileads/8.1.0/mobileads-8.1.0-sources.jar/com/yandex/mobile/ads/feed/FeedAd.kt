package com.yandex.mobile.ads.feed

import android.content.Context
import com.monetization.ads.common.AdRequestData
import com.monetization.ads.feed.ui.FeedViewModel
import com.yandex.mobile.ads.common.AdRequest
import com.yandex.mobile.ads.common.YandexAdRequestConfigurationConverter
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.feed.adapter.FeedAdLoadListenerAdapter
import com.yandex.mobile.ads.feed.provider.FeedAdAppearanceParametersProvider

/**
 * Class allows to set [FeedAdLoadListener] and to preload feed.
 */
class FeedAd private constructor(
    private val viewModel: FeedViewModel
) : PrivateFeedAd() {

    /**
     * Register a callback for listening feed ads loading.
     */
    var loadListener: FeedAdLoadListener? = null
        set(value) {
            viewModel.feedAdLoadListener = FeedAdLoadListenerAdapter(value)
            field = value
        }

    /**
     * Preload feed ad.
     */
    fun preloadAd() {
        viewModel.preloadAd()
    }

    override fun getPrivateFeedViewModel(): FeedViewModel {
        return viewModel
    }

    /**
     * Class for creating new [FeedAd] object.
     *
     * @param context The context through which can be accessible the current theme, resources, etc.
     * @param adRequest Ad request with targeting information and custom parameters.
     * @param appearance Feed ad appearance configuration.
     */
    class Builder(
        private val context: Context,
        private val adRequest: AdRequest,
        private val appearance: FeedAdAppearance
    ) {

        private val adRequestConverter = YandexAdRequestConfigurationConverter()
        private val appearanceParametersProvider = FeedAdAppearanceParametersProvider()

        /**
         * Constructs a [FeedAd] with specified configurations.
         *
         * @return [FeedAd].
         */
        fun build(): FeedAd {
            val adRequestData = convertToAdRequestData(adRequest, appearance)
            val environmentModule = YandexSdkEnvironmentModule(context)
            val appContext = context.applicationContext
            val viewModel = FeedViewModel(appContext, environmentModule, adRequestData)
            return FeedAd(viewModel)
        }

        private fun convertToAdRequestData(
            adRequest: AdRequest,
            appearance: FeedAdAppearance
        ): AdRequestData {
            // Convert base AdRequest to AdRequestData using common converter
            val baseAdRequestData = adRequestConverter.convertToAdRequestData(adRequest)

            // Get appearance-specific parameters
            val appearanceParams = appearanceParametersProvider.getFeedAdAppearanceParameters(appearance)

            // Merge custom parameters from AdRequest with appearance parameters
            val mergedParameters = buildMap {
                baseAdRequestData.parameters?.let { putAll(it) }
                putAll(appearanceParams)
            }

            // Build final AdRequestData with merged parameters
            return AdRequestData.Builder(baseAdRequestData.adUnitId)
                .setAge(baseAdRequestData.age)
                .setGender(baseAdRequestData.gender)
                .setContextQuery(baseAdRequestData.contextQuery)
                .setContextTags(baseAdRequestData.contextTags)
                .setLocation(baseAdRequestData.location)
                .setParameters(mergedParameters)
                .setOpenBiddingData(baseAdRequestData.openBiddingData)
                .setReadyResponse(baseAdRequestData.readyResponse)
                .setPreferredTheme(baseAdRequestData.preferredTheme)
                .build()
        }
    }
}
