package com.yandex.mobile.ads.nativeads

import androidx.annotation.MainThread
import com.yandex.mobile.ads.common.AdBindingResult

/**
 * Interface allows to bind [NativeAdViewBinder] with slider content,
 */
@MainThread
interface SliderAd {

    /**
     * Ads which should be displayed in slider ad view.
     * Each ad view should be subview of slider ad view.
     *
     * @return [List].
     */
    val nativeAds: List<NativeAd>

    /**
     * Bind view with native ad&#39;s content.
     *
     * Returns [AdBindingResult.Success] if binding was successful, or
     * [AdBindingResult.Failure] if binding failed (e.g., a required asset view is missing).
     *
     * @param viewBinder An [NativeAdViewBinder] object.
     * @return [AdBindingResult] indicating success or failure.
     */
    fun bindSliderAd(viewBinder: NativeAdViewBinder): AdBindingResult
}
