package com.yandex.mobile.ads.instream.adbreak

import android.content.Context
import com.monetization.ads.base.utils.context.applicationContextOrThis
import com.monetization.ads.instream.loader.adbreak.InstreamAdBreakLoadingController
import com.yandex.mobile.ads.core.di.YandexSdkEnvironmentModule
import com.yandex.mobile.ads.instream.adapter.data.YandexInstreamAdBreakRequestConverter
import com.yandex.mobile.ads.instream.adapter.load.YandexInstreamAdBreakLoadListenerAdapter
import com.yandex.mobile.ads.instream.adbreak.converter.InstreamAdBreakLoadResultConverter

/**
 * This class can be used for loading instream ad break
 */
class InstreamAdBreakLoader(context: Context) : PrivateInstreamAdBreakLoader() {

    private val appContext = context.applicationContextOrThis

    private val sdkEnvironmentModule = YandexSdkEnvironmentModule(context)
    private val adLoadingController = InstreamAdBreakLoadingController(context, sdkEnvironmentModule)
    private val configurationConverter = YandexInstreamAdBreakRequestConverter()
    private val adLoadResultConverter = InstreamAdBreakLoadResultConverter(appContext)

    /**
     * Loads instream ad break object.
     *
     * @param configuration Request configuration
     * @param listener [InstreamAdBreakLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    fun loadAd(configuration: InstreamAdBreakRequest, listener: InstreamAdBreakLoadListener) {
        val requestConfig = configurationConverter.convert(configuration)
        val coreListener = YandexInstreamAdBreakLoadListenerAdapter(appContext, listener)
        adLoadingController.loadInstreamAd(requestConfig, coreListener)
    }

    /**
     * Loads instream ad break object. Suspends until the result is available.
     *
     * @param configuration Request configuration
     * @return [InstreamAdBreakLoadResult.Success] with [InstreamAdBreak]
     * or [InstreamAdBreakLoadResult.Failure] with [InstreamAdBreakRequestError].
     */
    @JvmSynthetic
    suspend fun loadAd(
        configuration: InstreamAdBreakRequest
    ): InstreamAdBreakLoadResult {
        val requestConfig = configurationConverter.convert(configuration)
        val coreAdLoadResult = adLoadingController.loadInstreamAd(requestConfig)

        return adLoadResultConverter.convert(coreAdLoadResult)
    }

    /**
     * Loads instream ad break object using vast url.
     *
     * @param configuration Request configuration
     * @param listener [InstreamAdBreakLoadListener] to be invoked when the ad is loaded or loading fails.
     */
    protected override fun privateLoadAd(
        configuration: InstreamAdBreakUrlRequest,
        listener: InstreamAdBreakLoadListener,
    ) {
        val requestConfig = configurationConverter.convert(configuration)
        val coreListener = YandexInstreamAdBreakLoadListenerAdapter(appContext, listener)
        adLoadingController.loadInstreamAd(requestConfig, coreListener)
    }

    /**
     * Cancel loading the instream ad break.
     */
    fun cancelLoading() {
        adLoadingController.cancelLoading()
    }
}
