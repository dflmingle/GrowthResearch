package io.appmetrica.analytics.impl.billing

import io.appmetrica.analytics.billinginterface.internal.BillingType
import io.appmetrica.analytics.coreutils.internal.logger.YLogger
import io.appmetrica.analytics.coreutils.internal.reflection.ReflectionUtils

private const val LOG_TAG = "[BillingTypeDetector]"

internal object BillingTypeDetector {

    @JvmStatic
    fun getBillingType(): BillingType {
        val version = try {
            ReflectionUtils
                .findClass("com.android.billingclient.BuildConfig")
                ?.getField("VERSION_NAME")
                ?.get(null) as String?
        } catch (e: Throwable) {
            YLogger.info(LOG_TAG, "Failed to get billing library version: $e")
            null
        }
        YLogger.info(LOG_TAG, "Billing library version: $version")

        return when {
            version.isNullOrBlank() -> BillingType.NONE
            version.startsWith("2.") -> BillingType.NONE
            version.startsWith("3.") -> BillingType.NONE
            version.startsWith("4.") -> BillingType.NONE
            version.startsWith("5.") -> BillingType.LIBRARY_V6
            version.startsWith("6.") -> BillingType.LIBRARY_V6
            else -> BillingType.LIBRARY_V6
        }
    }
}
