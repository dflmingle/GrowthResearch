/*
 * Copyright (c) 2020. Fyber N.V -  All Rights Reserved
 */

package com.fyber.inneractive.sdk.external;

/**
 * Spacial impression data static listener that publisher can implement under mediation
 * without having controller
 *
 */
public interface OnGlobalImpressionDataListener {
    void onImpression(String spotId, String unitId, ImpressionData impressionData);
}
