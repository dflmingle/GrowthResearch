/*
 * Copyright (c) 2020. Fyber N.V -  All Rights Reserved
 */

package com.fyber.inneractive.sdk.external;

/**
 * Error abstract super class
 */
public abstract class InneractiveError {

    /**
     * @return error full description
     */
    abstract public String description();
}
