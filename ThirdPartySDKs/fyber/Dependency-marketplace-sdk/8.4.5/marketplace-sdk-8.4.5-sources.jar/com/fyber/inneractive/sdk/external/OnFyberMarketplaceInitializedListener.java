/*
 * Copyright (c) 2020. Fyber N.V -  All Rights Reserved
 */

package com.fyber.inneractive.sdk.external;

/**
 * Initialized Listener use to update publisher on
 * VAMP sdk initialization successfully of not
 */
public interface OnFyberMarketplaceInitializedListener {
    public enum FyberInitStatus {
        SUCCESSFULLY,
        FAILED_NO_KITS_DETECTED,
        FAILED,
        INVALID_APP_ID
    }

    public void onFyberMarketplaceInitialized(FyberInitStatus status);
}
