/*
 * Copyright (c) 2020. Fyber N.V -  All Rights Reserved
 */

package com.fyber.inneractive.sdk.external;

/**
 * This class doesn't do anything. really.
 */
public class FyberStubClass {
    
    public void unused() {
    
    }
    
}
