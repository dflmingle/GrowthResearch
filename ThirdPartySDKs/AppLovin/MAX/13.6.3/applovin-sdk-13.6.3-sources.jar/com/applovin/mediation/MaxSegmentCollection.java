package com.applovin.mediation;

import com.applovin.impl.mediation.MaxSegmentCollectionImpl;

import java.util.List;

/**
 * This interface contains a collection of {@link MaxSegment} objects.
 */
public interface MaxSegmentCollection
{
    /**
     * @return a list of {@link MaxSegment} objects.
     */
    List<MaxSegment> getSegments();

    /**
     * Creates a builder object for {@link MaxSegmentCollection}.
     * Please call {@code build()} to create a {@link MaxSegmentCollection} object.
     *
     * @return a {@link MaxSegmentCollection.Builder} object.
     */
    static Builder builder()
    {
        return new MaxSegmentCollectionImpl.BuilderImpl();
    }

    /**
     * Builder class used to create a {@link MaxSegmentCollection} object.
     */
    interface Builder
    {
        /**
         * Adds a {@link MaxSegment} to the collection.
         *
         * @param segment The {@link MaxSegment} to add.
         */
        Builder addSegment(final MaxSegment segment);

        /**
         * Builds a {@link MaxSegmentCollection} object from the builder properties' values.
         *
         * @return a {@link MaxSegmentCollection} object.
         */
        MaxSegmentCollection build();
    }
}
