package com.applovin.mediation;

import com.applovin.impl.mediation.debugger.ui.axonevents.AxonEventsListActivity;

/**
 * @hide
 */
public final class MaxDebuggerAxonEventsListActivity
        extends AxonEventsListActivity
{
}
