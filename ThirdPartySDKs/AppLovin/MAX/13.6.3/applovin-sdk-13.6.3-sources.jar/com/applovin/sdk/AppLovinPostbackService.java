package com.applovin.sdk;

/**
 * @deprecated This API has been deprecated and will be removed in a future release.
 */
@Deprecated
public interface AppLovinPostbackService
{
    /**
     * @deprecated This API has been deprecated and will be removed in a future release.
     */
    @Deprecated
    void dispatchPostbackAsync(final String targetUrl, final AppLovinPostbackListener postbackListener);
}
