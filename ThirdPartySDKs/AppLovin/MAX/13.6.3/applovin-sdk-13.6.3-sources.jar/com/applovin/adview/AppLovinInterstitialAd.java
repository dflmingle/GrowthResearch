package com.applovin.adview;

import android.content.Context;

import com.applovin.impl.adview.InterstitialAdDialogWrapper;
import com.applovin.impl.sdk.CoreSdk;
import com.applovin.sdk.AppLovinSdk;

/**
 * Interstitial ads are full-screen or full-page ads that temporarily cover an app’s interface.
 * They’re typically shown at natural pauses or transition points—such as after completing a level in a game or when navigating between major views.
 */
public class AppLovinInterstitialAd
{
    /**
     * Create a new interstitial dialog that can be shown to the user. This is primarily useful in advanced integrations as the Ad Dialog allows finer control - including manually pre-caching and rendering ads. If all you want to do is show an interstitial the default way, you're looking for
     * <code>show()</code>.
     *
     * @return A new instance of {@link com.applovin.adview.AppLovinInterstitialAdDialog}.
     */
    public static AppLovinInterstitialAdDialog create()
    {
        return create( AppLovinSdk.getInstance( CoreSdk.getApplicationContext() ), CoreSdk.getApplicationContext() );
    }

    /**
     * @deprecated This API has been deprecated and will be removed in a future release. Please use {@link #create()} instead.
     */
    @Deprecated
    public static AppLovinInterstitialAdDialog create(final AppLovinSdk sdk, final Context context)
    {
        // Check input
        if ( sdk == null ) throw new IllegalArgumentException( "No sdk specified" );
        if ( context == null ) throw new IllegalArgumentException( "No context specified" );

        return new InterstitialAdDialogWrapper( sdk, context );
    }

    @Override
    public String toString()
    {
        return "AppLovinInterstitialAd{}";
    }
}
