package com.applovin.adview;

public class AppLovinFullscreenImmersiveActivity
        extends AppLovinFullscreenActivity
{ }
