package com.applovin.sdk;

import androidx.annotation.Nullable;

/**
 * Contains user identity data to attach to Axon events and ad requests.
 *
 * Set plaintext values when available — the SDK normalizes and hashes PII fields internally before transmission.
 * Email and phone are SHA-256 hashed; pre-hashed normalized SHA-256 hex values are also accepted.
 * userId is sent as plaintext — do not include PII.
 */
public class AppLovinUserData
{
    /**
     * The user's email address in plaintext (e.g. "User@Example.com").
     * The SDK trims whitespace, lowercases, and SHA-256 hashes the value before sending.
     * Plaintext is preferred; normalized SHA-256 hex is also accepted.
     */
    @Nullable
    private String email;

    /**
     * The user's phone number in plaintext (e.g. "+1 (234) 567-8900").
     * The SDK strips non-digit characters and SHA-256 hashes the value before sending.
     * Plaintext is preferred; normalized SHA-256 hex is also accepted.
     */
    @Nullable
    private String phone;

    /**
     * An internal user ID that identifies the user within the advertiser's system.
     * Sent as plaintext — do not include PII.
     */
    @Nullable
    private String userId;

    @Nullable
    public String getEmail() { return email; }

    public void setEmail(@Nullable final String email) { this.email = email; }

    @Nullable
    public String getPhone() { return phone; }

    public void setPhone(@Nullable final String phone) { this.phone = phone; }

    @Nullable
    public String getUserId() { return userId; }

    public void setUserId(@Nullable final String userId) { this.userId = userId; }
}
