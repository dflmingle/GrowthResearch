package com.unity3d.services.ads.gmascar.managers;

import com.unity3d.ads.IUnityAdsTokenListener;
import com.unity3d.services.ads.gmascar.utils.IScarAdFormatProvider;

public class BiddingEagerManager extends BiddingBaseManager {

	public BiddingEagerManager(IScarAdFormatProvider scarAdFormatProvider, IUnityAdsTokenListener unityAdsTokenListener) {
		super(scarAdFormatProvider, unityAdsTokenListener);
	}

	@Override
	public void start() {
		permitSignalsUpload();
		fetchSignals();
	}
}
