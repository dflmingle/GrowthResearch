package com.unity3d.services.ads.offerwall

enum class OfferwallEvent {
    REQUEST_SUCCESS,
    REQUEST_FAILED,
    ON_CONTENT_READY,
    ON_CONTENT_SHOW,
    ON_CONTENT_DISMISS,
    SHOW_FAILED,
}