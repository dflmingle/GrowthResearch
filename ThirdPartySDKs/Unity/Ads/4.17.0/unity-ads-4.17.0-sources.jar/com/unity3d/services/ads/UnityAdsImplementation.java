package com.unity3d.services.ads;

import static com.unity3d.ads.UnityAdsErrorKt.MSG_BOLD_LOAD_FAIL_NO_FILL;
import static com.unity3d.ads.UnityAdsErrorKt.MSG_BOLD_LOAD_FAIL_SDK_NOT_INITIALIZED;
import static com.unity3d.ads.UnityAdsErrorKt.MSG_BOLD_LOAD_FAIL_TIME_OUT;
import static com.unity3d.ads.core.data.model.LoadResult.MSG_NOT_INITIALIZED;
import static com.unity3d.ads.core.data.model.LoadResult.MSG_PLACEMENT_NULL;
import static com.unity3d.services.core.misc.Utilities.wrapCustomerListener;

import static kotlin.jvm.JvmClassMappingKt.getKotlinClass;

import android.app.Activity;
import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.OptIn;

import com.google.protobuf.ByteString;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.IUnityAdsTokenListener;
import com.unity3d.ads.TokenConfiguration;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsError;
import com.unity3d.ads.UnityAdsExperimental;
import com.unity3d.ads.UnityAdsLoadOptions;
import com.unity3d.ads.UnityAdsShowOptions;
import com.unity3d.ads.core.configuration.AlternativeFlowReader;
import com.unity3d.ads.core.data.model.AdObject;
import com.unity3d.ads.core.configuration.ForceAlternativeFlow;
import com.unity3d.ads.core.data.model.Listeners;
import com.unity3d.ads.core.data.repository.AdRepository;
import com.unity3d.ads.core.domain.InternalLoadListener;
import com.unity3d.services.UnityAdsSDK;
import com.unity3d.services.UnityServices;
import com.unity3d.services.ads.gmascar.managers.BiddingBaseManager;
import com.unity3d.services.ads.gmascar.managers.BiddingManagerFactory;
import com.unity3d.services.ads.operation.load.LoadModule;
import com.unity3d.services.ads.operation.load.LoadOperationState;
import com.unity3d.services.ads.operation.show.ShowModule;
import com.unity3d.services.ads.operation.show.ShowOperationState;
import com.unity3d.services.ads.token.AsyncTokenStorage;
import com.unity3d.services.ads.token.TokenStorage;
import com.unity3d.services.core.configuration.Configuration;
import com.unity3d.services.core.configuration.ConfigurationReader;
import com.unity3d.services.core.di.ServiceKey;
import com.unity3d.services.core.di.ServiceProvider;
import com.unity3d.services.core.log.DeviceLog;
import com.unity3d.services.core.misc.Utilities;
import com.unity3d.services.core.properties.ClientProperties;
import com.unity3d.services.core.request.metrics.AdOperationMetric;
import com.unity3d.services.core.request.metrics.SDKMetricsSender;
import com.unity3d.services.core.webview.WebViewApp;
import com.unity3d.services.core.webview.bridge.WebViewBridgeInvoker;
import org.jetbrains.annotations.NotNull;

import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode;

public final class UnityAdsImplementation implements IUnityAds {
	private static Configuration configuration = null;
	private static final WebViewBridgeInvoker webViewBridgeInvoker = new WebViewBridgeInvoker();
	private static IUnityAds instance;

	public static IUnityAds getInstance() {
		if (instance == null) {
			instance = new UnityAdsImplementation();
		}
		return instance;
	}

	/**
	 * Initializes Unity Ads. Unity Ads should be initialized when app starts.
	 *
	 * @param context Current Android application context of calling app
	 * @param gameId Unique identifier for a game, given by Unity Ads admin tools or Unity editor
	 * @param testMode If true, only test ads are shown
	 * @param initializationListener Listener for IUnityAdsInitializationListener callbacks
	 */
	@Override
	public void initialize(final Context context, final String gameId, final boolean testMode, final IUnityAdsInitializationListener initializationListener) {
		DeviceLog.entered();
		if (hasInvalidContext(context)) {
			DeviceLog.error("Error while initializing Unity Services: null context, halting Unity Ads init");
			if (initializationListener != null) {
				wrapCustomerListener(() -> initializationListener.onInitializationFailed(UnityAds.UnityAdsInitializationError.INVALID_ARGUMENT, "Unity Ads SDK failed to initialize due to invalid context"));
			}
			return;
		}
		UnityServices.initialize(context, gameId, testMode, null, initializationListener);
	}

	/**
	 * Checks if Unity Ads has been initialized. This might be useful for debugging initialization problems.
	 *
	 * @return If true, Unity Ads has been successfully initialized
	 */
	@Override
	public boolean isInitialized() {
		return UnityServices.isInitialized();
	}

	/**
	 * Checks if current device supports running Unity Ads
	 *
	 * @return If true, device supports Unity Ads. If false, device can't initialize or show Unity Ads.
	 */
	@Override
	public boolean isSupported() {
		return UnityServices.isSupported();
	}

	/**
	 * Get current SDK version
	 *
	 * @return Current SDK version name
	 */
	@Override
	public String getVersion() {
		return UnityServices.getVersion();
	}

	/**
	 * Show one advertisement with custom placement.
	 *
	 * @param activity    Current Android activity of calling app
	 * @param placementId Placement, as defined in Unity Ads admin tools
	 */
	public void show(final Activity activity, final String placementId) {
		show(activity, placementId, new UnityAdsShowOptions(), null);
	}

	/**
	 * Show one advertisement with custom placement.
	 *
	 * @param activity     Current Android activity of calling app
	 * @param placementId  Placement, as defined in Unity Ads admin tools
	 * @param showListener Listener for IUnityAdsShowListener callbacks
	 */
	public void show(final Activity activity, final String placementId, final IUnityAdsShowListener showListener) {
		show(activity, placementId, new UnityAdsShowOptions(), showListener);
	}

	/**
	 * Show one advertisement with custom placement and custom options.
	 *
	 * @param activity     Current Android activity of calling app
	 * @param placementId  Placement, as defined in Unity Ads admin tools
	 * @param showOptions  Custom options
	 * @param showListener Listener for IUnityAdsShowListener callbacks
	 */
	@Override
	public void show(@Nullable final Activity activity, @Nullable final String placementId, @Nullable final UnityAdsShowOptions showOptions, @Nullable final IUnityAdsShowListener showListener) {
		if (activity == null || hasInvalidContext(activity)) {
			String showErrorMessage = "Activity must not be null";
			handleShowError(showListener, placementId, UnityAds.UnityAdsShowError.INVALID_ARGUMENT, showErrorMessage);
			return;
		}
		ClientProperties.setActivity(activity);
		final AlternativeFlowReader alternativeFlowReader = Utilities.getService(AlternativeFlowReader.class);
		if (alternativeFlowReader.invoke()) {
			new UnityAdsSDK().show(placementId, showOptions, new Listeners() {
				@Override
				public void onLeftApplication(@NotNull String placementId) {
					// no-op
				}

				@Override
				public void onError(@NotNull String placementId, @NotNull UnityAds.UnityAdsShowError error, @NotNull String message) {
					if (showListener != null) {
						showListener.onUnityAdsShowFailure(placementId, error, message);
					}
				}

				@Override
				public void onStart(@NotNull String placementId) {
					if (showListener != null) {
						showListener.onUnityAdsShowStart(placementId);
					}
				}

				@Override
				public void onClick(@NotNull String placementId) {
					if (showListener != null) {
						showListener.onUnityAdsShowClick(placementId);
					}
				}

				@Override
				public void onRewarded(@NotNull String placementId) {
					// no-op for now - only supported by new public api
				}

				@Override
				public void onComplete(@NotNull String placementId, @NotNull UnityAds.UnityAdsShowCompletionState state) {
					if (showListener != null) {
						showListener.onUnityAdsShowComplete(placementId, state);
					}
				}
			});
		} else {
			if (!isSupported()) {
				String showErrorMessage = "Unity Ads is not supported for this device";
				handleShowError(showListener, placementId, UnityAds.UnityAdsShowError.NOT_INITIALIZED, showErrorMessage);
				return;
			}
			if (!isInitialized()) {
				handleShowError(showListener, placementId, UnityAds.UnityAdsShowError.NOT_INITIALIZED, MSG_NOT_INITIALIZED);
				return;
			}
			if (activity == null) {
				String showErrorMessage = "Activity must not be null";
				handleShowError(showListener, placementId, UnityAds.UnityAdsShowError.INVALID_ARGUMENT, showErrorMessage);
				return;
			}
			if (placementId == null) {
				handleShowError(showListener, "", UnityAds.UnityAdsShowError.INVALID_ARGUMENT, MSG_PLACEMENT_NULL);
				return;
			}

			Configuration config = configuration == null ? new Configuration() : configuration;
			ShowModule.getInstance().executeAdOperation(WebViewApp.getCurrentApp(), new ShowOperationState(placementId, showListener, activity, showOptions, config));
		}
	}

	private void handleShowError(IUnityAdsShowListener showListener, String placementId, UnityAds.UnityAdsShowError error, String message) {
		final SDKMetricsSender sdkMetricsSender = Utilities.getService(SDKMetricsSender.class);
		sdkMetricsSender.sendMetricWithInitState(AdOperationMetric.newAdShowFailure(error, 0L));
		if (showListener == null) return;
		showListener.onUnityAdsShowFailure(placementId, error, message);
	}

	/**
	 * Toggles debug mode on/off
	 *
	 * @param debugMode If true, debug mode is on and there will be lots of debug output from Unity Ads. If false, there will be only some short log messages from Unity Ads.
	 */
	@Override
	public void setDebugMode(boolean debugMode) {
		UnityServices.setDebugMode(debugMode);
	}

	/**
	 * Get current debug mode status
	 *
	 * @return If true, debug mode is on. If false, debug mode is off.
	 */
	@Override
	public boolean getDebugMode() {
		return UnityServices.getDebugMode();
	}

	@Override
	public void load(@Nullable final String placementId, @NonNull final UnityAdsLoadOptions loadOptions, @Nullable final IUnityAdsLoadListener listener) {
		if (hasInvalidContext()) {
			DeviceLog.error("No valid Context for loading ads");
			if (listener != null) {
				wrapCustomerListener(() -> listener.onUnityAdsFailedToLoad(placementId, UnityAds.UnityAdsLoadError.INVALID_ARGUMENT, "Unity Ads SDK failed to load due to invalid context"));
			}
			return;
		}
		final ForceAlternativeFlow forceAlternativeFlow = Utilities.getService(ForceAlternativeFlow.class);
		if (loadOptions.loadConfiguration != null) {
			// LoadConfigurationInternal is only set in new Public API
			forceAlternativeFlow.invoke(true);
		}
		final AlternativeFlowReader alternativeFlowReader = Utilities.getService(AlternativeFlowReader.class);
		if (alternativeFlowReader.invoke()) {
			InternalLoadListener wrappedListener = null;
			if (listener != null) {
				wrappedListener = new InternalLoadListener() {
					@Override
					public void onAdLoaded(@NonNull AdObject adObject) {
						listener.onUnityAdsAdLoaded(placementId);
					}

					@Override
					@OptIn(markerClass = UnityAdsExperimental.class)
					public void onAdLoadFail(@NonNull UnityAdsError error) {
						PublicErrorCode errorCode = PublicErrorCode.forNumber(error.getCode());
						UnityAds.UnityAdsLoadError loadError = UnityAds.UnityAdsLoadError.INTERNAL_ERROR;
						if(errorCode != null) {
							switch (errorCode) {
								case PUBLIC_ERROR_CODE_LOAD_NO_FILL:
									loadError = UnityAds.UnityAdsLoadError.NO_FILL;
									break;
								case PUBLIC_ERROR_CODE_TIMEOUT:
									loadError = UnityAds.UnityAdsLoadError.TIMEOUT;
									break;
								case PUBLIC_ERROR_CODE_LOAD_NOT_INITIALIZED:
									loadError = UnityAds.UnityAdsLoadError.INITIALIZE_FAILED;
									break;
								default:
									break;
							}
						}

						listener.onUnityAdsFailedToLoad(placementId,
							loadError,
							error.getMessage());
					}
				};
			}
			new UnityAdsSDK().load(placementId, loadOptions, wrappedListener, null);
		} else {
			Configuration config = configuration == null ? new Configuration() : configuration;
			LoadModule.getInstance().executeAdOperation(webViewBridgeInvoker, new LoadOperationState(placementId, listener, loadOptions, config));
		}
	}

	@Override
	@OptIn(markerClass = UnityAdsExperimental.class)
	public void load(@Nullable final String placementId, @NonNull final UnityAdsLoadOptions loadOptions, @NonNull final InternalLoadListener listener) {
		if (hasInvalidContext()) {
			DeviceLog.error("No valid Context for loading ads");
			wrapCustomerListener(() -> listener.onAdLoadFail(
					new UnityAdsError(
						PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_NOT_INITIALIZED.getNumber(),
						MSG_BOLD_LOAD_FAIL_SDK_NOT_INITIALIZED)
				)
			);
			return;
		}

		new UnityAdsSDK().load(placementId, loadOptions, listener, null);
	}

	@Override
	public @Nullable String getToken() {
		if (hasInvalidContext()) {
			DeviceLog.error("No valid Context for getting token");
			return null;
		}
		final AlternativeFlowReader alternativeFlowReader = Utilities.getService(AlternativeFlowReader.class);
		if (alternativeFlowReader.invoke()) {
			return new UnityAdsSDK().getToken();
		} else {
			final TokenStorage tokenStorage = Utilities.getService(TokenStorage.class);
			// Getting the available token from storage
			final String token = tokenStorage.getToken();
			if (token == null || token.isEmpty()) {
				return null;
			}

			Configuration config = configuration == null ? new ConfigurationReader().getCurrentConfiguration() : configuration;
			BiddingBaseManager manager = BiddingManagerFactory.getInstance().createManager(null, config.getExperiments());
			manager.start();
			return manager.getFormattedToken(token);
		}
	}

	@Override
	public void getToken(final @Nullable TokenConfiguration tokenConfiguration, final @Nullable IUnityAdsTokenListener listener) {
		// TODO: Once we only support new public API, we should run all of this under the tokenScope.
		if (hasInvalidContext()) {
			DeviceLog.error("No valid Context for getting token");
			if (listener != null) {
				listener.onUnityAdsTokenReady(null);
			}
			return;
		}

		if (tokenConfiguration != null) {
			final ForceAlternativeFlow forceAlternativeFlow = Utilities.getService(ForceAlternativeFlow.class);
			forceAlternativeFlow.invoke(tokenConfiguration.isNewApi());
		}

		final AlternativeFlowReader alternativeFlowReader = Utilities.getService(AlternativeFlowReader.class);
		if (alternativeFlowReader.invoke()) {
			new UnityAdsSDK().getToken(tokenConfiguration, listener);
		} else {
			if (listener == null) {
				// Invalidating listener
				DeviceLog.info("Please provide non-null listener to UnityAds.GetToken method");
				return;
			} else if (ClientProperties.getApplicationContext() == null) {
				// Invalidating app Context.
				wrapCustomerListener(() ->
					listener.onUnityAdsTokenReady(null));
				return;
			}
			final AsyncTokenStorage asyncTokenStorage = Utilities.getService(AsyncTokenStorage.class);
			Configuration config = configuration == null ? new ConfigurationReader().getCurrentConfiguration() : configuration;
			BiddingBaseManager manager = BiddingManagerFactory.getInstance().createManager(listener, tokenConfiguration, config.getExperiments());
			manager.start();

			asyncTokenStorage.getToken(manager);
		}
	}

	@Override
	public void getToken(final @Nullable IUnityAdsTokenListener listener) {
		getToken(null, listener);
	}

	public static void setConfiguration(Configuration configuration) {
		UnityAdsImplementation.configuration = configuration;
	}

	private boolean hasInvalidContext(Context context) {
		if (ClientProperties.getApplicationContext() != null) {
			return false;
		}

		if (context == null) {
			return true;
		}

		if (context instanceof Application) {
			Application application = (Application) context;
			ClientProperties.setApplicationContext(context);
			ClientProperties.setApplication(application);
			return false;
		}

		if (context instanceof Activity) {
			Activity activity = (Activity) context;
			if (activity.getApplication() != null && activity.getApplicationContext() != null) {
				ClientProperties.setApplicationContext(context.getApplicationContext());
				ClientProperties.setApplication(activity.getApplication());
				return false;
			}
			return true;
		}

		return true;
	}

	private boolean hasInvalidContext() {
		return hasInvalidContext(null);
	}
}
