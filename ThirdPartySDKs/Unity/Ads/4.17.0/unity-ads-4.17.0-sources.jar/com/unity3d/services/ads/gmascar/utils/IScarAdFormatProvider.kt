package com.unity3d.services.ads.gmascar.utils

import com.unity3d.scar.adapter.common.scarads.UnityAdFormat

fun interface IScarAdFormatProvider {
    fun buildAdFormatList(): List<UnityAdFormat>
}