package com.unity3d.ads

@UnityAdsExperimental
sealed interface ShowListener<UnityAd> {
   fun onStarted(unityAd: UnityAd)
   fun onClicked(unityAd: UnityAd)
   fun onCompleted(unityAd: UnityAd, state: ShowFinishState)
   fun onFailed(unityAd: UnityAd, error: UnityAdsError)
}

@UnityAdsExperimental
interface InterstitialShowListener : ShowListener<InterstitialAd>

@UnityAdsExperimental
interface RewardedShowListener : ShowListener<RewardedAd> {
    fun onRewarded(rewardedAd: RewardedAd)
}