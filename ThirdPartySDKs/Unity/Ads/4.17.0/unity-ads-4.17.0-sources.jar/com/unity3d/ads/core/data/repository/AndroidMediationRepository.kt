package com.unity3d.ads.core.data.repository

import com.unity3d.ads.core.data.datasource.MediationDataSource
import com.unity3d.ads.core.domain.MediationProviderParser
import gatewayprotocol.v1.ClientInfoOuterClass

class AndroidMediationRepository(
    private val mediationDataSource: MediationDataSource,
    private val mediationProviderParser: MediationProviderParser,
) : MediationRepository {
    override val name: String?
        get() = mediationDataSource.name
    override val version: String?
        get() = mediationDataSource.version
    override val mediationProvider: () -> ClientInfoOuterClass.MediationProvider
        get() = { mediationProviderParser(name) }
}