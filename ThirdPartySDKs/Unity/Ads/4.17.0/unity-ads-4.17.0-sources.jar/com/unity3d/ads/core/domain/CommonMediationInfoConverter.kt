package com.unity3d.ads.core.domain

import com.unity3d.ads.MediationInfo
import com.unity3d.ads.UnityAdsExperimental
import gatewayprotocol.v1.ClientInfoOuterClass.MediationProvider
import gatewayprotocol.v1.MediationInfoOuterClass
import gatewayprotocol.v1.mediationInfo

@OptIn(UnityAdsExperimental::class)
class CommonMediationInfoConverter(
    private val mediationProviderParser: MediationProviderParser
) : MediationInfoConverter {
    override fun invoke(mediationInfoData: MediationInfo): MediationInfoOuterClass.MediationInfo {
        val mediationProvider = mediationProviderParser(mediationInfoData.name)
        return mediationInfo {
            provider = mediationProvider
            if (mediationProvider == MediationProvider.MEDIATION_PROVIDER_CUSTOM) {
                customName = mediationInfoData.name
            }
            version = mediationInfoData.version
            adapterVersion = mediationInfoData.adapterVersion
        }
    }
}