package com.unity3d.ads.core.domain

import com.unity3d.ads.MediationInfo
import com.unity3d.ads.UnityAdsExperimental
import gatewayprotocol.v1.MediationInfoOuterClass

@OptIn(UnityAdsExperimental::class)
fun interface MediationInfoConverter {
    operator fun invoke(mediationInfoData: MediationInfo): MediationInfoOuterClass.MediationInfo
}