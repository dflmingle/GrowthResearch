package com.unity3d.ads.core.domain

import com.unity3d.services.core.network.model.HttpResponse
import com.unity3d.services.core.network.model.RequestType

interface ExecuteAdViewerRequest {
    suspend operator fun invoke(type: RequestType, parameters: Array<Any>): HttpResponse
}