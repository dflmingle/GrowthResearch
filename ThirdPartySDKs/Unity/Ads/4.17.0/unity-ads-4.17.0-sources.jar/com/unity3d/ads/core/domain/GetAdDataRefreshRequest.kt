package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

interface GetAdDataRefreshRequest {
    suspend operator fun invoke(opportunityId: ByteString, refreshToken: ByteString): UniversalRequest
}