package com.unity3d.ads.core.data.datasource

import gatewayprotocol.v1.DeveloperConsentOuterClass

interface DeveloperConsentDataSource {
    val developerConsent: DeveloperConsentOuterClass.DeveloperConsent
}