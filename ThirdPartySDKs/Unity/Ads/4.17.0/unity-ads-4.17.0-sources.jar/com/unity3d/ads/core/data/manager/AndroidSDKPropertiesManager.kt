package com.unity3d.ads.core.data.manager

import com.unity3d.services.core.device.Device
import com.unity3d.services.core.properties.SdkProperties


typealias LegacySdkProperties = SdkProperties


class AndroidSDKPropertiesManager : SDKPropertiesManager {
    override fun setInitialized(initialized: Boolean) = LegacySdkProperties.setInitialized(initialized)
    override fun setInitializeState(initializeState: SdkProperties.InitializationState) = LegacySdkProperties.setInitializeState(initializeState)
    override fun getCurrentInitializationState(): SdkProperties.InitializationState = LegacySdkProperties.getCurrentInitializationState()
    override fun setInitializationTime() = LegacySdkProperties.setInitializationTime(Device.getElapsedRealtime())
    override fun setInitializationTimeSinceEpoch() = LegacySdkProperties.setInitializationTimeSinceEpoch(System.currentTimeMillis())
}