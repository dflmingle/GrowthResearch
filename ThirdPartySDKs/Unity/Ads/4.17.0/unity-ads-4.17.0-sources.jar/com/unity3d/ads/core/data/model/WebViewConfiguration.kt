package com.unity3d.ads.core.data.model

data class WebViewConfiguration(
    val version: Int,
    val entryPoint: String,
    val additionalFiles: List<String>,
    val type: String,
)