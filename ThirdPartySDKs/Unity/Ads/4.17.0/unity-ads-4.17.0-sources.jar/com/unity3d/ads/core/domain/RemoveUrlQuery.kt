package com.unity3d.ads.core.domain

interface RemoveUrlQuery {
    operator fun invoke(url: String): String?
}