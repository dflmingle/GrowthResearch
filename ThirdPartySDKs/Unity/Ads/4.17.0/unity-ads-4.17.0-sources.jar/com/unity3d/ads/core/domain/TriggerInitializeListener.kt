package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.exception.InitializationException
import com.unity3d.services.core.properties.SdkProperties
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch


internal class TriggerInitializeListener(
    private val coroutineDispatcher: CoroutineDispatcher
) {
    fun success() {
        CoroutineScope(coroutineDispatcher).launch {
            SdkProperties.notifyInitializationComplete()
        }
    }

    fun error(e: InitializationException) {
        CoroutineScope(coroutineDispatcher).launch {
            SdkProperties.notifyInitializationFailed(e)
        }
    }
}