package com.unity3d.ads

@UnityAdsExperimental
fun interface InitializationListener {
    fun onInitializationComplete(error: UnityAdsError?)
}