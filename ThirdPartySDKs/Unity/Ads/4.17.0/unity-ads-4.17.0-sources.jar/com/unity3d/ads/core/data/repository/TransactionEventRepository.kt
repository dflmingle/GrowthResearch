package com.unity3d.ads.core.data.repository

import gatewayprotocol.v1.TransactionEventRequestOuterClass
import kotlinx.coroutines.flow.SharedFlow

interface TransactionEventRepository {
    val transactionEvents: SharedFlow<TransactionEventRequestOuterClass.TransactionEventRequest>
    fun addTransactionEvent(transactionEventRequest: TransactionEventRequestOuterClass.TransactionEventRequest)
}