package com.unity3d.ads

class TokenConfiguration @JvmOverloads constructor(
    val adFormat: AdFormat,
    val extras: Map<String, String> = emptyMap()
) {
    @UnityAdsExperimental
    private var _mediationInfo: MediationInfo? = null

    private var _placementId: String? = null

    @UnityAdsExperimental
    private var _bannerSize: BannerSize? = null

    private var _mediationAdUnitId: String? = null

    private var _isNewApi: Boolean = false

    @UnityAdsExperimental
    val mediationInfo: MediationInfo?
        get() = _mediationInfo

    val placementId: String?
        get() = _placementId

    @UnityAdsExperimental
    val bannerSize: BannerSize?
        get() = _bannerSize

    val mediationAdUnitId: String?
        get() = _mediationAdUnitId

    val isNewApi: Boolean
        get() = _isNewApi


    @UnityAdsExperimental
    private constructor(
        adFormat: AdFormat,
        mediationInfo: MediationInfo? = null,
        placementId: String? = null,
        bannerSize: BannerSize? = null,
        mediationAdUnitId: String? = null,
        extras: Map<String, String> = emptyMap(),
        isNewApi: Boolean = false
    ) : this(adFormat, extras) {
        this._mediationInfo = mediationInfo
        this._placementId = placementId
        this._bannerSize = bannerSize
        this._mediationAdUnitId = mediationAdUnitId
        this._isNewApi = isNewApi
    }

    @UnityAdsExperimental
    class Builder(private val adFormat: AdFormat) {
        private var mediationInfo: MediationInfo? = null
        private var placementId: String? = null
        private var bannerSize: BannerSize? = null
        private var mediationAdUnitId: String? = null
        private var extras: Map<String, String> = emptyMap()

        fun withMediationInfo(mediationInfo: MediationInfo?): Builder {
            this.mediationInfo = mediationInfo
            return this
        }

        fun withPlacementId(placementId: String?): Builder {
            this.placementId = placementId
            return this
        }

        fun withBannerSize(bannerSize: BannerSize?): Builder {
            this.bannerSize = bannerSize
            return this
        }

        fun withMediationAdUnitId(mediationAdUnitId: String?): Builder {
            this.mediationAdUnitId = mediationAdUnitId
            return this
        }

        fun withExtras(extras: Map<String, String>): Builder {
            this.extras = extras
            return this
        }

        fun build(): TokenConfiguration {
            return TokenConfiguration(
                adFormat = adFormat,
                mediationInfo = mediationInfo,
                placementId = placementId,
                bannerSize = bannerSize,
                mediationAdUnitId = mediationAdUnitId,
                extras = extras,
                isNewApi = true
            )
        }
    }
}
