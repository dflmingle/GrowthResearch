package com.unity3d.ads.core.domain

import android.content.Context
import com.google.protobuf.ByteString
import com.unity3d.ads.UnityAdsLoadOptions
import com.unity3d.ads.core.data.model.LoadResult
import gatewayprotocol.v1.AdResponseOuterClass.AdResponse

interface HandleGatewayAdResponse {
    suspend operator fun invoke(
        loadOptions: UnityAdsLoadOptions,
        opportunityId: ByteString,
        response: AdResponse,
        context: Context,
        placementId: String,
        adType: gatewayprotocol.v1.DiagnosticEventRequestOuterClass.DiagnosticAdType,
        isHeaderBidding: Boolean
    ) : LoadResult
}