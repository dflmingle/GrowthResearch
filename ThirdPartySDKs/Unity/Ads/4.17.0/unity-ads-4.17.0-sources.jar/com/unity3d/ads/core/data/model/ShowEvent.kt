package com.unity3d.ads.core.data.model

import com.unity3d.ads.adplayer.model.ShowStatus

sealed class ShowEvent {
    object Started : ShowEvent()
    object Clicked : ShowEvent()
    object ReceivedReward : ShowEvent()
    object CancelTimeout : ShowEvent()
    data class Completed(val status: ShowStatus, val reason: String? = null, val reasonDebug: String? = null) : ShowEvent()
    data class Error(val message: String, val errorCode: Int, val reason: String) : ShowEvent()
    object LeftApplication : ShowEvent()
}
