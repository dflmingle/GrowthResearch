package com.unity3d.ads.core.data.repository

import com.unity3d.ads.core.data.datasource.TcfDataSource

class AndroidTcfRepository(
    val tcfDataSource: TcfDataSource
) : TcfRepository {
    override val tcfString: String?
        get() = tcfDataSource.tcfString
}