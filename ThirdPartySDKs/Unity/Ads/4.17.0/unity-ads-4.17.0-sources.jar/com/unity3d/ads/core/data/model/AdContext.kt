package com.unity3d.ads.core.data.model

@JvmInline
value class AdData(val data: String)

@JvmInline
value class AdDataRefreshToken(val data: String)

@JvmInline
value class ImpressionConfig(val data: String)