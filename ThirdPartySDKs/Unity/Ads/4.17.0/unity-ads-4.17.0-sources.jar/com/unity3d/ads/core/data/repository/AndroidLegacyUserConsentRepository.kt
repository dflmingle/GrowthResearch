package com.unity3d.ads.core.data.repository

import com.unity3d.ads.core.data.datasource.LegacyUserConsentDataSource



class AndroidLegacyUserConsentRepository(private val legacyUserConsentDataSource: LegacyUserConsentDataSource) : LegacyUserConsentRepository {
    override val legacyFlowUserConsent: String?
        get() = legacyUserConsentDataSource.privacyData
}