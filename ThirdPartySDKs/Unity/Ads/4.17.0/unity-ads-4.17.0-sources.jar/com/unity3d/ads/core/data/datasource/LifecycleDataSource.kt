package com.unity3d.ads.core.data.datasource

import kotlinx.coroutines.flow.StateFlow

interface LifecycleDataSource {
    val appActive: StateFlow<Boolean>
    fun appIsForeground(): Boolean
}