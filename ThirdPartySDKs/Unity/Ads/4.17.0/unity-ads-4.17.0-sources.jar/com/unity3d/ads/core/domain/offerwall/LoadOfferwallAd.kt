package com.unity3d.ads.core.domain.offerwall

import com.unity3d.ads.core.data.manager.OfferwallManager

class LoadOfferwallAd(private val offerwallManager: OfferwallManager) {
    suspend operator fun invoke(
        placementName: String
    ) {
        offerwallManager.loadAd(
            placementName = placementName,
        )
    }
}