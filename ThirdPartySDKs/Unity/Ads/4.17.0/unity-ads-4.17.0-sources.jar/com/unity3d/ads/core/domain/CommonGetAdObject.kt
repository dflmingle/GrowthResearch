package com.unity3d.ads.core.domain

import com.google.protobuf.kotlin.toByteStringUtf8
import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.repository.AdRepository


@Deprecated("Should use directly AdRepository.getAd()", ReplaceWith("adRepository.getAd(UUID.fromString(opportunityId).toByteString()"))
class CommonGetAdObject(private val adRepository: AdRepository) : GetAdObject {
    override fun invoke(opportunityId: String): AdObject? {
        return adRepository.getAd(opportunityId.toByteStringUtf8())
    }
}