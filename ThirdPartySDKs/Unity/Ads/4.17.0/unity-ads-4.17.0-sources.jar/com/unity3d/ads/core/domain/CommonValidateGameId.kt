package com.unity3d.ads.core.domain

class CommonValidateGameId(
    private val getGameId: GetGameId,
    private val setGameId: SetGameId
) : ValidateGameId {
    override fun invoke(gameId: String?): Boolean {
        val currentGameId = getGameId()

        if (currentGameId != null) {
            return true
        }

        if (gameId == null) {
            return false
        }

        setGameId(gameId)
        return true
    }
}