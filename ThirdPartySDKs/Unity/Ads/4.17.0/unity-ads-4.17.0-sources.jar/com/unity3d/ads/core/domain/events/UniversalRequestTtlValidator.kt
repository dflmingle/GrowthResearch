package com.unity3d.ads.core.domain.events

import com.unity3d.ads.gatewayclient.RequestPolicy
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

/**
 * Validates the TTL of a universal request based on requestPolicy, if expired will return false.
 */
fun interface UniversalRequestTtlValidator {
    operator fun invoke(universalRequest: UniversalRequest, requestPolicy: RequestPolicy): Boolean
}