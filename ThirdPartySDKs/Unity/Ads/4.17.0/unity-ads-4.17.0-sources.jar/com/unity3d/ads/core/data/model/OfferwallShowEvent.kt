package com.unity3d.ads.core.data.model

sealed class OfferwallShowEvent {
    object Show : OfferwallShowEvent()
}