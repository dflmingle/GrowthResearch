package com.unity3d.ads

@RequiresOptIn(
    level = RequiresOptIn.Level.ERROR,
    message = "This Unity Ads API is experimental. It may be changed in the future without notice."
)
@Retention(AnnotationRetention.BINARY)
@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY, AnnotationTarget.CONSTRUCTOR)
annotation class UnityAdsExperimental 
