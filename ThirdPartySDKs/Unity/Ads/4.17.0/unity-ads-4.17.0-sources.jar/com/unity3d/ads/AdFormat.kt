package com.unity3d.ads

enum class AdFormat {
    UNSPECIFIED,
    INTERSTITIAL,
    REWARDED,
    BANNER,
}
