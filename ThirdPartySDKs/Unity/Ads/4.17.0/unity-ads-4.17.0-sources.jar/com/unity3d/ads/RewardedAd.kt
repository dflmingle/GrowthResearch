package com.unity3d.ads

import android.app.Activity
import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.model.AdObjectState
import com.unity3d.ads.core.data.model.Listeners
import com.unity3d.ads.core.data.model.LoadConfigurationInternal
import com.unity3d.ads.core.data.model.ShowConfigurationInternal
import com.unity3d.ads.core.domain.InternalLoadListener
import com.unity3d.ads.core.domain.SafeCallbackInvoke
import com.unity3d.ads.core.extensions.toUUID
import com.unity3d.ads.metadata.MetaData
import com.unity3d.services.UnityAdsSDK
import com.unity3d.services.ads.UnityAdsImplementation
import com.unity3d.services.core.di.ServiceKey
import com.unity3d.services.core.di.ServiceProvider
import com.unity3d.services.core.di.ServiceProvider.NAMED_LOAD_SCOPE
import com.unity3d.services.core.di.ServiceProvider.NAMED_SHOW_SCOPE
import com.unity3d.services.core.misc.Utilities.wrapCustomerListener
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode.PUBLIC_ERROR_CODE_SHOW_ALREADY_SHOWN
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode.PUBLIC_ERROR_CODE_SHOW_EXPIRED
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode.PUBLIC_ERROR_CODE_SHOW_INTERNAL
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode.PUBLIC_ERROR_CODE_TIMEOUT
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference
import java.util.UUID

@UnityAdsExperimental
class RewardedAd internal constructor(
    private val adObject: AdObject,
    private val safeCallbackInvoke: SafeCallbackInvoke
) {
    var onAdExpired: AdExpiredListener<RewardedAd>? = null

    init {
        adObject.adPlayer?.scope?.let { scope ->
            scope.launch {
                adObject.state
                    .filter(AdObjectState.EXPIRED::equals)
                    .take(1)
                    .collect {
                        safeCallbackInvoke {
                            onAdExpired?.onAdExpired(this@RewardedAd)
                        }
                    }
            }
        }
    }

    fun show(activity: Activity, configuration: ShowConfiguration? = null, listener: RewardedShowListener? = null) {
        val showScope = ServiceProvider.getRegistry().resolveService<CoroutineScope>(
            ServiceKey(
                named = NAMED_SHOW_SCOPE,
                instanceClass = CoroutineScope::class
            )
        )
        showScope.launch {
            val showConfigurationInternal = ShowConfigurationInternal(
                customRewardString = configuration?.customRewardString,
                extras = configuration?.extras ?: emptyMap(),
            )

            val showOptions = UnityAdsShowOptions()
            showOptions.objectId = adObject.opportunityId.toUUID().toString()
            showOptions.showConfiguration = showConfigurationInternal
            val metadata = MetaData(activity)
            configuration?.extras?.forEach { (key, value) ->
                metadata.set(key, value)
            }
            metadata.commit()

            adObject.showConfiguration = configuration
            adObject.playerServerId = configuration?.customRewardString
            adObject.activity = WeakReference(activity)

            UnityAdsSDK().show(adObject.placementId, showOptions, object : Listeners {
                override fun onLeftApplication(placementId: String) {
                    // no-op
                }

                override fun onError(
                    placementId: String,
                    error: UnityAds.UnityAdsShowError,
                    message: String
                ) {
                    val errorCode = when (error) {
                        UnityAds.UnityAdsShowError.TIMEOUT -> PUBLIC_ERROR_CODE_TIMEOUT
                        UnityAds.UnityAdsShowError.EXPIRED -> PUBLIC_ERROR_CODE_SHOW_EXPIRED
                        UnityAds.UnityAdsShowError.ALREADY_SHOWING -> PUBLIC_ERROR_CODE_SHOW_ALREADY_SHOWN
                        else -> PUBLIC_ERROR_CODE_SHOW_INTERNAL
                    }

                    listener?.onFailed(
                        this@RewardedAd,
                        UnityAdsError(
                            code = errorCode.number,
                            message = errorCode.getShowErrorMsg()
                        )
                    )
                }

                override fun onStart(placementId: String) {
                    listener?.onStarted(this@RewardedAd)
                }

                override fun onClick(placementId: String) {
                    listener?.onClicked(this@RewardedAd)
                }

                override fun onComplete(
                    placementId: String,
                    state: UnityAds.UnityAdsShowCompletionState
                ) {
                    val state = when (state) {
                        UnityAds.UnityAdsShowCompletionState.COMPLETED -> ShowFinishState.COMPLETED
                        UnityAds.UnityAdsShowCompletionState.SKIPPED -> ShowFinishState.SKIPPED
                    }

                    listener?.onCompleted(this@RewardedAd, state)
                }

                override fun onRewarded(placementId: String) {
                    listener?.onRewarded(this@RewardedAd)
                }
            })
        }
    }

    companion object {
        @JvmStatic
        fun load(configuration: LoadConfiguration, listener: LoadListener<RewardedAd>) {
            val loadScope = ServiceProvider.getRegistry().resolveService<CoroutineScope>(ServiceKey(named = NAMED_LOAD_SCOPE, instanceClass = CoroutineScope::class))
            loadScope.launch {
                runCatching {
                    val internalConfiguration = LoadConfigurationInternal(
                        configuration.placementId,
                        configuration.adMarkup,
                        configuration.mediationAdUnitId,
                        configuration.mediationInfo,
                        configuration.extras.toMap(),
                    )

                    val opportunityId = UUID.randomUUID()
                    val unityAdsLoadOptions = UnityAdsLoadOptions().also {
                        it.objectId = opportunityId.toString()
                        it.setAdMarkup(configuration.adMarkup)
                        it.loadConfiguration = internalConfiguration
                    }

                    UnityAdsImplementation.getInstance().load(
                        configuration.placementId,
                        unityAdsLoadOptions,
                        object : InternalLoadListener {
                            override fun onAdLoaded(adObject: AdObject) {
                                val safeCallbackInvoke = ServiceProvider.getRegistry().resolveService<SafeCallbackInvoke>(ServiceKey(instanceClass = SafeCallbackInvoke::class))
                                listener.onAdLoaded(RewardedAd(adObject, safeCallbackInvoke), null)
                            }

                            override fun onAdLoadFail(error: UnityAdsError) {
                                listener.onAdLoaded(null, error)
                            }

                        })
                }.onFailure { exception ->
                    wrapCustomerListener {
                        listener.onAdLoaded(
                            null, UnityAdsError(
                                PublicErrorCode.PUBLIC_ERROR_CODE_INIT_UNKNOWN.number,
                                "Unity Ads SDK load failed due to unexpected error: ${exception.message}"
                            )
                        )
                    }
                }
            }
        }
    }
}
