package com.unity3d.ads.core.configuration

import com.unity3d.services.core.misc.JsonStorage

class MediationInitBlobMetadataReader(
    jsonStorage: JsonStorage
) : MetadataReader<String?>(jsonStorage, MEDIATION_UADS_INIT_BLOB) {
    companion object {
        const val MEDIATION_UADS_INIT_BLOB = "mediation.uads_init_blob.value"
    }
}