package com.unity3d.ads.gl

/**
 * Off-screen EGL surface (pbuffer).
 */
class OffscreenSurface(eglCore: EglCore, width: Int, height: Int) : EglSurfaceBase(eglCore) {
    /**
     * Creates an off-screen surface with the specified width and height.
     */
    init {
        createOffscreenSurface(width, height)
    }

    /**
     * Releases any resources associated with the surface.
     */
    fun release() = releaseEglSurface()

}