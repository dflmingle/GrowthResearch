package com.unity3d.ads.core.domain.om

interface IsOMActivated {
    operator fun invoke(): Boolean
}