package com.unity3d.ads.core.data.model

import java.io.File

data class CachedFile (
    val url: String,
    val name: String,
    val file: File? = null,
    val extension: String? = "",
    val contentLength: Long = -1L,
    val protocol: String = "",
    val priority: Int = Int.MAX_VALUE,
)