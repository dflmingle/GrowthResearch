package com.unity3d.ads.core.domain

import java.io.File

interface GetCacheDirectory {
    operator fun invoke(cacheDirectoryBase: File, cacheDirectoryPath: String): File
}