package com.unity3d.ads.gatewayclient

import com.unity3d.ads.core.data.model.OperationType
import com.unity3d.ads.core.data.model.OperationType.DIAGNOSTIC_EVENT
import com.unity3d.ads.core.data.model.OperationType.GET_TOKEN
import com.unity3d.ads.core.data.model.OperationType.INITIALIZATION_COMPLETED
import com.unity3d.ads.core.data.model.OperationType.LOAD
import com.unity3d.ads.core.data.model.OperationType.LOAD_HEADER_BIDDING
import com.unity3d.ads.core.data.model.OperationType.OPERATIVE_EVENT
import com.unity3d.ads.core.data.model.OperationType.PRIVACY_UPDATE
import com.unity3d.ads.core.data.model.OperationType.REFRESH
import com.unity3d.ads.core.data.model.OperationType.SHOW
import com.unity3d.ads.core.data.model.OperationType.TRANSACTION_EVENT
import com.unity3d.ads.core.data.repository.SessionRepository
import gatewayprotocol.v1.InitializationResponseOuterClass.RequestType

internal class AndroidRequestUrlFactory(
    private val sessionRepository: SessionRepository
) : RequestUrlFactory {

    override fun getRequestUrl(operationType: OperationType, defaultUrl: String?): String {
        return operationType.getRequestUrlOverrideType()?.let { requestType ->
            sessionRepository.requestUrlOverrides.firstOrNull { requestUrlOverride ->
                requestUrlOverride.requestType == requestType
            }?.url
        } ?: defaultUrl ?: ""
    }
}

private fun OperationType.getRequestUrlOverrideType(): RequestType? {
    return when (this) {
        SHOW, LOAD -> RequestType.REQUEST_TYPE_AD
        LOAD_HEADER_BIDDING -> RequestType.REQUEST_TYPE_AD_PLAYER_CONFIG
        REFRESH -> RequestType.REQUEST_TYPE_AD_DATA_REFRESH
        PRIVACY_UPDATE -> RequestType.REQUEST_TYPE_PRIVACY_UPDATE
        INITIALIZATION_COMPLETED -> RequestType.REQUEST_TYPE_INITIALIZATION_COMPLETED
        TRANSACTION_EVENT -> RequestType.REQUEST_TYPE_TRANSACTION_EVENT
        GET_TOKEN -> RequestType.REQUEST_TYPE_GET_TOKEN_EVENT
        DIAGNOSTIC_EVENT -> RequestType.REQUEST_TYPE_DIAGNOSTIC_EVENT
        OPERATIVE_EVENT -> RequestType.REQUEST_TYPE_OPERATIVE_EVENT
        else -> null
    }
}