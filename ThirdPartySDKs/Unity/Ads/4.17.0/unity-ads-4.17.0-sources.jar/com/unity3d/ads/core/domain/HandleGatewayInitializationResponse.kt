package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalResponseOuterClass.UniversalResponse

interface HandleGatewayInitializationResponse {
    suspend operator fun invoke(response: UniversalResponse)
}