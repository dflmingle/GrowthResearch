package com.unity3d.ads.core.data.model

internal data class TokenCounters(
    var seq: Int,
    var wins: Int,
    var starts: Int
)
