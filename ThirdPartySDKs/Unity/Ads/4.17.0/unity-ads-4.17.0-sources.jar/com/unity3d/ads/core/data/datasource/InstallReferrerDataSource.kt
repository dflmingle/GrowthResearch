package com.unity3d.ads.core.data.datasource

import gatewayprotocol.v1.InitializationRequestOuterClass.InstallReferrer

interface InstallReferrerDataSource {
    suspend operator fun invoke(): InstallReferrer?
}