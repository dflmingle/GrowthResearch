package com.unity3d.ads.core.utils

import kotlinx.coroutines.Job

interface CoroutineTimer {
    fun start(delayStartMillis: Long, repeatMillis: Long, action: () -> Unit): Job
}