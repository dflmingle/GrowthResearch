package com.unity3d.ads.core.data.model.exception

class ExposureException(message: String, val parameters: Array<out Any?>) : Exception(message)