package com.unity3d.ads.core.data.model

import com.google.protobuf.ByteString
import kotlin.coroutines.CoroutineContext

class CoroutineOpportunity(val value: ByteString): CoroutineContext.Element {
    override val key: CoroutineContext.Key<*> get() = Key

    companion object Key : CoroutineContext.Key<CoroutineOpportunity>
}