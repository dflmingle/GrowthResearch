package com.unity3d.ads.adplayer.model

data class WebViewClientError(
    val url: String? = null,
    val reason: ErrorReason,
    val statusCode: Int? = null
)