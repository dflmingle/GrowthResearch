package com.unity3d.ads.adplayer

import android.util.Base64
import com.unity3d.ads.adplayer.model.LoadEvent
import com.unity3d.ads.adplayer.model.OnActivityDestroyedEvent
import com.unity3d.ads.adplayer.model.OnAllowedPiiChangeEvent
import com.unity3d.ads.adplayer.model.OnBroadcastEvent
import com.unity3d.ads.adplayer.model.OnFocusChangeEvent
import com.unity3d.ads.adplayer.model.OnGmaEvent
import com.unity3d.ads.adplayer.model.OnMuteChangeEvent
import com.unity3d.ads.adplayer.model.OnOfferwallEvent
import com.unity3d.ads.adplayer.model.OnPrivacyFsmChangeEvent
import com.unity3d.ads.adplayer.model.OnScarBannerEvent
import com.unity3d.ads.adplayer.model.OnStorageEvent
import com.unity3d.ads.adplayer.model.OnUserConsentChangeEvent
import com.unity3d.ads.adplayer.model.OnVisibilityChangeEvent
import com.unity3d.ads.adplayer.model.OnVolumeChangeEvent
import com.unity3d.ads.adplayer.model.ShowStatus
import com.unity3d.ads.adplayer.model.WebViewEvent
import com.unity3d.ads.core.data.model.OfferwallShowEvent
import com.unity3d.ads.core.data.model.ScarEvent
import com.unity3d.ads.core.data.model.ShowEvent
import com.unity3d.ads.core.data.repository.DeviceInfoRepository
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.domain.SendDiagnosticEvent
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.BRIDGE_SEND_EVENT_FAILED
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_AD_VIEWER
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_CODE
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_DEBUG
import com.unity3d.ads.core.extensions.toBase64
import com.unity3d.scar.adapter.common.GMAEvent
import com.unity3d.services.ads.offerwall.OfferwallEvent
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent
import com.unity3d.services.core.device.Storage
import com.unity3d.services.core.device.StorageEventInfo
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.shareIn
import kotlinx.coroutines.flow.single
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import org.json.JSONObject

private val SHOW_EVENTS = arrayOf(
    ExposedFunctionLocation.STARTED,
    ExposedFunctionLocation.CLICKED,
    ExposedFunctionLocation.RECEIVED_REWARD,
    ExposedFunctionLocation.COMPLETED,
    ExposedFunctionLocation.FAILED,
    ExposedFunctionLocation.CANCEL_SHOW_TIMEOUT,
    ExposedFunctionLocation.LEFT_APPLICATION, // Banner only
)

private val LOAD_EVENTS = arrayOf(
    ExposedFunctionLocation.LOAD_COMPLETE,
    ExposedFunctionLocation.LOAD_ERROR,
)

/**
 * Class responsible for handling ad playback in a WebView.
 *
 * @property bridge The WebViewBridge used for communication with the WebView.
 * @property deviceInfoRepository The repository used for retrieving device information.
 * @property sessionRepository The repository used for managing session data.
 * @property dispatcher The CoroutineDispatcher used for running coroutines.
 */
internal class WebViewAdPlayer(
    private val bridge: WebViewBridge,
    private val deviceInfoRepository: DeviceInfoRepository,
    private val sessionRepository: SessionRepository,
    private val dispatcher: CoroutineDispatcher,
    private val sendDiagnosticEvent: SendDiagnosticEvent,
    override val webViewContainer: WebViewContainer,
    adPlayerScope: CoroutineScope,
) : AdPlayer {
    private val isCompletedManually = MutableStateFlow(false)

    private val storageEventCallback: (StorageEventInfo) -> Unit = {
        scope.launch {
            bridge.sendEvent(OnStorageEvent(
                eventType = it.eventType,
                storageType = it.storageType,
                value = it.value
            ))
        }
    }

    override val scope = adPlayerScope + dispatcher + CoroutineName("WebViewAdPlayer")

    override val onScarEvent = bridge.onInvocation
        .filter { it.location in arrayOf(ExposedFunctionLocation.SHOW_SCAR_AD) }
        .map {
            it.handle()
            when(it.location) {
                ExposedFunctionLocation.SHOW_SCAR_AD -> ScarEvent.Show
                else -> error("Unexpected location: ${it.location}")
            }
        }

    override val onOfferwallEvent = bridge.onInvocation
        .filter { it.location in arrayOf(ExposedFunctionLocation.SHOW_OFFERWALL_AD) }
        .map {
            it.handle()
            when(it.location) {
                ExposedFunctionLocation.SHOW_OFFERWALL_AD -> OfferwallShowEvent.Show
                else -> error("Unexpected location: ${it.location}")
            }
        }

    override val onShowEvent = bridge.onInvocation
        .filter { it.location in SHOW_EVENTS }
        .map {
            val event = when (it.location) {
                ExposedFunctionLocation.STARTED -> ShowEvent.Started
                ExposedFunctionLocation.CLICKED -> ShowEvent.Clicked
                ExposedFunctionLocation.RECEIVED_REWARD -> ShowEvent.ReceivedReward
                ExposedFunctionLocation.COMPLETED -> ShowEvent.Completed(
                    when (it.parameters.first() as? String) {
                        "COMPLETED" -> ShowStatus.COMPLETED
                        "SKIPPED" -> ShowStatus.SKIPPED
                        else -> ShowStatus.ERROR
                    }
                )
                ExposedFunctionLocation.FAILED -> {
                    val jsonObject = it.parameters.first() as JSONObject
                    val errorCode = jsonObject.optInt("code")
                    val errorMessage = jsonObject.optString("message")
                    ShowEvent.Error(errorMessage, errorCode, REASON_AD_VIEWER)
                }
                ExposedFunctionLocation.CANCEL_SHOW_TIMEOUT -> ShowEvent.CancelTimeout
                ExposedFunctionLocation.LEFT_APPLICATION -> ShowEvent.LeftApplication
                else -> throw IllegalStateException("Unexpected location: ${it.location}")
            }
            it.handle()
            event
        }.combine(isCompletedManually) { event, isCompletedManually ->
            if (isCompletedManually) {
                ShowEvent.Completed(ShowStatus.COMPLETED)
            } else {
                event
            }
        }.shareIn(scope, SharingStarted.Eagerly,10)

    override val onLoadEvent = bridge.onInvocation
        .filter { it.location in LOAD_EVENTS }
        .map {
            it.handle()

            if (it.location == ExposedFunctionLocation.LOAD_ERROR) {
                val jsonObject = it.parameters.first() as JSONObject
                val errorCode = jsonObject.optInt("code")
                val errorMessage = jsonObject.optString("message")
                LoadEvent.Error(errorMessage, errorCode)
            } else {
                LoadEvent.Completed
            }
        }
        .shareIn(scope, SharingStarted.Eagerly, 1)
        .take(1)

    private val onBroadcastEvents = bridge.onInvocation
        .filter { it.location == ExposedFunctionLocation.BROADCAST_EVENT }
        .map {
            it.handle()
            it.parameters.first().toString()
        }

    init {
        Storage.addStorageEventCallback(storageEventCallback)

        adPlayerScope.coroutineContext.job.invokeOnCompletion {
            Storage.removeStorageEventCallback(storageEventCallback)
        }

        // Listen to calls of `broadcastEvent`, and emit them to the broadcast event channel.
        onBroadcastEvents.onEach(AdPlayer.broadcastEventChannel::emit).launchIn(scope)

        // Listen to the broadcast event channel, and send the events to the webview.
        AdPlayer.broadcastEventChannel.onEach(::onBroadcastEvent).launchIn(scope)
    }

    // region AdViewer API

    override suspend fun requestShow(unityAdsShowOptions: Map<String, Any?>?) {
        val dynamicDeviceInfo = deviceInfoRepository.dynamicDeviceInfo

        val showOptions = JSONObject().also {
            it.put("orientation", deviceInfoRepository.orientation)
            it.put("connectionType", deviceInfoRepository.connectionTypeStr)
            it.put("isMuted", deviceInfoRepository.ringerMode != 2)
            it.put("volume", dynamicDeviceInfo.android.volume)
            it.put("privacy", sessionRepository.getPrivacy().toBase64())
            it.put("privacyFsm", sessionRepository.getPrivacyFsm().toBase64())
            // TODO: Discuss with AdViewer and iOS how we should really pass around allowedPii structure.
            it.put("allowedPii", deviceInfoRepository.allowedPii.value.toByteString().toBase64())
            unityAdsShowOptions?.let { showOptions ->
                // Remove object id from show options
                val filteredShowOptions = showOptions.filter { currentEntry ->
                    currentEntry.key != "objectId"
                }
                // Only put showOptions if it is not empty
                if (filteredShowOptions.isNotEmpty()) {
                    it.put("showOptions", JSONObject(filteredShowOptions))
                }
            }
        }

        bridge.request("webview", "show", showOptions)
    }

    override fun dispatchShowCompleted() {
        isCompletedManually.value = true
    }

    // endregion AdViewer API

    // region Events

    private suspend fun sendEvent(getEvent: () -> WebViewEvent) {
        val loadEvent = onLoadEvent.single()
        if (loadEvent is LoadEvent.Error) {
            sendDiagnosticEvent(
                event = BRIDGE_SEND_EVENT_FAILED,
                tags = mapOf(
                    REASON to REASON_AD_VIEWER,
                    REASON_DEBUG to loadEvent.message,
                    REASON_CODE to loadEvent.errorCode.toString(),
                )
            )
            return
        }

        val event = getEvent()
        bridge.sendEvent(event)
    }

    override suspend fun sendScarBannerEvent(event: BannerEvent) = sendEvent {
        OnScarBannerEvent(event)
    }

    override suspend fun sendGmaEvent(event: GMAEvent) = sendEvent {
        OnGmaEvent(event)
    }

    override suspend fun sendOfferwallEvent(event: OfferwallEvent) = sendEvent {
        OnOfferwallEvent(event)
    }

    override suspend fun sendMuteChange(isMuted: Boolean) = sendEvent {
        OnMuteChangeEvent(isMuted)
    }

    override suspend fun sendVisibilityChange(isVisible: Boolean) = sendEvent {
        OnVisibilityChangeEvent(isVisible)
    }

    override suspend fun sendFocusChange(isFocused: Boolean) = sendEvent {
        OnFocusChangeEvent(isFocused)
    }

    // Activity was destroyed because of external
    override suspend fun sendActivityDestroyed() = sendEvent {
        OnActivityDestroyedEvent()
    }

    override suspend fun sendVolumeChange(volume: Double) = sendEvent {
        OnVolumeChangeEvent(volume)
    }

    override suspend fun sendUserConsentChange(value: ByteArray) = sendEvent {
        OnUserConsentChangeEvent(Base64.encodeToString(value, Base64.NO_WRAP))
    }

    override suspend fun sendPrivacyFsmChange(value: ByteArray) = sendEvent {
        OnPrivacyFsmChangeEvent(Base64.encodeToString(value, Base64.NO_WRAP))
    }

    override suspend fun onBroadcastEvent(event: String) = sendEvent {
        val json = JSONObject(event)
        val eventType = json.getString("eventType")
        val data = json.optString("data")

        OnBroadcastEvent(eventType, data)
    }

    override suspend fun onAllowedPiiChange(value: ByteArray) = sendEvent {
        OnAllowedPiiChangeEvent(Base64.encodeToString(value, Base64.NO_WRAP))
    }
    // endregion Events
}
