package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.repository.SessionRepository

internal class CommonTokenNumberProvider(sessionRepository: SessionRepository): TokenNumberProvider {
    private val number by lazy { sessionRepository.headerBiddingTokenCounter }

    override fun invoke(): Int {
        return number
    }
}