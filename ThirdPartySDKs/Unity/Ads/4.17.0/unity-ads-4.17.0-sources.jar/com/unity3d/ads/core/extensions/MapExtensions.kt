package com.unity3d.ads.core.extensions

fun Map<String, String>.sizeInKb(): Int {
    val totalBytes = entries.sumOf { (key, value) ->
        key.toByteArray(Charsets.UTF_8).size + value.toByteArray(Charsets.UTF_8).size
    }
    return totalBytes / 1024
}
