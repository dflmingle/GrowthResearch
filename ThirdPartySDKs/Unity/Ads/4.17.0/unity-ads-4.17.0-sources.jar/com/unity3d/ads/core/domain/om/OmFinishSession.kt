package com.unity3d.ads.core.domain.om

import com.unity3d.ads.core.data.model.AdObject

interface OmFinishSession {
    suspend operator fun invoke(adObject: AdObject)
}