package com.unity3d.ads.core.data.model

import com.unity3d.ads.LogLevel
import com.unity3d.ads.MediationInfo
import com.unity3d.ads.UnityAdsExperimental

@OptIn(UnityAdsExperimental::class)
internal data class InitializationConfigurationInternal(
    val gameId: String,
    val isTestModeEnabled: Boolean,
    val logLevel: LogLevel = LogLevel.INFO,
    val extras: Map<String, String> = emptyMap(),
    val mediationInfo: MediationInfo? = null,
)
