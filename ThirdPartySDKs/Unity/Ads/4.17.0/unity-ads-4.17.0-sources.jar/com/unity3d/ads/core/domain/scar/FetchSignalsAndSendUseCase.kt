package com.unity3d.ads.core.domain.scar

import com.google.protobuf.ByteString
import com.unity3d.ads.TokenConfiguration

fun interface FetchSignalsAndSendUseCase {
    suspend operator fun invoke(tokenNumber: Int, tokenId: ByteString, tokenConfiguration: TokenConfiguration?)
}