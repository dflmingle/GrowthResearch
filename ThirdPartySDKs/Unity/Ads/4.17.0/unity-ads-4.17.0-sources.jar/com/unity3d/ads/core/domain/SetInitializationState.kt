package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.InitializationState

internal interface SetInitializationState {
    operator fun invoke(state: InitializationState, legacy: Boolean = false)
}