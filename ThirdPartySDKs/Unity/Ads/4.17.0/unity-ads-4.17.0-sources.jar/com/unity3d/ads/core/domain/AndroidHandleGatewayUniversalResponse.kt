package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.datasource.AndroidAppSetIdDataSource
import com.unity3d.ads.core.data.model.exception.GatewayException
import com.unity3d.ads.core.data.repository.DeviceInfoRepository
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_GATEWAY
import com.unity3d.ads.getInitErrorMsg
import gatewayprotocol.v1.UniversalResponseOuterClass.UniversalResponse
import kotlinx.coroutines.flow.update

internal class AndroidHandleGatewayUniversalResponse(
    private val sessionRepository: SessionRepository,
    private val deviceInfoRepository: DeviceInfoRepository,
    private val appSetIdDataSource: AndroidAppSetIdDataSource,
) : HandleGatewayUniversalResponse {
    override suspend fun invoke(response: UniversalResponse) {
        if (response.hasError()) {
            throw GatewayException(
                message = response.error.errorCode.getInitErrorMsg(sessionRepository.gameId) ?: response.error.errorText,
                throwable = IllegalStateException(response.error.errorText),
                reason = "${REASON_GATEWAY}_${GatewayException.GATEWAY_RESPONSE_DEPTH_UNIVERSAL}",
                reasonDebug = response.error.errorText,
                errorCode = response.error.errorCode
            )
        }

        if (response.hasMutableData()) {
            val mutableData = response.mutableData

            deviceInfoRepository.allowedPii.update { mutableData.allowedPii }

            if (mutableData.allowedPii.appsetId) {
                // if appset-id allowed, start collecting
                appSetIdDataSource()
            }

            sessionRepository.gatewayState = mutableData.currentState

            if (mutableData.hasSessionToken()) {
                sessionRepository.sessionToken = mutableData.sessionToken
            }
            if (mutableData.hasPrivacy()) {
                sessionRepository.setPrivacy(mutableData.privacy)
            }
            if (mutableData.hasSessionCounters()) {
                sessionRepository.sessionCounters = mutableData.sessionCounters
            }
            if (mutableData.hasCache()) {
                sessionRepository.setGatewayCache(mutableData.cache)
            }
            if (mutableData.hasPrivacyFsm()) {
                sessionRepository.setPrivacyFsm(mutableData.privacyFsm)
            }
        }
    }
}