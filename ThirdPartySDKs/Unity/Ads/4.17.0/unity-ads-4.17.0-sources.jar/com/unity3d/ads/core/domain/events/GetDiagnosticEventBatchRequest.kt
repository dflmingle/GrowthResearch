package com.unity3d.ads.core.domain.events

import gatewayprotocol.v1.DiagnosticEventRequestOuterClass
import gatewayprotocol.v1.diagnosticEventRequest



class GetDiagnosticEventBatchRequest {

    operator fun invoke(diagnosticEvents: List<DiagnosticEventRequestOuterClass.DiagnosticEvent>): DiagnosticEventRequestOuterClass.DiagnosticEventRequest {
        return diagnosticEventRequest {
            batch.addAll(diagnosticEvents)
        }
    }
}