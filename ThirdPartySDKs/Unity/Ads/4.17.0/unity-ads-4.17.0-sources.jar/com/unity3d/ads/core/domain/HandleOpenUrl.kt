package com.unity3d.ads.core.domain

import android.content.Intent
import com.unity3d.ads.core.data.model.AdObject

interface HandleOpenUrl {
    suspend operator fun invoke(
        adObject: AdObject,
        url: String,
        packageName: String?,
        action: String? = Intent.ACTION_VIEW,
        extras: Map<String, Any?>? = null,
        useActivityForResult: Boolean = false): Boolean
}