package com.unity3d.ads.core.data.repository

import com.google.protobuf.ByteString
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.core.data.model.InitializationConfigurationInternal
import com.unity3d.ads.core.data.model.InitializationState
import com.unity3d.ads.core.data.model.SessionChange
import com.unity3d.ads.core.data.model.TokenCounters
import com.unity3d.ads.core.data.model.exception.InitializationException
import gatewayprotocol.v1.AdFormatOuterClass.AdFormat
import gatewayprotocol.v1.InitializationResponseOuterClass.RequestUrlOverride
import gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlags
import gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfiguration
import gatewayprotocol.v1.SessionCountersOuterClass.SessionCounters
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow

internal interface SessionRepository {
    var sessionToken: ByteString
    var gatewayState: ByteString
    var nativeConfiguration: NativeConfiguration
    var gatewayUrl: String
    val scarEligibleFormats: MutableList<AdFormat>
    var initializationState: InitializationState
    var initializationError: InitializationException?
    var requestUrlOverrides: List<RequestUrlOverride>
    val observeInitializationState: Flow<InitializationState>
    val isSdkInitialized: Boolean
    val isDiagnosticsEnabled: Boolean
    var sessionCounters: SessionCounters
    var tokenCounters: TokenCounters
    var gameId: String?
    var shouldInitialize: Boolean
    val sessionId: ByteString
    val isTestModeEnabled: Boolean
    val onChange: SharedFlow<SessionChange>
    val featureFlags: FeatureFlags
    val headerBiddingTokenCounter: Int
    val isOmEnabled: Boolean
    val isFirstInitAttempt: Boolean
    val unityInstallationId: String?
    val unityMegaSessionId: String?
    @OptIn(UnityAdsExperimental::class)
    var initializationConfiguration: InitializationConfigurationInternal?

    suspend fun getGatewayCache(): ByteString
    suspend fun setGatewayCache(value: ByteString)
    suspend fun getPrivacy(): ByteString
    suspend fun setPrivacy(value: ByteString)
    suspend fun getPrivacyFsm(): ByteString
    suspend fun setPrivacyFsm(value: ByteString)
    fun incrementLoadRequestCount()
    fun incrementLoadRequestAdmCount()
    fun incrementBannerLoadRequestCount()
    fun incrementBannerLoadRequestAdmCount()
    fun incrementBannerImpressionCount()
    suspend fun persistNativeConfiguration()
    fun incrementTokenSequenceNumber()
    fun incrementTokenWinsCount()
    fun incrementTokenStartsCount()
    fun resetTokenCounters()
    fun incrementGlobalAdsFocusChangeCount()
    fun addTimeToGlobalAdsFocusTime(timeMs: Int)
    fun incrementFocusChangeCount()
}