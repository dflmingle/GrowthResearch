package com.unity3d.ads.core.data.datasource

import gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo

interface StaticDeviceInfoDataSource {
    suspend fun fetch(additionalStores: List<String>): StaticDeviceInfo
    fun fetchCached(): StaticDeviceInfo
    suspend fun getIdfi(): String
    suspend fun getAuid(): String?
    suspend fun getUnityBuildGuid(): String?
    val analyticsUserId: String?
    fun getSystemBootTime(): Long
    fun getAppName(): String
    fun getModel(): String
    fun getManufacturer(): String
    fun getOsVersion(): String
}