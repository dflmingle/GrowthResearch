package com.unity3d.ads.core.domain

import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.adplayer.AndroidShowOptions
import com.unity3d.ads.core.configuration.GameServerIdReader
import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.model.AdObjectState
import com.unity3d.ads.core.data.model.ShowEvent
import com.unity3d.ads.core.data.repository.AdRepository
import com.unity3d.ads.core.extensions.toBuiltInMap
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.transformWhile

internal class AndroidShow(
    private val adRepository: AdRepository,
    private val gameServerIdReader: GameServerIdReader,
    private val sendDiagnosticEvent: SendDiagnosticEvent,
    private val validateExtrasSize: ValidateExtrasSize,
) : Show {
    override fun invoke(adObject: AdObject, showOptions: UnityAdsShowOptions?): Flow<ShowEvent> = flow {
        require(!adObject.opportunityId.isEmpty) { "No opportunityId" }

        val opportunityId = adObject.opportunityId

        val ad = adRepository.getAd(opportunityId) ?: throw IllegalStateException("No ad associated with opportunityId")

        showOptions?.showConfiguration?.let {
            validateExtrasSize(it.extras, SendDiagnosticEvent.SOURCE_SHOW_API, adObject)
        }

        sendDiagnosticEvent(event = SendDiagnosticEvent.SHOW_STARTED_AD_VIEWER, adObject = adObject)

        val adPlayer = ad.adPlayer ?: throw IllegalStateException("No adPlayer associated with ad")

        adPlayer.onShowEvent
            .onStart {
                // TODO: When supporting only new Public API, delete this line entirely
                ad.playerServerId = gameServerIdReader.readAndDelete(ad.playerServerId)
                adObject.state.value = AdObjectState.SHOWING
                ad.adPlayer.show(
                    AndroidShowOptions(
                        showOptions?.data?.toBuiltInMap(),
                        isScarAd = ad.isScarAd,
                        scarAdString = ad.scarAdString,
                        scarQueryId = ad.scarQueryId,
                        scarAdUnitId = ad.scarAdUnitId,
                        isOfferwallAd = ad.isOfferwallAd,
                        offerwallPlacementName = ad.offerwallPlacementName,
                        placementId = ad.placementId)
                    )
            }
            .onCompletion {
                adObject.state.value = AdObjectState.COMPLETED
                adRepository.removeAd(opportunityId)
            }
            .transformWhile {
                emit(it)
                it !is ShowEvent.Completed && it !is ShowEvent.Error
            }
            .collect {
                emit(it)
            }
    }

    override suspend fun terminate(adObject: AdObject) {
        adObject.adPlayer?.destroy()
    }
}