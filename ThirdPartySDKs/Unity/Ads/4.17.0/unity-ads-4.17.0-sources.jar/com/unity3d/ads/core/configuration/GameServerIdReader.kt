package com.unity3d.ads.core.configuration

import com.unity3d.services.core.misc.JsonStorage

class GameServerIdReader(
    jsonStorage: JsonStorage
) : MetadataReader<String>(jsonStorage, PLAYER_SERVER_ID_KEY) {
    companion object {
        const val PLAYER_SERVER_ID_KEY = "player.server_id.value"
    }
}