package com.unity3d.ads.core.data.datasource

interface MediationDataSource {
    val name: String?
    val version: String?
}