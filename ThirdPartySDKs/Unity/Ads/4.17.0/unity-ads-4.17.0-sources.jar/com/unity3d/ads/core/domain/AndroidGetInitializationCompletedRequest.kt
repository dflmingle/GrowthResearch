package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.repository.DeviceInfoRepository
import gatewayprotocol.v1.UniversalRequestKt.payload
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest
import gatewayprotocol.v1.initializationCompletedEventRequest



internal class AndroidGetInitializationCompletedRequest(
    private val getUniversalRequestForPayLoad: GetUniversalRequestForPayLoad,
    private val deviceInfoRepository: DeviceInfoRepository
) : GetInitializationCompletedRequest {
    override suspend fun invoke(): UniversalRequest {
        val request = initializationCompletedEventRequest {
            staticDeviceInfo = deviceInfoRepository.staticDeviceInfo()
            dynamicDeviceInfo = deviceInfoRepository.dynamicDeviceInfo
        }

        val initCompletedPayload = payload {
            initializationCompletedEventRequest = request
        }

        return getUniversalRequestForPayLoad(initCompletedPayload)
    }
}