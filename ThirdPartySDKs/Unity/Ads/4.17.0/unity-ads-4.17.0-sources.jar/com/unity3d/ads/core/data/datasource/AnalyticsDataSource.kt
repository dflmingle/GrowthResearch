package com.unity3d.ads.core.data.datasource

interface AnalyticsDataSource {
    val userId : String?
}