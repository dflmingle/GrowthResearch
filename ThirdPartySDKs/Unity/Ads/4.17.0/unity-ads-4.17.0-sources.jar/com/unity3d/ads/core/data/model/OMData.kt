package com.unity3d.ads.core.data.model

data class OMData (
    val version: String,
    val partnerName: String,
    val partnerVersion: String,
)