package com.unity3d.ads.gatewayclient

import com.unity3d.ads.core.data.model.OperationType

interface RequestUrlFactory {
    fun getRequestUrl(operationType: OperationType, defaultUrl: String? = null): String
}