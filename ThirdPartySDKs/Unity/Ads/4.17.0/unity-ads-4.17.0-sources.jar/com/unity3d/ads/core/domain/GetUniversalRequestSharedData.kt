package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest.SharedData

interface GetUniversalRequestSharedData {
    suspend operator fun invoke(): SharedData
}