package com.unity3d.ads.core.extensions

import kotlin.time.DurationUnit
import kotlin.time.ExperimentalTime
import kotlin.time.TimeMark

@OptIn(ExperimentalTime::class)
fun TimeMark.elapsedMillis(): Double {
    return this.elapsedNow().toDouble(DurationUnit.MILLISECONDS)
}