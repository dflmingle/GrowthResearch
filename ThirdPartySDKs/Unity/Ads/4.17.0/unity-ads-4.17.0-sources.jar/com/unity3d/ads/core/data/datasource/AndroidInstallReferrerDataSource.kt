package com.unity3d.ads.core.data.datasource

import android.content.Context
import android.os.RemoteException
import com.android.installreferrer.api.InstallReferrerClient
import com.android.installreferrer.api.InstallReferrerStateListener
import com.unity3d.ads.core.domain.SendDiagnosticEvent
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INSTALL_REFERRAL_FETCH_COMPLETED
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INSTALL_REFERRAL_FETCH_TIMED_OUT
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INSTALL_REFERRAL_FETCH_FAILED
import gatewayprotocol.v1.InitializationRequestOuterClass.InstallReferrer
import gatewayprotocol.v1.installReferrer
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume


class AndroidInstallReferrerDataSource(
    private val appContext: Context,
    private val sendDiagnosticEvent: SendDiagnosticEvent
) : InstallReferrerDataSource {

    companion object {
        private const val TIME_OUT_MS = 500L
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    override suspend operator fun invoke(): InstallReferrer? =  try {
        withTimeout(TIME_OUT_MS) {
            suspendCancellableCoroutine { continuation ->

                try {
                    val referrerClient = InstallReferrerClient.newBuilder(appContext).build()

                    referrerClient.startConnection(object : InstallReferrerStateListener {
                        override fun onInstallReferrerSetupFinished(responseCode: Int) {
                            if (responseCode == InstallReferrerClient.InstallReferrerResponse.OK) {
                                try {
                                    val response = referrerClient.installReferrer

                                    val referrerUrlString = response.installReferrer?.replace(
                                        "[^a-zA-Z0-9]".toRegex(), ""
                                    )

                                    if (continuation.isActive) {
                                        continuation.resume(installReferrer {
                                            referrerUrlString?.let { url = it }
                                            clickTime = response.referrerClickTimestampSeconds
                                            installTime =
                                                response.installBeginTimestampServerSeconds
                                            instantExperienceLunch = response.googlePlayInstantParam

                                        }) {}
                                    }

                                    referrerClient.endConnection()

                                    sendDiagnosticEvent(INSTALL_REFERRAL_FETCH_COMPLETED)
                                } catch (e: RemoteException) {
                                    if (continuation.isActive) {
                                        continuation.resume(null)
                                        sendDiagnosticEvent(INSTALL_REFERRAL_FETCH_FAILED)
                                    }
                                }
                            } else {
                                if (continuation.isActive) {
                                    continuation.resume(null)
                                    sendDiagnosticEvent(INSTALL_REFERRAL_FETCH_FAILED)
                                }
                            }
                        }

                        override fun onInstallReferrerServiceDisconnected() {
                            if (continuation.isActive) {
                                continuation.resume(null)
                                sendDiagnosticEvent(INSTALL_REFERRAL_FETCH_FAILED)
                            }
                        }
                    })
                } catch (e: Throwable) {
                    if (continuation.isActive) {
                        continuation.resume(null)
                        sendDiagnosticEvent(INSTALL_REFERRAL_FETCH_FAILED)
                    }
                }
            }
        }
    } catch (e: TimeoutCancellationException) {
        sendDiagnosticEvent(INSTALL_REFERRAL_FETCH_TIMED_OUT)
        null
    }
}