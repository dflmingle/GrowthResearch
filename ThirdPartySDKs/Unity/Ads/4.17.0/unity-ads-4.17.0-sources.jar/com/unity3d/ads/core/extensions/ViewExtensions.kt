package com.unity3d.ads.core.extensions

import android.view.View
import android.view.ViewGroup

fun View?.removeViewFromParent() {
    val parent = this?.parent as? ViewGroup
    parent?.removeView(this)
}