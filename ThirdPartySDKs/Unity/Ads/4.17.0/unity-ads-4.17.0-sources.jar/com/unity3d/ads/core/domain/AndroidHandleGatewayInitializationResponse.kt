package com.unity3d.ads.core.domain

import com.unity3d.ads.MSG_INIT_FAIL_PARSING_ERROR
import com.unity3d.ads.core.data.manager.TransactionEventManager
import com.unity3d.ads.core.data.model.exception.GatewayException
import com.unity3d.ads.core.data.model.exception.InitializationException
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_GATEWAY
import gatewayprotocol.v1.NativeConfigurationOuterClass
import com.unity3d.ads.getInitErrorMsg
import gatewayprotocol.v1.ErrorOuterClass
import gatewayprotocol.v1.UniversalResponseOuterClass.UniversalResponse
import gatewayprotocol.v1.copy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

internal class AndroidHandleGatewayInitializationResponse(
    private val transactionEventManager: TransactionEventManager,
    private val triggerInitializationCompletedRequest: TriggerInitializationCompletedRequest,
    private val sessionRepository: SessionRepository,
    private val sdkScope: CoroutineScope,
    private val handleDebugSettings: HandleDebugSettings,
    private val getSafeguardedInitializationPolicy: GetSafeguardedInitializationPolicy,
    private val defaultNativeConfiguration: NativeConfigurationOuterClass.NativeConfiguration,
) : HandleGatewayInitializationResponse {

    override suspend fun invoke(response: UniversalResponse) {

        // throw non recoverable gateway exception
        if(response.hasPayload() && response.payload.hasInitializationResponse() &&
            response.payload.initializationResponse.hasError()) {
            throw GatewayException(
                message = response.payload.initializationResponse.error.errorCode.getInitErrorMsg(
                    sessionRepository.gameId,
                ) ?: response.payload.initializationResponse.error.errorText,
                throwable = IllegalStateException(response.payload.initializationResponse.error.errorText),
                reason = "${REASON_GATEWAY}_${GatewayException.GATEWAY_RESPONSE_DEPTH_INITIALIZATION}",
                reasonDebug = response.payload.initializationResponse.error.errorText,
                errorCode = response.payload.initializationResponse.error.errorCode
            )
        }

        // throw recoverable initialization exception
        if (response.hasError()) {
            throw InitializationException(
                message = response.error.errorCode.getInitErrorMsg(
                    sessionRepository.gameId,
                ) ?: response.error.errorText,
                throwable = IllegalStateException(response.error.errorText),
                reason = "${REASON_GATEWAY}_${GatewayException.GATEWAY_RESPONSE_DEPTH_INITIALIZATION}",
                reasonDebug = response.error.errorText,
                errorCode = response.error.errorCode
            )
        }

        if (!response.hasPayload() || !response.payload.hasInitializationResponse()) {
            throw InitializationException(
                message = MSG_INIT_FAIL_PARSING_ERROR,
                reason = REASON_GATEWAY,
                reasonDebug = "No payload",
                errorCode = ErrorOuterClass.PublicErrorCode.PUBLIC_ERROR_CODE_INIT_PROTO
            )
        }

        val initResponse = response.payload.initializationResponse

        // Rebuild native configs with init request policies safeguarded
        sessionRepository.nativeConfiguration = initResponse.nativeConfiguration.copy {
            initPolicy = getSafeguardedInitializationPolicy(initPolicy)
            maxExtrasSizeKb = if (maxExtrasSizeKb == 0) defaultNativeConfiguration.maxExtrasSizeKb else maxExtrasSizeKb
        }

        if (initResponse.hasUniversalRequestUrl() && !initResponse.universalRequestUrl.isNullOrEmpty()) {
            sessionRepository.gatewayUrl = initResponse.universalRequestUrl
        }

        initResponse.requestUrlOverridesList?.let { sessionRepository.requestUrlOverrides = it }

        sessionRepository.scarEligibleFormats.addAll(initResponse.scarEligibleFormatsList)

        if (initResponse.triggerInitializationCompletedRequest) {
            sdkScope.launch {
                triggerInitializationCompletedRequest()
            }
        }

        if (initResponse.nativeConfiguration.enableIapEvent) {
            transactionEventManager()
        }

        if (initResponse.nativeConfiguration.hasDebugSettings()) {
            handleDebugSettings(initResponse.nativeConfiguration.debugSettings)
        }
    }
}