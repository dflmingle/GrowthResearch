package com.unity3d.ads.core.data.model

import com.unity3d.ads.MediationInfo
import com.unity3d.ads.UnityAdsExperimental

@OptIn(UnityAdsExperimental::class)
internal data class LoadConfigurationInternal(
    val placementId: String,
    val adMarkup: String?,
    val mediationAdUnitId: String? = null,
    val mediationInfo: MediationInfo? = null,
    val extras: Map<String, String> = emptyMap(),
)
