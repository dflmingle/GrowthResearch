package com.unity3d.ads.core.data.repository

interface TcfRepository {
    val tcfString: String?
}