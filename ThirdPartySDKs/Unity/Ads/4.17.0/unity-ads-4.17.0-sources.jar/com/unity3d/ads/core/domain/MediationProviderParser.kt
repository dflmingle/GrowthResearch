package com.unity3d.ads.core.domain

import gatewayprotocol.v1.ClientInfoOuterClass.MediationProvider

fun interface MediationProviderParser {
    operator fun invoke(mediationProvider: String?): MediationProvider
}