package com.unity3d.ads.core.data.manager

import android.content.Context

interface StorageManager {
    fun init(context: Context): Boolean
    fun initStorage(type: LegacyStorageType)
    fun getStorage(type: LegacyStorageType): LegacyStorage
    fun hasStorage(type: LegacyStorageType): Boolean
    fun addStorageLocation(type: LegacyStorageType, fileName: String)
    fun removeStorage(type: LegacyStorageType)
    fun hasInitialized()
}