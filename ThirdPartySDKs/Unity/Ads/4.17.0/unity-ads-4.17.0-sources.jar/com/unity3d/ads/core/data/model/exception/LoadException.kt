package com.unity3d.ads.core.data.model.exception

class LoadException(val errorCode: Int, message: String) : Exception(message)