package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.InitializationState

internal interface GetInitializationState {
    operator fun invoke(legacy: Boolean = false): InitializationState
}