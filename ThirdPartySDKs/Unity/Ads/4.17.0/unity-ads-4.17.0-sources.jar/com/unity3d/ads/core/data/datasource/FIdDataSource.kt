package com.unity3d.ads.core.data.datasource

fun interface FIdDataSource {
    operator fun invoke(): String?
}