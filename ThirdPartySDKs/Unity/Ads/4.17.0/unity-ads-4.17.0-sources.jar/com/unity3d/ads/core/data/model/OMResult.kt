package com.unity3d.ads.core.data.model

sealed class OMResult {
    object Success : OMResult()
    data class Failure(
        val reason: String,
        val reasonDebug: String? = null
    ) : OMResult()
}