package com.unity3d.ads.adplayer

import com.unity3d.ads.adplayer.model.WebViewEvent
import kotlinx.coroutines.flow.SharedFlow

interface WebViewBridge {
    val onInvocation: SharedFlow<Invocation>

    fun handleInvocation(message: String)
    fun handleCallback(callbackId: String, callbackStatus: String, rawParameters: String)
    suspend fun sendEvent(event: WebViewEvent)
    suspend fun request(className: String, method: String, vararg params: Any): Array<Any>
}