package com.unity3d.ads.core.domain

interface ShouldAllowInitialization {
    operator fun invoke(gameId: String?): Boolean
}