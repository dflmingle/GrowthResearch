package com.unity3d.ads.network.model

/**
 * Defines the request type for an [HttpRequest]
 */
enum class RequestType {
    POST,
    GET,
    HEAD
}
