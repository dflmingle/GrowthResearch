package com.unity3d.ads.core.domain

import com.unity3d.ads.adplayer.WebViewContainer
import com.unity3d.ads.core.data.model.AdObject
import kotlinx.coroutines.CoroutineScope

interface GetWebViewContainerUseCase {
    suspend operator fun invoke(adPlayerScope: CoroutineScope, adObject: AdObject): WebViewContainer
}
