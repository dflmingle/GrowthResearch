package com.unity3d.ads.adplayer.model

enum class ShowStatus {
    COMPLETED,
    SKIPPED,
    ERROR;
}