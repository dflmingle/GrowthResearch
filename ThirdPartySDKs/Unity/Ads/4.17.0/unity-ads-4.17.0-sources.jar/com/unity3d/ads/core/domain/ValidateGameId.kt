package com.unity3d.ads.core.domain

interface ValidateGameId {
    operator fun invoke(gameId: String?): Boolean
}