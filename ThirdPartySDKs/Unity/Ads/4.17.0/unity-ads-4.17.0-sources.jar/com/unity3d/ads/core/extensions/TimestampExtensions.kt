package com.unity3d.ads.core.extensions

import com.google.protobuf.Timestamp

fun fromMillis(millis: Long): Timestamp = Timestamp.newBuilder().setSeconds(millis / 1000)
    .setNanos((((millis % 1000) * 1000000).toInt())).build()

fun Long.duration(): Long = System.nanoTime() - this