package com.unity3d.ads.core.domain.work

import androidx.work.Data
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

class UniversalRequestWorkerData(private val universalRequestId: String) {
    operator fun invoke(): Data {
        return Data.Builder()
            .putString(KEY_UNIVERSAL_REQUEST_ID, universalRequestId)
            .build()
    }

    companion object {
        const val KEY_UNIVERSAL_REQUEST_ID = "universalRequestId"
    }
}