package com.unity3d.ads.core.data.datasource

fun interface FIdExistenceDataSource {
    operator fun invoke(): Boolean
}