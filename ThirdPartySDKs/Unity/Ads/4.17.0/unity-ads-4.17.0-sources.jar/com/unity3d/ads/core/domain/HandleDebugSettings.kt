package com.unity3d.ads.core.domain

import android.webkit.WebView
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.core.log.LogLevelInternal
import com.unity3d.ads.core.log.Logger
import gatewayprotocol.v1.NativeConfigurationOuterClass.DebugSettings

internal class HandleDebugSettings(
    private val logger: Logger,
) {
    @OptIn(UnityAdsExperimental::class)
    operator fun invoke(debugSettings: DebugSettings) {
        if (debugSettings.enableTracing) {
            logger.logLevel = LogLevelInternal.TRACE
        }

        WebView.setWebContentsDebuggingEnabled(debugSettings.webviewInspectable)
    }
}