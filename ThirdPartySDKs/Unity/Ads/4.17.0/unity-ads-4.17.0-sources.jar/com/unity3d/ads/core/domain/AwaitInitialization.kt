package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.InitializationState

internal interface AwaitInitialization {
    suspend operator fun invoke(timeout: Long = Long.MAX_VALUE): InitializationState?
}