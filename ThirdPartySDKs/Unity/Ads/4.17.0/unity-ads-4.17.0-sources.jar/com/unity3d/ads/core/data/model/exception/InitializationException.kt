package com.unity3d.ads.core.data.model.exception

import com.unity3d.ads.MSG_INIT_FAIL_NETWORK_ERROR
import com.unity3d.ads.MSG_INIT_FAIL_TIMEOUT
import com.unity3d.ads.MSG_INIT_FAIL_UNKNOWN_ERROR
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_GATEWAY
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_NETWORK
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_TIMEOUT
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_UNKNOWN
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode
import kotlinx.coroutines.TimeoutCancellationException

data class InitializationException(
    override val message: String,
    val throwable: Throwable? = null,
    val reason: String = REASON_GATEWAY,
    val reasonDebug: String? = null,
    val errorCode: PublicErrorCode? = null
) : Exception(message) {
    companion object {
        fun parseFrom(e: Exception): InitializationException {
            return when (e) {
                is TimeoutCancellationException,
                is NetworkTimeoutException -> InitializationException(
                    message = MSG_INIT_FAIL_TIMEOUT,
                    throwable = e,
                    reason = REASON_TIMEOUT,
                    reasonDebug = e.message,
                    errorCode = PublicErrorCode.PUBLIC_ERROR_CODE_TIMEOUT
                )
                is GatewayException -> InitializationException(
                    message = e.message,
                    throwable = e.throwable,
                    reason = e.reason,
                    reasonDebug = e.reasonDebug,
                    errorCode = e.errorCode
                )
                is UnityAdsNetworkException -> InitializationException(
                    message = MSG_INIT_FAIL_NETWORK_ERROR,
                    throwable = e,
                    reason = if (e.code == null) REASON_NETWORK else "$REASON_NETWORK.${e.code}",
                    reasonDebug = e.message,
                    errorCode = PublicErrorCode.PUBLIC_ERROR_CODE_INIT_NETWORK
                )
                is InitializationException -> e
                else -> InitializationException(
                    message = MSG_INIT_FAIL_UNKNOWN_ERROR,
                    throwable = e,
                    reason = REASON_UNKNOWN,
                    reasonDebug = e.message,
                    errorCode = PublicErrorCode.PUBLIC_ERROR_CODE_INIT_UNKNOWN
                )
            }
        }
    }
}