package com.unity3d.ads.core.domain.privacy

import com.unity3d.services.core.misc.JsonFlattenerRules

interface FlattenerRulesUseCase {
    operator fun invoke(): JsonFlattenerRules
}