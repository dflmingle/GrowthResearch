package com.unity3d.ads.core.utils

import java.util.regex.Pattern

fun getMemoryValueFromString(memVal: String?): Long {
    if (memVal == null) return -1

    val p = Pattern.compile("(\\d+)")
    val m = p.matcher(memVal)
    var value: String? = null
    while (m.find()) {
        value = m.group(1)
    }

    return value?.toLongOrNull() ?: -1
}
