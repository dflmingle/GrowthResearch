package com.unity3d.ads.core.extensions

import com.unity3d.services.store.JsonSerializable
import org.json.JSONArray

fun List<JsonSerializable>.toJsonArray(): JSONArray {
    val jsonArray = JSONArray()
    for (jsonSerializable in this) {
        jsonArray.put(jsonSerializable.toJson())
    }
    return jsonArray
}