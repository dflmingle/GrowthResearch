package com.unity3d.ads.core.data.datasource

class AndroidFIdExistenceDataSource(
    private val className: String,
): FIdExistenceDataSource {
    override fun invoke(): Boolean =
        runCatching { Class.forName(className) }.isSuccess
}