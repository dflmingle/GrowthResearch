package com.unity3d.ads.core.domain.offerwall

import com.unity3d.services.ads.offerwall.OfferwallEvent

data class OfferwallEventData (
    val offerwallEvent: OfferwallEvent,
    val placementName: String? = null,
    val errorMessage: String? = null,
    val errorCode: Int? = null
)