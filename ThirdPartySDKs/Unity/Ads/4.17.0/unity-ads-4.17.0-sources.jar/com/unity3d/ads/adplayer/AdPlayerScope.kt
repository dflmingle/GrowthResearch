package com.unity3d.ads.adplayer

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope

class AdPlayerScope(
    private val defaultDispatcher: CoroutineDispatcher,
    private val sdkErrorHandler: CoroutineExceptionHandler,
) : CoroutineScope by CoroutineScope(defaultDispatcher + sdkErrorHandler)