package com.unity3d.ads.injection

import kotlin.reflect.KClass

data class EntryKey(
    val named: String = "",
    val instanceClass: KClass<*>,
)
