package com.unity3d.ads.core.data.repository

import com.google.protobuf.ByteString
import gatewayprotocol.v1.CampaignStateOuterClass.*

interface CampaignRepository {
    fun setCampaign(opportunityId: ByteString, campaign: Campaign)
    fun setShowTimestamp(opportunityId: ByteString)
    fun getCampaign(opportunityId: ByteString) : Campaign?
    fun removeState(opportunityId: ByteString)
    fun setLoadTimestamp(opportunityId: ByteString)
    fun getCampaignState(): CampaignState
}