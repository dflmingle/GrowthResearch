package com.unity3d.ads.core.domain.work

import android.content.Context
import androidx.work.WorkerParameters
import com.unity3d.ads.core.domain.GetRequestPolicy
import com.unity3d.ads.core.domain.events.UniversalRequestEventSender
import com.unity3d.services.core.di.IServiceComponent
import com.unity3d.services.core.di.ServiceProvider
import com.unity3d.services.core.di.inject

internal class OperativeEventJob(
    context: Context,
    workerParams: WorkerParameters
) : UniversalRequestJob(context, workerParams), IServiceComponent {

    private val getOperativeRequestPolicy: GetRequestPolicy by inject(ServiceProvider.NAMED_OPERATIVE_REQ)
    override val universalRequestEventSender: UniversalRequestEventSender by inject(ServiceProvider.OPERATIVE_EVENT_SENDER)

    override suspend fun doWork(): Result {
        return try {
            requestPolicy = getOperativeRequestPolicy()
            super.doWork()
        } catch (exception: Throwable) {
            logger.trace("OperativeEventJob failed to process work", exception)
            return Result.retry()
        }
    }
}