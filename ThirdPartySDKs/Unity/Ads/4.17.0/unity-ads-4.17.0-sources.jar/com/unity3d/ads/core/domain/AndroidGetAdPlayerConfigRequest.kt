package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.core.data.model.LoadConfigurationInternal
import gatewayprotocol.v1.AdFormatOuterClass.AdFormat
import gatewayprotocol.v1.UniversalRequestKt.payload
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest
import gatewayprotocol.v1.adPlayerConfigRequest

internal class AndroidGetAdPlayerConfigRequest(
    private val getUniversalRequestForPayLoad: GetUniversalRequestForPayLoad,
    private val mediationInfoConverter: MediationInfoConverter
) : GetAdPlayerConfigRequest {
    @OptIn(UnityAdsExperimental::class)
    override suspend fun invoke(
        placement: String,
        opportunityId: ByteString,
        configToken: ByteString,
        adFormat: AdFormat?,
        loadConfiguration: LoadConfigurationInternal?
    ): UniversalRequest {
        val request = adPlayerConfigRequest {
            configurationToken = configToken
            placementId = placement
            // webviewVersion
            impressionOpportunityId = opportunityId
            adFormat?.let { this.adFormat = it }
            loadConfiguration?.let {
                it.mediationAdUnitId?.let(::mediationAdUnitId::set)
                it.mediationInfo?.let { mediationInfoData ->
                    mediationInfo = mediationInfoConverter(mediationInfoData)
                }
                extras.putAll(it.extras)
            }
        }

        val payload = payload {
            adPlayerConfigRequest = request
        }

        return getUniversalRequestForPayLoad(payload)
    }
}