package com.unity3d.ads.core.domain

fun interface SafeCallbackInvoke {
    operator fun invoke(block: () -> Unit)
}