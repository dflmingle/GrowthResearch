package com.unity3d.ads.core.data.datasource

import com.unity3d.services.core.preferences.AndroidPreferences
import com.unity3d.services.core.properties.ClientProperties

class AndroidTcfDataSource : TcfDataSource {
    override val tcfString: String?
        get() = AndroidPreferences.getString(ClientProperties.getAppName() + "_settings", TCF_TCSTRING_KEY)

    companion object {
        const val TCF_TCSTRING_KEY = "IABTCF_TCString"
    }
}