package com.unity3d.ads.core.data.manager

import com.unity3d.ads.core.domain.offerwall.OfferwallEventData
import kotlinx.coroutines.flow.Flow

interface OfferwallManager {
    suspend fun getVersion(): String?
    suspend fun isConnected(): Boolean
    suspend fun isAdReady(placementName: String): Boolean
    suspend fun loadAd(placementName: String)
    fun showAd(placementName: String): Flow<OfferwallEventData>
}