package com.unity3d.ads

@UnityAdsExperimental
class BannerSize(val width: Int, val height: Int) {
    companion object {
        val leaderboard = BannerSize(728, 90)
        val iabStandard = BannerSize(468, 60)
        val standard = BannerSize(320, 50)
    }
}
