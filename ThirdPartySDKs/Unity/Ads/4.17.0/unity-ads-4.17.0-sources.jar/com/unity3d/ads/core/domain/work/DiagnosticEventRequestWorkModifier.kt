package com.unity3d.ads.core.domain.work

import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.domain.SendDiagnosticEvent
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest
import gatewayprotocol.v1.copy

internal class DiagnosticEventRequestWorkModifier(
    private val sessionRepository: SessionRepository,
) {
    operator fun invoke(
        universalRequest: UniversalRequest
    ): UniversalRequest = universalRequest.copy {
        payload = payload.copy {
            diagnosticEventRequest = diagnosticEventRequest.copy {
                val modifiedBatch = batch.map {
                    it.copy {
                        stringTags.put(SendDiagnosticEvent.SAME_SESSION, (universalRequest.sharedData.sessionToken == sessionRepository.sessionToken).toString())
                    }
                }
                batch.clear()
                batch.addAll(modifiedBatch)
            }
        }
    }

}