package com.unity3d.ads.core.data.model

import com.unity3d.ads.UnityAds.UnityAdsShowCompletionState
import com.unity3d.ads.UnityAds.UnityAdsShowError

interface Listeners {
    fun onError(placementId: String, error: UnityAdsShowError, message: String) {}
    fun onStart(placementId: String) {}
    fun onClick(placementId: String) {}
    fun onRewarded(placementId: String) {}
    fun onComplete(placementId: String, state: UnityAdsShowCompletionState) {}
    fun onLeftApplication(placementId: String) {}
}