package com.unity3d.ads.core.data.datasource

import com.google.protobuf.ByteString
import com.unity3d.ads.datastore.ByteStringStoreOuterClass.ByteStringStore

interface ByteStringDataSource {
    suspend fun get(): ByteStringStore
    suspend fun set(data: ByteString)
}