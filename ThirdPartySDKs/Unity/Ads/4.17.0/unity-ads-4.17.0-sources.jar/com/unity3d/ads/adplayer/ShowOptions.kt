package com.unity3d.ads.adplayer

interface ShowOptions
