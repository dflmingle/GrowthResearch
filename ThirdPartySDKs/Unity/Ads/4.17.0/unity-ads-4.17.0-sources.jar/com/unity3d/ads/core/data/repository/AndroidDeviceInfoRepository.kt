package com.unity3d.ads.core.data.repository

import com.google.protobuf.ByteString
import com.unity3d.ads.core.data.datasource.DynamicDeviceInfoDataSource
import com.unity3d.ads.core.data.datasource.PrivacyDeviceInfoDataSource
import com.unity3d.ads.core.data.datasource.StaticDeviceInfoDataSource
import com.unity3d.ads.core.extensions.toByteString
import gatewayprotocol.v1.AllowedPiiOuterClass.AllowedPii
import gatewayprotocol.v1.DynamicDeviceInfoOuterClass.DynamicDeviceInfo
import gatewayprotocol.v1.PiiOuterClass.Pii
import gatewayprotocol.v1.StaticDeviceInfoOuterClass.StaticDeviceInfo
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

internal class AndroidDeviceInfoRepository(
    private val staticDeviceInfoDataSource: StaticDeviceInfoDataSource,
    private val dynamicDeviceInfoDataSource: DynamicDeviceInfoDataSource,
    private val privacyDeviceInfoDataSource: PrivacyDeviceInfoDataSource,
    private val sessionRepository: SessionRepository
) : DeviceInfoRepository {
    override val allowedPii = MutableStateFlow<AllowedPii>(AllowedPii.getDefaultInstance())

    override suspend fun staticDeviceInfo(): StaticDeviceInfo = staticDeviceInfoDataSource.fetch(sessionRepository.nativeConfiguration.additionalStorePackagesList)

    override fun cachedStaticDeviceInfo(): StaticDeviceInfo = staticDeviceInfoDataSource.fetchCached()

    override val dynamicDeviceInfo: DynamicDeviceInfo
        get() = dynamicDeviceInfoDataSource.fetch()

    override val piiData: Pii
        get() = privacyDeviceInfoDataSource.fetch(allowed = allowedPii.value)

    override suspend fun getIdfi(): String = staticDeviceInfoDataSource.getIdfi()

    override suspend fun getAuidString(): String? = staticDeviceInfoDataSource.getAuid()

    override suspend fun getAuidByteString(): ByteString? {
        val auidString = getAuidString() ?: return null
        return try {
            UUID.fromString(auidString).toByteString()
        } catch (e: Throwable) {
            null
        }
    }

    override suspend fun getUnityBuildGuid(): String? = staticDeviceInfoDataSource.getUnityBuildGuid()

    override val analyticsUserId = staticDeviceInfoDataSource.analyticsUserId

    override val volumeSettingsChange = dynamicDeviceInfoDataSource.volumeSettingsChange
    override val ringerMode
        get() = dynamicDeviceInfoDataSource.getRingerMode()
    override val systemBootTime: Long
        get() = staticDeviceInfoDataSource.getSystemBootTime()
    override val orientation
        get() = dynamicDeviceInfoDataSource.getOrientation()
    override val connectionTypeStr
        get() = dynamicDeviceInfoDataSource.getConnectionTypeStr()
    override val currentUiTheme
        get() = dynamicDeviceInfoDataSource.getCurrentUiTheme()
    override val localeList
        get() = dynamicDeviceInfoDataSource.getLocaleList()
    override val appName: String
        get() = staticDeviceInfoDataSource.getAppName()
    override val model: String
        get() = staticDeviceInfoDataSource.getModel()
    override val manufacturer: String
        get() = staticDeviceInfoDataSource.getManufacturer()
    override val osVersion: String
        get() = staticDeviceInfoDataSource.getOsVersion()
    override val hasInternet: Boolean
        get() = dynamicDeviceInfoDataSource.hasInternet()
}