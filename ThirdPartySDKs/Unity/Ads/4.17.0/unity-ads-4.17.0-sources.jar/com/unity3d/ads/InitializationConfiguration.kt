package com.unity3d.ads

@UnityAdsExperimental
class InitializationConfiguration internal constructor(
    val gameId: String,
    val isTestModeEnabled: Boolean,
    val logLevel: LogLevel = LogLevel.INFO,
    val extras: Map<String, String> = emptyMap(),
    val mediationInfo: MediationInfo? = null,
) {
    class Builder(private val gameId: String) {
        private var logLevel: LogLevel = LogLevel.INFO
        private var mediationInfo: MediationInfo? = null
        private var extras: Map<String, String> = emptyMap()
        private var isTestModeEnabled: Boolean = false

        fun withLogLevel(logLevel: LogLevel): Builder {
            this.logLevel = logLevel
            return this
        }

        fun withMediationInfo(mediationInfo: MediationInfo?): Builder {
            this.mediationInfo = mediationInfo
            return this
        }

        fun withExtras(extras: Map<String, String>): Builder {
            this.extras = extras
            return this
        }

        fun withTestMode(isTestModeEnabled: Boolean): Builder {
            this.isTestModeEnabled = isTestModeEnabled
            return this
        }

        fun build(): InitializationConfiguration {
            return InitializationConfiguration(
                gameId,
                isTestModeEnabled,
                logLevel,
                extras,
                mediationInfo
            )
        }
    }
}