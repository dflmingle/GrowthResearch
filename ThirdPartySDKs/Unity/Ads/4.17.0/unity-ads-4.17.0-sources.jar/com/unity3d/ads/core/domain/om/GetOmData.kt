package com.unity3d.ads.core.domain.om

import com.unity3d.ads.core.data.model.OMData

interface GetOmData {
    suspend operator fun invoke(): OMData
}