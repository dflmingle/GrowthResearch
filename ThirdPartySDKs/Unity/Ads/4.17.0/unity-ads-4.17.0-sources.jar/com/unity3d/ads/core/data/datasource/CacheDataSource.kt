package com.unity3d.ads.core.data.datasource

import com.unity3d.ads.core.data.model.CacheResult
import java.io.File

interface CacheDataSource {
    suspend fun getFile(cachePath: File, fileName: String, url: String? = null, priority: Int? = Int.MAX_VALUE): CacheResult
}