package com.unity3d.ads.adplayer

enum class HandlerType(val jsPath: String) {
    CALLBACK("handleCallback"),
    INVOCATION("handleInvocation"),
    EVENT("handleEvent")
}
