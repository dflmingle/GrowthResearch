package com.unity3d.ads.core.domain

import com.unity3d.ads.adplayer.model.WebViewClientError
import com.unity3d.ads.core.data.model.AdObject

class AndroidSendWebViewClientErrorDiagnostics(
    private val sendDiagnosticEvent: SendDiagnosticEvent
) : SendWebViewClientErrorDiagnostics {
    override fun invoke(errors: List<WebViewClientError>, adObject: AdObject) {
        errors.forEach {
            val tags = if (!it.url.isNullOrEmpty()) {
                mapOf(
                    SendDiagnosticEvent.WEBVIEW_URL to it.url,
                )
            } else {
                null
            }
            val intTags = mutableMapOf(
                SendDiagnosticEvent.REASON to it.reason.code,
            )
            if (it.statusCode != null) intTags[SendDiagnosticEvent.WEBVIEW_ERROR_CODE] = it.statusCode

            sendDiagnosticEvent(SendDiagnosticEvent.WEBVIEW_ERROR, tags = tags, intTags = intTags, adObject = adObject)
        }
    }
}