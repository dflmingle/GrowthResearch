package com.unity3d.ads.core.domain.om

interface InitializeOMSDK {
    suspend operator fun invoke()
}