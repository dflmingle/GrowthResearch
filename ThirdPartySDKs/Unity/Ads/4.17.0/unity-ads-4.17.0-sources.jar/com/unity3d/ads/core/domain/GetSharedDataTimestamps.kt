package com.unity3d.ads.core.domain

import gatewayprotocol.v1.TimestampsOuterClass.Timestamps

interface GetSharedDataTimestamps {
    operator fun invoke(): Timestamps
}