package com.unity3d.ads.core.domain

import com.unity3d.services.core.network.core.HttpClient

interface HttpClientProvider {
    suspend operator fun invoke(): HttpClient
}