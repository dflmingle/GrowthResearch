package com.unity3d.ads.core.domain

import android.net.Uri

class AndroidRemoveUrlQuery : RemoveUrlQuery {
    override fun invoke(url: String): String = Uri.parse(url).buildUpon().clearQuery().build().toString()
}