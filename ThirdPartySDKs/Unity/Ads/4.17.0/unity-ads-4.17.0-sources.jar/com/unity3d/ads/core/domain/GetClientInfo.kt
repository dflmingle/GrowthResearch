package com.unity3d.ads.core.domain

import gatewayprotocol.v1.ClientInfoOuterClass.ClientInfo

interface GetClientInfo {
    suspend operator fun invoke(): ClientInfo
}
