package com.unity3d.ads.core.domain

import com.unity3d.ads.UnityAdsError
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.core.data.model.AdObject

@OptIn(UnityAdsExperimental::class)
interface InternalLoadListener {
    fun onAdLoaded(adObject: AdObject)
    fun onAdLoadFail(error: UnityAdsError)
}