package com.unity3d.ads.core.domain

interface SetGameId {
    operator fun invoke(gameId: String?)
}