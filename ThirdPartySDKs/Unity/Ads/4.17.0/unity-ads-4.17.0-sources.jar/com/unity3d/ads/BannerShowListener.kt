package com.unity3d.ads

@UnityAdsExperimental
interface BannerShowListener {
   fun onImpression(banner: BannerAd)
   fun onClicked(banner: BannerAd)
   fun onFailedToShow(banner: BannerAd, error: UnityAdsError)
}