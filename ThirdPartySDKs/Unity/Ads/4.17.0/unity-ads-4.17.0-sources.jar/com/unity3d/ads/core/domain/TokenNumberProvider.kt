package com.unity3d.ads.core.domain

fun interface TokenNumberProvider {
    operator fun invoke(): Int
}