package com.unity3d.ads.core.domain.events

import gatewayprotocol.v1.TransactionEventRequestOuterClass.TransactionData
import gatewayprotocol.v1.TransactionEventRequestOuterClass.TransactionEventRequest
import gatewayprotocol.v1.TransactionEventRequestOuterClass.TransactionOrigin

fun interface GetTransactionRequest {
    suspend operator fun invoke(
        transactionDataList: List<TransactionData>,
        googlePlayBillingLibraryVersion: String,
        transactionOrigin: TransactionOrigin
    ): TransactionEventRequest
}