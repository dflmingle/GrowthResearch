package com.unity3d.ads.core.domain

import gatewayprotocol.v1.InitializationDataOuterClass.InitializationData

interface GetInitializationData {
    suspend operator fun invoke(): InitializationData
}