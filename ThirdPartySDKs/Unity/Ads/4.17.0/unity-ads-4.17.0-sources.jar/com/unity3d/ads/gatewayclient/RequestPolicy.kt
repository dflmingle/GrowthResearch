package com.unity3d.ads.gatewayclient

data class RequestPolicy(
    val maxDuration: Int,
    val retryMaxInterval: Int,
    val retryWaitBase: Int,
    val retryJitterPct: Float,
    val retryScalingFactor: Float,
    val connectTimeout: Int,
    val readTimeout: Int,
    val writeTimeout: Int,
    val overallTimeout: Int,
    val shouldStoreLocally: Boolean
)