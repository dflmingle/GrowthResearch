package com.unity3d.ads.core.data.model

sealed class CacheResult {
    data class Success(val cachedFile: CachedFile, val source: CacheSource) : CacheResult()
    data class Failure(val error: CacheError, val source: CacheSource = CacheSource.LOCAL, val reason: Throwable? = null) : CacheResult()
}