package com.unity3d.ads.core.extensions

import android.content.Context
import com.unity3d.services.UnityAdsConstants.Cache.DATASTORE_PATH
import java.io.File

fun Context.unityAdsDataStoreFile(fileName: String): File =
    File(applicationContext.filesDir, "$DATASTORE_PATH$fileName")