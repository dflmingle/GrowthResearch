package com.unity3d.ads.core.data.model

enum class StorageType {
    EXTERNAL, INTERNAL
}