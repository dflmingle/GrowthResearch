package com.unity3d.ads.core.domain

import android.app.Activity
import android.content.Context
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.model.ShowEvent
import kotlinx.coroutines.flow.Flow

interface Show {
    operator fun invoke(adObject: AdObject, showOptions: UnityAdsShowOptions?): Flow<ShowEvent>
    suspend fun terminate(adObject: AdObject)
}