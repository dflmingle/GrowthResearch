package com.unity3d.ads.core.domain

import java.io.File

class CommonCreateFile : CreateFile {
    override fun invoke(parent: File, child: String): File {
        return File(parent, child)
    }

    override fun invoke(pathname: String): File {
        return File(pathname)
    }
}