package com.unity3d.ads.core.data.model

import com.unity3d.ads.UnityAdsExperimental

@OptIn(UnityAdsExperimental::class)
internal data class ShowConfigurationInternal(
    val customRewardString: String? = null,
    val extras: Map<String, String> = emptyMap(),
)
