package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.repository.SessionRepository

internal class CommonSetGameId(
    private val sessionRepository: SessionRepository
) : SetGameId {
    override fun invoke(gameId: String?) {
        sessionRepository.gameId = gameId
    }
}