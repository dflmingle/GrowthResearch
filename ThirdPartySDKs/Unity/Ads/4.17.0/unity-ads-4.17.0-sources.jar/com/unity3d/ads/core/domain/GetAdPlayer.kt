package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import com.unity3d.ads.adplayer.AdPlayer
import com.unity3d.ads.adplayer.AndroidWebViewContainer
import com.unity3d.ads.adplayer.WebViewBridge
import gatewayprotocol.v1.DiagnosticEventRequestOuterClass.DiagnosticAdType

fun interface GetAdPlayer {
    operator fun invoke(
        webviewBridge: WebViewBridge,
        webviewContainer: AndroidWebViewContainer,
        opportunityId: ByteString,
        adType: DiagnosticAdType
    ): AdPlayer
}