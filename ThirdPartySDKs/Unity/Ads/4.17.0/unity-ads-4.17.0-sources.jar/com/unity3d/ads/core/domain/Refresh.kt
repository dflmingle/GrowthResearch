package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import gatewayprotocol.v1.AdDataRefreshResponseOuterClass.AdDataRefreshResponse

interface Refresh {
    suspend operator fun invoke(opportunityId: ByteString, adDataRefreshToken: ByteString): AdDataRefreshResponse
}