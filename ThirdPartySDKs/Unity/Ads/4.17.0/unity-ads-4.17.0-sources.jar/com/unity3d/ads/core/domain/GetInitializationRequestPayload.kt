package com.unity3d.ads.core.domain

import gatewayprotocol.v1.InitializationRequestOuterClass.InitializationRequest

interface GetInitializationRequestPayload {
    suspend operator fun invoke(): InitializationRequest
}