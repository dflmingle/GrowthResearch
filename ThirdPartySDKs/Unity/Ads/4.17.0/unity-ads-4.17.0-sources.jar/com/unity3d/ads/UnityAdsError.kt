package com.unity3d.ads

import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode
import java.lang.String.format

@UnityAdsExperimental
class UnityAdsError internal constructor(
    val code: Int,
    val message: String
)

private const val BOLD_LOAD_FAIL_MSG_PREF = "Unity Ads SDK ad load failed:"
const val MSG_BOLD_LOAD_FAIL_TIME_OUT = "$BOLD_LOAD_FAIL_MSG_PREF Request timed out. Check your network connection and try again later.\n"
const val MSG_BOLD_LOAD_FAIL_NO_FILL = "$BOLD_LOAD_FAIL_MSG_PREF No ad fill available for the requested placement."
const val MSG_BOLD_LOAD_FAIL_SDK_NOT_INITIALIZED = "$BOLD_LOAD_FAIL_MSG_PREF The Unity Ads SDK is not initialized. Initialize the SDK before loading ads."
const val MSG_BOLD_LOAD_FAIL_PLACEMENT_NOT_FOUND = "$BOLD_LOAD_FAIL_MSG_PREF Placement not found. Use the correct placement ID from your Unity Ads Monetization dashboard."
const val MSG_BOLD_LOAD_FAIL_PROTO_ERROR = "$BOLD_LOAD_FAIL_MSG_PREF Internal protocol error occurred. Try again later."
const val MSG_BOLD_LOAD_FAIL_UNSUPPORTED_PLACEMENT = "$BOLD_LOAD_FAIL_MSG_PREF The placement ID doesn’t match the ad format or the placement type. Check your placement settings in the Monetization dashboard."
const val MSG_BOLD_LOAD_FAIL_NETWORK_ERROR = "$BOLD_LOAD_FAIL_MSG_PREF Network error occurred. Check your network connection and try again later."
const val MSG_BOLD_LOAD_FAIL_INSUFFICIENT_STORAGE = "$BOLD_LOAD_FAIL_MSG_PREF Insufficient storage space on the device. Free up space and try again."
const val MSG_BOLD_LOAD_FAIL_PARSING_ERROR = "$BOLD_LOAD_FAIL_MSG_PREF Internal error occurred while parsing ad response."

fun PublicErrorCode.getLoadErrorMsg(): String? {
    return when (this) {
        PublicErrorCode.PUBLIC_ERROR_CODE_TIMEOUT -> MSG_BOLD_LOAD_FAIL_TIME_OUT
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_NO_FILL -> MSG_BOLD_LOAD_FAIL_NO_FILL
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_NOT_INITIALIZED -> MSG_BOLD_LOAD_FAIL_SDK_NOT_INITIALIZED
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_PLACEMENT_NOT_FOUND -> MSG_BOLD_LOAD_FAIL_PLACEMENT_NOT_FOUND
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_PROTO -> MSG_BOLD_LOAD_FAIL_PROTO_ERROR
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_UNSUPPORTED_PLACEMENT -> MSG_BOLD_LOAD_FAIL_UNSUPPORTED_PLACEMENT
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_NETWORK -> MSG_BOLD_LOAD_FAIL_NETWORK_ERROR
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_FILE_SYSTEM -> MSG_BOLD_LOAD_FAIL_INSUFFICIENT_STORAGE
        PublicErrorCode.PUBLIC_ERROR_CODE_LOAD_ADVIEWER -> MSG_BOLD_LOAD_FAIL_PARSING_ERROR
        else -> null
    }
}

const val MSG_INIT_FAIL_TIMEOUT = "Unity Ads SDK initialization failed: Request timed out. Check your network connection and try again later."
const val MSG_INIT_FAIL_UNKNOWN_ERROR = "Unity Ads SDK initialization failed: Unknown error occurred."
const val MSG_INIT_FAIL_GAME_NOT_FOUND = "Invalid Game ID: %s. Verify the Game ID in your Unity Ads Monetization dashboard."
const val MSG_INIT_FAIL_WRONG_PLATFORM = "Unity Ads SDK initialization failed: Game ID mismatch. Use the correct Game ID for the target platform from your Unity Ads Monetization dashboard."
const val MSG_INIT_FAIL_PARSING_ERROR = "Unity Ads SDK initialization failed: Internal protocol error occurred.Try again later."
const val MSG_INIT_FAIL_SYSTEM_ERROR = "Unity Ads SDK initialization failed: System error occurred. Try again later."
const val MSG_INIT_FAIL_NETWORK_ERROR = "Unity Ads SDK initialization failed: Network error occurred. Check your network connection and try again later."
const val MSG_INIT_FAIL_INSUFFICIENT_STORAGE = "Unity Ads SDK initialization failed: Insufficient storage space on the device. Free up space and try again."

fun PublicErrorCode.getInitErrorMsg(gameId: String? = null): String? {
    return when (this) {
        PublicErrorCode.PUBLIC_ERROR_CODE_TIMEOUT -> MSG_INIT_FAIL_TIMEOUT
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_UNKNOWN -> MSG_INIT_FAIL_UNKNOWN_ERROR
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_NOT_FOUND -> format(
            MSG_INIT_FAIL_GAME_NOT_FOUND, gameId
        )
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_MISMATCHED_PLATFORM -> MSG_INIT_FAIL_WRONG_PLATFORM
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_PROTO -> MSG_INIT_FAIL_PARSING_ERROR
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_INTERNAL_SYSTEM -> MSG_INIT_FAIL_SYSTEM_ERROR
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_NETWORK -> MSG_INIT_FAIL_NETWORK_ERROR
        PublicErrorCode.PUBLIC_ERROR_CODE_INIT_FILE_SYSTEM -> MSG_INIT_FAIL_INSUFFICIENT_STORAGE
        else -> null
    }
}

const val MSG_BOLD_SHOW_FAIL_AD_OBJECT_EXPIRED = "Unity Ads SDK ad show failed: The ad has expired. Load a new ad."
const val MSG_BOLD_SHOW_FAIL_TIMEOUT = "Unity Ads SDK ad show failed: Request timed out. Check your network connection and try again later."
const val MSG_BOLD_SHOW_FAIL_ALREADY_SHOWING = "Unity Ads SDK ad show failed: An ad is already being shown. Wait until the current ad finishes before showing a new one."
const val MSG_BOLD_SHOW_FAIL_INTERNAL_ERROR = "Unity Ads SDK ad show failed: Internal error occurred."

fun PublicErrorCode.getShowErrorMsg(): String {
    return when (this) {
        PublicErrorCode.PUBLIC_ERROR_CODE_TIMEOUT -> MSG_BOLD_SHOW_FAIL_TIMEOUT
        PublicErrorCode.PUBLIC_ERROR_CODE_SHOW_EXPIRED -> MSG_BOLD_SHOW_FAIL_AD_OBJECT_EXPIRED
        PublicErrorCode.PUBLIC_ERROR_CODE_SHOW_ALREADY_SHOWN -> MSG_BOLD_SHOW_FAIL_ALREADY_SHOWING
        else -> MSG_BOLD_SHOW_FAIL_INTERNAL_ERROR
    }
}
