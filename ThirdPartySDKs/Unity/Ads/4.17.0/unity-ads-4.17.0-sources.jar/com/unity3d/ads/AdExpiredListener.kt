package com.unity3d.ads

@UnityAdsExperimental
fun interface AdExpiredListener<UnityAd> {
    fun onAdExpired(ad: UnityAd)
}
