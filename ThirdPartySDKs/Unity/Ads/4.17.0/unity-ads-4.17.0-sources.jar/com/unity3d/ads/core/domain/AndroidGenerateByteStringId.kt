package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import com.unity3d.ads.core.extensions.toByteString

import java.util.UUID


class AndroidGenerateByteStringId : GetByteStringId {
    override fun invoke(): ByteString = UUID.randomUUID().toByteString()
}