package com.unity3d.ads.core.domain.scar

import com.unity3d.scar.adapter.common.GMAEvent
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent

data class GmaEventData (
    val gmaEvent: GMAEvent,
    val bannerEvent: BannerEvent? = null,
    val opportunityId: String? = null,
    val placementId: String? = null,
    val queryId: String? = null,
    val errorMessage: String? = null,
    val errorCode: Int? = null
)