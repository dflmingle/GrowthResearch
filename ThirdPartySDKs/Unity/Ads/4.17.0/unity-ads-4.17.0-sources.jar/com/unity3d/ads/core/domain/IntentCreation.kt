package com.unity3d.ads.core.domain

import android.content.Intent


fun interface IntentCreation {
    operator fun invoke(
        url: String,
        packageName: String?,
        action: String?,
        extras: Map<String, Any?>?,
    ): Intent
}