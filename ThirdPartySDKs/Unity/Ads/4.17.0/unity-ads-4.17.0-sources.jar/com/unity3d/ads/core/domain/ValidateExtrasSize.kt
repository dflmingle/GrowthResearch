package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.extensions.sizeInKb

internal class ValidateExtrasSize(
    private val sessionRepository: SessionRepository,
    private val sendDiagnosticEvent: SendDiagnosticEvent,
) {
    operator fun invoke(extras: Map<String, String>, source: String, adObject: AdObject? = null) {
        if (extras.isEmpty()) return

        val maxSizeKb = sessionRepository.nativeConfiguration.maxExtrasSizeKb
        if (maxSizeKb <= 0) return

        val actualSizeKb = extras.sizeInKb()

        if (actualSizeKb >= maxSizeKb) {
            sendDiagnosticEvent(
                event = SendDiagnosticEvent.EXTRAS_EXCEEDED_SIZE,
                tags = mapOf(
                    SendDiagnosticEvent.SOURCE to source,
                    SendDiagnosticEvent.SIZE_KB to actualSizeKb.toString()
                ),
                adObject = adObject,
            )
        }
    }
}
