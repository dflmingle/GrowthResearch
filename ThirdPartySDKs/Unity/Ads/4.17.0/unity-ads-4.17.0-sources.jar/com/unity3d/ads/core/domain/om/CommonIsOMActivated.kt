package com.unity3d.ads.core.domain.om

import com.unity3d.ads.core.data.repository.OpenMeasurementRepository



class CommonIsOMActivated(
    private val openMeasurementRepository: OpenMeasurementRepository
) : IsOMActivated {
    override operator fun invoke(): Boolean = openMeasurementRepository.isOMActive
}