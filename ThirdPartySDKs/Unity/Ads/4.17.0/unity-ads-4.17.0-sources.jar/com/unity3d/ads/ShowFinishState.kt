package com.unity3d.ads

@UnityAdsExperimental
enum class ShowFinishState {
    SKIPPED,
    COMPLETED,
}