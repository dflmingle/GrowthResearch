package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.repository.SessionRepository

internal class CommonGetGameId(private val sessionRepository: SessionRepository): GetGameId {
    override fun invoke(): String? = sessionRepository.gameId
}