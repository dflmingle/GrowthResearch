package com.unity3d.ads.core.domain

import com.unity3d.ads.IUnityAdsTokenListener
import com.unity3d.ads.TokenConfiguration

interface GetAsyncHeaderBiddingToken {
    suspend operator fun invoke(tokenNumber: Int, tokenConfiguration: TokenConfiguration?, listener: IUnityAdsTokenListener?)
}