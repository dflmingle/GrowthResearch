package com.unity3d.ads.core.domain.om

import com.unity3d.ads.core.data.model.OMData
import com.unity3d.ads.core.data.repository.OpenMeasurementRepository



class CommonGetOmData(
    private val openMeasurementRepository: OpenMeasurementRepository
) : GetOmData {
    override suspend fun invoke(): OMData = openMeasurementRepository.omData
}