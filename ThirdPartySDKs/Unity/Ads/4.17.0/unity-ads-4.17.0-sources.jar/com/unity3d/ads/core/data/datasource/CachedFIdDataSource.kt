package com.unity3d.ads.core.data.datasource

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import java.util.concurrent.atomic.AtomicBoolean

class CachedFIdDataSource(
    dispatcher: CoroutineDispatcher,
    private val dataSource: FIdDataSource
) : FIdDataSource {
    private var loaded = AtomicBoolean(false)
    @Volatile
    private var value: String? = null
    private var scope = CoroutineScope(dispatcher) + CoroutineExceptionHandler { _, _ -> }

    init {
        scope.launch {
                value = dataSource()
        }.invokeOnCompletion({
            scope.cancel()
            loaded.set(true)
        })
    }

    override operator fun invoke(): String? {
        if (loaded.get()) {
            return value
        }

        return null
    }
}
