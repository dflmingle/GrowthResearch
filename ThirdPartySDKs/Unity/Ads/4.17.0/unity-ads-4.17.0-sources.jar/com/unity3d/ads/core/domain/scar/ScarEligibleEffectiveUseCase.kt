package com.unity3d.ads.core.domain.scar

import com.unity3d.ads.TokenConfiguration
import gatewayprotocol.v1.AdFormatOuterClass.AdFormat

fun interface ScarEligibleEffectiveUseCase {
    operator fun invoke(tokenConfiguration: TokenConfiguration?): List<AdFormat>
}