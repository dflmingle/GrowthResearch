package com.unity3d.ads.core.data.model

sealed class ScarEvent {
    object Show : ScarEvent()
}