package com.unity3d.ads.core.data.manager

import com.unity3d.services.core.properties.SdkProperties

interface SDKPropertiesManager {
    fun setInitialized(initialized: Boolean)
    fun setInitializeState(initializeState: SdkProperties.InitializationState)
    fun getCurrentInitializationState(): SdkProperties.InitializationState
    fun setInitializationTime()
    fun setInitializationTimeSinceEpoch()
}