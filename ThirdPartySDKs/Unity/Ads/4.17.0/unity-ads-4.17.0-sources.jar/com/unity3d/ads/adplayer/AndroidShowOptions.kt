package com.unity3d.ads.adplayer

import android.app.Activity
import java.lang.ref.WeakReference

data class AndroidShowOptions(
    val unityAdsShowOptions: Map<String, Any?>?,
    val placementId: String? = null,
    val isScarAd: Boolean = false,
    val scarQueryId: String? = null,
    val scarAdString: String? = null,
    val scarAdUnitId: String? = null,
    val isOfferwallAd: Boolean = false,
    val offerwallPlacementName: String? = null
) : ShowOptions