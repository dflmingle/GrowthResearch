package com.unity3d.ads.core.domain.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.unity3d.ads.core.data.datasource.UniversalRequestDataSource
import com.unity3d.ads.core.domain.events.UniversalRequestEventSender
import com.unity3d.ads.core.log.Logger
import com.unity3d.ads.gatewayclient.RequestPolicy
import com.unity3d.services.core.di.IServiceComponent
import com.unity3d.services.core.di.ServiceProvider
import com.unity3d.services.core.di.inject
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

internal abstract class UniversalRequestJob(
    context: Context,
    protected val workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams), IServiceComponent {
    lateinit var requestPolicy: RequestPolicy

    protected open val universalRequestEventSender: UniversalRequestEventSender by inject(ServiceProvider.UNIVERSAL_EVENT_SENDER)
    protected val universalRequestDataSource: UniversalRequestDataSource by inject()
    protected val logger: Logger by inject()

    override suspend fun doWork(): Result {
        val universalRequestId =
            workerParams.inputData.getString(UniversalRequestWorkerData.KEY_UNIVERSAL_REQUEST_ID)?: return Result.success()
        val rawUniversalRequest = runCatching {
            universalRequestDataSource.get().getUniversalRequestMapOrThrow(universalRequestId)
        }.getOrElse {
            // Request is not in storage anymore, mark as success so that its cleared from WorkDB
            return Result.success()
        }
        val universalRequest = UniversalRequest.parseFrom(rawUniversalRequest)
        val universalRequestEventSender = runCatching {
            universalRequestEventSender(universalRequest, requestPolicy)
        }
        return if (universalRequestEventSender.isSuccess) {
            universalRequestDataSource.remove(universalRequestId)
            Result.success()
        } else {
            Result.retry()
        }
    }
}