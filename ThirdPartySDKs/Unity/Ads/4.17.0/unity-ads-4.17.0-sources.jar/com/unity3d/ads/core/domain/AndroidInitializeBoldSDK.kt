package com.unity3d.ads.core.domain


import com.unity3d.ads.core.data.manager.SDKPropertiesManager
import com.unity3d.ads.core.data.manager.StorageManager
import com.unity3d.ads.core.data.model.InitializationState
import com.unity3d.ads.core.data.model.OperationType
import com.unity3d.ads.core.data.model.exception.GatewayException
import com.unity3d.ads.core.data.model.exception.InitializationException
import com.unity3d.ads.core.data.repository.DiagnosticEventRepository
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INIT_FAILURE
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INIT_STARTED
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INIT_SUCCESS
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.NEW_API
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.IS_RETRY
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.KOTLIN_VERSION
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.OPERATION
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_DEBUG
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_GATEWAY
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_INVALID_GAME_ID
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.SOURCE
import com.unity3d.ads.core.domain.events.EventObservers
import com.unity3d.ads.core.domain.om.InitializeOMSDK
import com.unity3d.ads.core.extensions.elapsedMillis
import com.unity3d.ads.core.extensions.toUUID
import com.unity3d.ads.core.log.Logger
import com.unity3d.ads.gatewayclient.GatewayClient
import com.unity3d.services.UnityAdsConstants
import com.unity3d.services.core.configuration.ConfigurationReader
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlin.time.ExperimentalTime
import kotlin.time.TimeMark
import kotlin.time.TimeSource

@OptIn(ExperimentalTime::class)

internal class AndroidInitializeBoldSDK(
    private val defaultDispatcher: CoroutineDispatcher,
    private val initializeOM: InitializeOMSDK,
    private val getInitializeRequest: GetInitializationRequest,
    private val getRequestPolicy: GetRequestPolicy,
    private val cleanAssets: CleanAssets,
    private val handleGatewayInitializationResponse: HandleGatewayInitializationResponse,
    private val gatewayClient: GatewayClient,
    private val sessionRepository: SessionRepository,
    private val eventObservers: EventObservers,
    private val triggerInitializeListener: TriggerInitializeListener,
    private val sendDiagnosticEvent: SendDiagnosticEvent,
    private val diagnosticEventRepository: DiagnosticEventRepository,
    private val storageManager: StorageManager,
    private val legacyConfigurationReader: ConfigurationReader,
    private val sdkPropertiesManager: SDKPropertiesManager,
    private val getGameId: GetGameId,
    private val logger: Logger,
    private val handleFocusCounters: AndroidHandleFocusCounters,
) : InitializeBoldSDK {

    override suspend fun invoke(source: String) = withContext(defaultDispatcher) {
        val startTime = TimeSource.Monotonic.markNow()
        val isRetry = !sessionRepository.isFirstInitAttempt

        try {
            withTimeout(UnityAdsConstants.Timeout.INIT_TIMEOUT_MS) {
                initializationStart(source, isRetry)
                checkCanInitialize()
                val initializationRequest = getInitializeRequest()
                val requestPolicy = getRequestPolicy()
                val response = gatewayClient.request(request = initializationRequest, requestPolicy = requestPolicy, operationType = OperationType.INITIALIZATION)
                handleGatewayInitializationResponse(response)
            }
        } catch (e: Exception) {
            val failure = InitializationException.parseFrom(e)
            if (e is GatewayException) {
                sessionRepository.shouldInitialize = false
            }
            initializationFailure(startTime, failure, source, isRetry)
            return@withContext
        }

        initializationSuccess(startTime, source, isRetry)
    }

    private fun checkCanInitialize() {
        if (!sessionRepository.shouldInitialize) {
            throw sessionRepository.initializationError ?: InitializationException(message = MSG_GATEWAY_DENIED, reason = REASON_GATEWAY, reasonDebug = "!sessionRepository.shouldInitialize")
        }

        val gameId = getGameId()
        if (gameId == null) {
            throw InitializationException(message = "gameId is null.", reason = REASON_INVALID_GAME_ID, reasonDebug = "null")
        }
    }

    private suspend fun initializationStart(source: String, isRetry: Boolean) {
        logger.info(getInitLog())
        sdkPropertiesManager.setInitializationTime()
        sdkPropertiesManager.setInitializationTimeSinceEpoch()
        sendDiagnosticEvent(
            event = INIT_STARTED,
            tags = getTags(source = source, isRetry = isRetry) + mapOf(KOTLIN_VERSION to KotlinVersion.CURRENT.toString())
        )
        sessionRepository.initializationState = InitializationState.INITIALIZING
        eventObservers()
    }

    private fun getInitLog(): String {
        return "Initializing SDK ${UnityAdsConstants.ClientInfo.SDK_VERSION_NAME} " +
            "${UnityAdsConstants.ClientInfo.SDK_VERSION} " +
            "with game id ${getGameId()} " +
            "in ${if (sessionRepository.isTestModeEnabled) "test" else "production"} mode, " +
            "session ${sessionRepository.sessionId.toUUID()}"
    }

    private suspend fun initializationSuccess(startTime: TimeMark, source: String, isRetry: Boolean) {
        logger.info("Initialized successfully")
        sendDiagnosticEvent(
            event = INIT_SUCCESS,
            value = startTime.elapsedMillis(),
            tags = getTags(
                source = source,
                isRetry = isRetry
            )
        )
        storageManager.hasInitialized()
        initializeOM()
        cleanAssets()
        handleFocusCounters()
        // We persist config and remove legacy config from disk so we can be ready for clean slate in case we switch back to non gateway flow.
        sessionRepository.persistNativeConfiguration()
        legacyConfigurationReader.currentConfiguration.deleteFromDisk()
        sessionRepository.initializationState = InitializationState.INITIALIZED
        sdkPropertiesManager.setInitialized(true)
        triggerInitializeListener.success()
        setupDiagnosticEvents()
    }

    private fun initializationFailure(
        startTime: TimeMark,
        e: InitializationException,
        source: String,
        isRetry: Boolean
    ) {
        logger.error("Initialization failed: ${e.message}", e)
        sendDiagnosticEvent(event = INIT_FAILURE, value = startTime.elapsedMillis(), tags = getTags(e, source, isRetry))
        sessionRepository.initializationState = InitializationState.FAILED
        sessionRepository.initializationError = e
        sdkPropertiesManager.setInitialized(false)
        triggerInitializeListener.error(e)
        setupDiagnosticEvents()
    }

    private fun getTags(e: InitializationException? = null, source: String, isRetry: Boolean): Map<String, String> {
        return buildMap {
            put(OPERATION, OperationType.INITIALIZATION.toString())
            e?.let { put(REASON, e.reason) }
            put(SOURCE, source)
            put(IS_RETRY, isRetry.toString())
            put(NEW_API, (sessionRepository.initializationConfiguration != null).toString())
            e?.reasonDebug?.let { put(REASON_DEBUG, e.reasonDebug) }
        }
    }

    private fun setupDiagnosticEvents() {
        val config = sessionRepository.nativeConfiguration.diagnosticEvents
        diagnosticEventRepository.configure(config)
    }

    companion object {
        const val MSG_GATEWAY_DENIED = "Gateway communication failure"
        const val MSG_TIMEOUT = "Timeout"
        const val MSG_NETWORK = "Network"
        const val MSG_UNKNOWN = "Initialization failure"
    }
}
