package com.unity3d.ads

@UnityAdsExperimental
enum class LogLevel(internal val level: Int) {
    DISABLED(0), ERROR(1), INFO(2), DEBUG(3), TRACE(4);
}