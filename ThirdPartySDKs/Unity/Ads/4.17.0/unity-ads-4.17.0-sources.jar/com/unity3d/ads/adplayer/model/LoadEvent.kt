package com.unity3d.ads.adplayer.model

sealed class LoadEvent {
    object Completed : LoadEvent()
    data class Error(val message: String, val errorCode: Int) : LoadEvent()
}
