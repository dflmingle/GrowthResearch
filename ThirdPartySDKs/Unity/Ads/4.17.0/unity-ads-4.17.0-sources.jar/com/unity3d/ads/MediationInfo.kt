package com.unity3d.ads

@UnityAdsExperimental
class MediationInfo(
    name: String,
    val version: String,
    val adapterVersion: String,
) {
    val name: String = name.lowercase()
}
