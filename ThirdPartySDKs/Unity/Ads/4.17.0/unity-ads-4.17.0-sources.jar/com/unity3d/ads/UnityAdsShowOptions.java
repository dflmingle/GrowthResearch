package com.unity3d.ads;

import androidx.annotation.RestrictTo;
import com.unity3d.ads.core.data.model.ShowConfigurationInternal;

public class UnityAdsShowOptions extends UnityAdsBaseOptions {
	public UnityAdsShowOptions() {
		super();
	}

	@RestrictTo(RestrictTo.Scope.LIBRARY)
	public ShowConfigurationInternal showConfiguration = null;
}
