package com.unity3d.ads.core.data.model

import com.google.protobuf.ByteString

internal sealed class SessionChange {
    data class UserConsentChange(val value: ByteString) : SessionChange()
    data class PrivacyFsmChange(val value: ByteString) : SessionChange()
}
