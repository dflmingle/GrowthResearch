package com.unity3d.ads.core.domain

import com.unity3d.ads.adplayer.model.WebViewClientError
import com.unity3d.ads.core.data.model.AdObject

interface SendWebViewClientErrorDiagnostics {
    operator fun invoke(errors: List<WebViewClientError>, adObject: AdObject)
}