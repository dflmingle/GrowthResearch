package com.unity3d.ads.core.domain

interface GetFileExtensionFromUrl {
    operator fun invoke(url: String): String?
}