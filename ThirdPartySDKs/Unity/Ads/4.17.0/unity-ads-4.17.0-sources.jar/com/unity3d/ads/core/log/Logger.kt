package com.unity3d.ads.core.log

internal interface Logger {

    var logLevel: LogLevelInternal

    fun info(message: String)

    fun debug(message: String)

    fun debug(fb: () -> String)

    fun error(message: String, e: Throwable? = null)

    fun trace(message: String, e: Throwable? = null)
}
