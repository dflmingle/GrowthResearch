package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest.Payload
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest
import gatewayprotocol.v1.universalRequest



class AndroidGetUniversalRequestForPayLoad(
    private val getUniversalRequestSharedData: GetUniversalRequestSharedData,
) : GetUniversalRequestForPayLoad {
    override suspend fun invoke(payload: Payload): UniversalRequest {
        return universalRequest {
            this.sharedData = getUniversalRequestSharedData()
            this.payload = payload
        }
    }
}