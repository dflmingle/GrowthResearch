package com.unity3d.ads.core.domain

import java.io.File

class CommonGetCacheDirectory : GetCacheDirectory {
    override fun invoke(cacheDirectoryBase: File, cacheDirectoryPath: String): File {
        return File(cacheDirectoryBase, cacheDirectoryPath)
    }
}