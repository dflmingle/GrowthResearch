package com.unity3d.ads.core.domain.scar

import com.unity3d.ads.core.domain.SendDiagnosticEvent
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.SCAR_VIDEO_LENGTH_IN_SEC

class ScarTimeHackFixer(
    val sendDiagnosticEvent: SendDiagnosticEvent
) {
    operator fun invoke(videoLengthMs: Int): Int
    {
        return if (videoLengthMs < 1000) {
            sendDiagnosticEvent(SCAR_VIDEO_LENGTH_IN_SEC)
            videoLengthMs * 1000
        } else videoLengthMs
    }

}