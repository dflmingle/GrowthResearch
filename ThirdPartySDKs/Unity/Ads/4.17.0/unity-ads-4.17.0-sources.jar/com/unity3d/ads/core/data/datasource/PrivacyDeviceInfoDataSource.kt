package com.unity3d.ads.core.data.datasource

import gatewayprotocol.v1.AllowedPiiOuterClass.AllowedPii
import gatewayprotocol.v1.PiiOuterClass

interface PrivacyDeviceInfoDataSource {
    fun fetch(allowed: AllowedPii = AllowedPii.getDefaultInstance()): PiiOuterClass.Pii
}