package com.unity3d.ads.adplayer

interface EmbeddableAdPlayer : AdPlayer