package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalRequestOuterClass.LimitedSessionToken

fun interface GetLimitedSessionToken {
    suspend operator fun invoke(): LimitedSessionToken
}