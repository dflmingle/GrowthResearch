package com.unity3d.ads.core.data.repository

import gatewayprotocol.v1.ClientInfoOuterClass.MediationProvider

interface MediationRepository {
    val name: String?
    val version: String?
    val mediationProvider: () -> MediationProvider
}