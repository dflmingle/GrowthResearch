package com.unity3d.ads.core.data.datasource

import com.google.protobuf.ByteString

interface GetByteStringData {
    operator fun invoke(data: String): ByteString
}