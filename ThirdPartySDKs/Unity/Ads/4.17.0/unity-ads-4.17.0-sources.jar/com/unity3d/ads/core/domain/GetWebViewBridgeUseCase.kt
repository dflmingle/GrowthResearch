package com.unity3d.ads.core.domain

import com.unity3d.ads.adplayer.AndroidWebViewContainer
import com.unity3d.ads.adplayer.WebViewBridge
import kotlinx.coroutines.CoroutineScope

internal interface GetWebViewBridgeUseCase {
    operator fun invoke(webViewContainer: AndroidWebViewContainer, adPlayerScope: CoroutineScope): WebViewBridge
}