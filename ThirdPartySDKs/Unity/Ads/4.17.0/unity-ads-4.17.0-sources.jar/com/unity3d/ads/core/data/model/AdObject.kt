package com.unity3d.ads.core.data.model

import android.app.Activity
import com.google.protobuf.ByteString
import com.unity3d.ads.LoadConfiguration
import com.unity3d.ads.ShowConfiguration
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.UnityAdsLoadOptions
import com.unity3d.ads.adplayer.AdPlayer
import gatewayprotocol.v1.DiagnosticEventRequestOuterClass.DiagnosticAdType
import kotlinx.coroutines.flow.MutableStateFlow
import java.lang.ref.WeakReference
import kotlin.time.Duration

enum class AdObjectState {
    INIT,
    LOADED,
    SHOWING,
    EXPIRED,
    COMPLETED,
}

@OptIn(UnityAdsExperimental::class)
data class AdObject(
    val opportunityId: ByteString,
    val placementId: String,
    var trackingToken: ByteString,
    var isScarAd: Boolean = false,
    var scarQueryId: String? = null,
    var scarAdUnitId: String? = null,
    var scarAdString: String? = null,
    var isOfferwallAd: Boolean = false,
    var offerwallPlacementName: String? = null,
    val adPlayer: AdPlayer? = null,
    var playerServerId: String? = null,
    val loadOptions: UnityAdsLoadOptions,
    val isHeaderBidding: Boolean,
    val adType: DiagnosticAdType,
    var ttl: MutableStateFlow<Duration?> = MutableStateFlow(null),
    var state: MutableStateFlow<AdObjectState> = MutableStateFlow(AdObjectState.INIT),
    var loadConfiguration: LoadConfiguration? = null,
    var showConfiguration: ShowConfiguration? = null,
    var activity: WeakReference<Activity>? = null,
)