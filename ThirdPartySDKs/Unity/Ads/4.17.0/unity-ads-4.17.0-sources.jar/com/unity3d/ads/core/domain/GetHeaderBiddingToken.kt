package com.unity3d.ads.core.domain

import com.unity3d.ads.TokenConfiguration

interface GetHeaderBiddingToken {
    suspend operator fun invoke(tokenNumber: Int, tokenConfiguration: TokenConfiguration? = null): String
}