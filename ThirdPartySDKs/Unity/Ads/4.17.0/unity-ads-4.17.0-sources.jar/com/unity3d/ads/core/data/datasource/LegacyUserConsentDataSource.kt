package com.unity3d.ads.core.data.datasource

interface LegacyUserConsentDataSource {
    val privacyData: String?
}