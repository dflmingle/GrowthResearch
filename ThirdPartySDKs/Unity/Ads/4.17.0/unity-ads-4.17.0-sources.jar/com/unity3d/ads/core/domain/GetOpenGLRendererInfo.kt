package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString

interface GetOpenGLRendererInfo {
    operator fun invoke(): ByteString
}