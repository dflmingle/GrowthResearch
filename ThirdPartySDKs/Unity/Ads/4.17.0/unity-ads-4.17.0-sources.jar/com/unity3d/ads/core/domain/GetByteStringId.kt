package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString

interface GetByteStringId {
    operator fun invoke(): ByteString
}