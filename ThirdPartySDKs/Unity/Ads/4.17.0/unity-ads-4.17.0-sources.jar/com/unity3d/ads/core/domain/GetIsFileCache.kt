package com.unity3d.ads.core.domain

interface GetIsFileCache {
    suspend operator fun invoke(url: String): Boolean
}