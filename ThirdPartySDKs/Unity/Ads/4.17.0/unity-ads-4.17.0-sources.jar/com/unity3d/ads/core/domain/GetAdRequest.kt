package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import com.unity3d.ads.core.data.model.LoadConfigurationInternal
import gatewayprotocol.v1.AdRequestOuterClass.BannerSize
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

internal interface GetAdRequest {
    suspend operator fun invoke(
        placement: String,
        impressionOpportunity: ByteString,
        size: BannerSize? = null,
        loadConfiguration: LoadConfigurationInternal? = null,
    ): UniversalRequest
}