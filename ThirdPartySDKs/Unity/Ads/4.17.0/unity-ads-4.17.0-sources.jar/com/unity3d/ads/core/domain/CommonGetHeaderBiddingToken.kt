package com.unity3d.ads.core.domain

import com.unity3d.ads.TokenConfiguration
import com.unity3d.ads.core.domain.scar.FetchSignalsAndSendUseCase
import com.unity3d.ads.core.domain.scar.ScarEligibleEffectiveUseCase
import com.unity3d.ads.core.extensions.toBase64

internal class CommonGetHeaderBiddingToken(
    private val buildHeaderBiddingToken: BuildHeaderBiddingToken,
    private val fetchSignalsAndSendUseCase: FetchSignalsAndSendUseCase,
    private val scarEligibleEffectiveUseCase: ScarEligibleEffectiveUseCase
) : GetHeaderBiddingToken {
    override suspend fun invoke(tokenNumber: Int, tokenConfiguration: TokenConfiguration?): String {
        val scarEligibleEffectiveList = scarEligibleEffectiveUseCase(tokenConfiguration)
        val rawToken = buildHeaderBiddingToken(tokenNumber, tokenConfiguration, scarEligibleEffectiveList.isNotEmpty())
        // collect and send scar signals
        if (scarEligibleEffectiveList.isNotEmpty()) {
            fetchSignalsAndSendUseCase(tokenNumber, rawToken.tokenId, tokenConfiguration)
        }
        // mediation receives a base64 encoded string
        val token = rawToken.toByteString().toBase64()
        // append version
        return "$HB_TOKEN_VERSION:$token"
    }

    companion object {
        const val HB_TOKEN_VERSION = "2"
    }
}