package com.unity3d.ads.core.domain.billing

/**
 * Interface for fetching product details with different strategies.
 * This allows for flexible fallback mechanisms and easy testing.
 */
interface ProductDetailsFetcher {
    suspend fun fetchProductDetails(
        productId: String
    ): ProductDetailsResult
}


