package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.model.CacheResult
import org.json.JSONArray

interface CacheFile {
    suspend operator fun invoke(url: String, adObject: AdObject, headers: JSONArray?, priority: Int): CacheResult
}