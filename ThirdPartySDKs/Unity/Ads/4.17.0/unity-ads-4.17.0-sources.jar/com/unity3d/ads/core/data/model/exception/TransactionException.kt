package com.unity3d.ads.core.data.model.exception

class TransactionException (message: String) : Exception(message)