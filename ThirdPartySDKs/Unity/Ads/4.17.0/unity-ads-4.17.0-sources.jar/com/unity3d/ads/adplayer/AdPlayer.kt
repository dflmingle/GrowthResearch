package com.unity3d.ads.adplayer

import androidx.annotation.CallSuper
import com.unity3d.ads.adplayer.model.LoadEvent
import com.unity3d.ads.core.data.model.OfferwallShowEvent
import com.unity3d.services.ads.offerwall.OfferwallEvent
import com.unity3d.ads.core.data.model.ScarEvent
import com.unity3d.ads.core.data.model.ShowEvent
import com.unity3d.scar.adapter.common.GMAEvent
import com.unity3d.services.banners.bridge.BannerBridge.BannerEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow

/**
 * This interface represents an ad player that can be used to play advertisements.
 * It provides methods to control the player's behavior and events for tracking ad playback.
 **/
interface AdPlayer {
    /**
     * Represents a CoroutineScope object associated to the lifetime of the AdPlayer. It can be used to launch Flows
     * that will be cancelled when the AdPlayer is destroyed.
     **/
    val scope: CoroutineScope

    val webViewContainer: WebViewContainer

    /**
     * Represents a Flow of ScarEvent objects that can be used to track SCAR ad playback.
     **/
    val onScarEvent: Flow<ScarEvent>

    /**
     * Represents a Flow of ShowEvent objects that can be used to track ad playback.
     **/
    val onShowEvent: Flow<ShowEvent>

    /**
     * Represents a Flow of OfferwallEvent objects that can be used to track Offerwall ad playback.
     **/
    val onOfferwallEvent: Flow<OfferwallShowEvent>

    /**
     * Represents the event that is triggered when the AdViewer html has finished loading.
     *
     * Only triggered once per ad view.
     *
     * If an error occurs, it will throw an exception.
     **/
    val onLoadEvent: Flow<LoadEvent>

    // region AdViewer API

    /**
     * Sends a request to the AdViewer to start playing the ad.
     **/
    suspend fun requestShow(unityAdsShowOptions: Map<String, Any?>?)

    /**
     * Used to dispatch the show completed event from native. Banner is using this to dispatch the event when the container is detached.
     */
    fun dispatchShowCompleted()

    fun show(showOptions: ShowOptions) {
        throw NotImplementedError()
    }

    @CallSuper
    suspend fun destroy() {
        // Cancel the scope. Any coroutines launched in the scope will be cancelled (such as flow listeners).
        // When the AdPlayer is destroyed, we stop receiving DisplayMessages...
        scope.cancel()
    }

    // endregion AdViewer API

    // region Events

    suspend fun sendMuteChange(isMuted: Boolean)
    suspend fun sendVisibilityChange(isVisible: Boolean)
    suspend fun sendFocusChange(isFocused: Boolean)
    suspend fun sendActivityDestroyed()
    suspend fun sendVolumeChange(volume: Double)
    suspend fun sendUserConsentChange(value: ByteArray)
    suspend fun sendPrivacyFsmChange(value: ByteArray)
    suspend fun onAllowedPiiChange(value: ByteArray)
    suspend fun onBroadcastEvent(event: String)
    suspend fun sendGmaEvent(event: GMAEvent)
    suspend fun sendOfferwallEvent(event: OfferwallEvent)
    suspend fun sendScarBannerEvent(event: BannerEvent)

    companion object {
        val broadcastEventChannel = MutableSharedFlow<String>()
        const val SCAR_EVENT_QUEUE_SIZE = 10
        const val OFFERWALL_EVENT_QUEUE_SIZE = 5
    }

    // endregion Events
}
