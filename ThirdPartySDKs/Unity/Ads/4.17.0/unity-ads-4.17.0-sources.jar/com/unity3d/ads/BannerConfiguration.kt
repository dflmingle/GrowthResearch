package com.unity3d.ads

@UnityAdsExperimental
class BannerConfiguration private constructor(
    val placementId: String,
    val bannerSize: BannerSize,
    val listener: BannerShowListener,
    val extras: Map<String, String> = emptyMap(),
    val adMarkup: String? = null,
    val mediationInfo: MediationInfo? = null,
    val mediationAdUnitId: String? = null,
) {
    class Builder(private val placementId: String, private val bannerSize: BannerSize, private val listener: BannerShowListener) {
        private var adMarkup: String? = null
        private var extras: Map<String, String> = emptyMap()
        private var mediationInfo: MediationInfo? = null
        private var mediationAdUnitId: String? = null

        fun withAdMarkup(adMarkup: String): Builder {
            this.adMarkup = adMarkup
            return this
        }

        fun withExtras(extras: Map<String, String>): Builder {
            this.extras = extras
            return this
        }

        fun withMediationInfo(mediationInfo: MediationInfo): Builder {
            this.mediationInfo = mediationInfo
            return this
        }

        fun withMediationAdUnitId(mediationAdUnitId: String): Builder {
            this.mediationAdUnitId = mediationAdUnitId
            return this
        }

        fun build(): BannerConfiguration {
            return BannerConfiguration(
                placementId = placementId,
                bannerSize = bannerSize,
                listener = listener,
                extras = extras,
                adMarkup = adMarkup,
                mediationInfo = mediationInfo,
                mediationAdUnitId = mediationAdUnitId
            )
        }
    }
}