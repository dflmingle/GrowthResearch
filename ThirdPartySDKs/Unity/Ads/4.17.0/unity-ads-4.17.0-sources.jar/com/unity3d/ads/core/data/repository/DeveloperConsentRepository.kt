package com.unity3d.ads.core.data.repository

import gatewayprotocol.v1.DeveloperConsentOuterClass

interface DeveloperConsentRepository {
    val developerConsent: DeveloperConsentOuterClass.DeveloperConsent
}