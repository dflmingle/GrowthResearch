package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

interface GetInitializationRequest {
    suspend operator fun invoke(): UniversalRequest
}
