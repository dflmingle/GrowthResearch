package com.unity3d.ads.core.domain

import java.io.File

interface CreateFile {
    operator fun invoke(parent: File, child: String): File
    operator fun invoke(pathname: String): File
}