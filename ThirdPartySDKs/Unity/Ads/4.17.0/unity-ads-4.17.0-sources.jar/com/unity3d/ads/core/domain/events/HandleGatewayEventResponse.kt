package com.unity3d.ads.core.domain.events

import gatewayprotocol.v1.UniversalResponseOuterClass.UniversalResponse

interface HandleGatewayEventResponse {
    suspend operator fun invoke(response: UniversalResponse)

}