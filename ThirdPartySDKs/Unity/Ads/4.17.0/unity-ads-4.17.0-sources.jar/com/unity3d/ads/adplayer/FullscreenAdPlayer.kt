package com.unity3d.ads.adplayer

interface FullscreenAdPlayer : AdPlayer