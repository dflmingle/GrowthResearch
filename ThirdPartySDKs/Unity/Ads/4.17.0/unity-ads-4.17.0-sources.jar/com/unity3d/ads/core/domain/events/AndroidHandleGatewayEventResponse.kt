package com.unity3d.ads.core.domain.events

import gatewayprotocol.v1.UniversalResponseOuterClass



class AndroidHandleGatewayEventResponse : HandleGatewayEventResponse {
    override suspend fun invoke(response: UniversalResponseOuterClass.UniversalResponse) {
        // For now, we don't do anything with the response.
        // We might want to check for errors and send metrics in these cases.
    }
}