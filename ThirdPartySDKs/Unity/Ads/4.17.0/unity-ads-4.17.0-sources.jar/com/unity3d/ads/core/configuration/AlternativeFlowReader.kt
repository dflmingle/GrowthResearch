package com.unity3d.ads.core.configuration

fun interface AlternativeFlowReader {
    operator fun invoke(): Boolean
}

