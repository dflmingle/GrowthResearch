package com.unity3d.ads.core.data.model.exception

import com.unity3d.ads.core.data.model.OperationType

class NetworkTimeoutException(
    message: String,
    type: OperationType = OperationType.UNKNOWN,
    code: Int? = null,
    url: String? = null,
    protocol: String? = null,
    cronetCode: Int? = null,
    client: String? = null
) : UnityAdsNetworkException(
    message,
    type,
    code,
    url,
    protocol,
    cronetCode,
    client
)