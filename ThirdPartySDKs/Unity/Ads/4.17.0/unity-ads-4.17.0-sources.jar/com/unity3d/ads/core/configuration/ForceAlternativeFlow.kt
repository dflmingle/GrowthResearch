package com.unity3d.ads.core.configuration

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

class ForceAlternativeFlow {

    private val _forceAlternativeFlow = MutableStateFlow(false)
    val forceAlternativeFlow
        get() = _forceAlternativeFlow.value

    operator fun invoke(force: Boolean) {
        _forceAlternativeFlow.update { force }
    }
}