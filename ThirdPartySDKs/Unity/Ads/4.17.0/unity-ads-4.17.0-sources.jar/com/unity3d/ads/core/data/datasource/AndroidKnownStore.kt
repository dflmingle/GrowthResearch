package com.unity3d.ads.core.data.datasource

enum class AndroidKnownStore(
    val packageName: String,
) {
    GOOGLE("com.android.vending"),
    GOOGLE_MARKET("com.google.market"), // Old name for Google Play Store (pre-2012) when it was the Android Market
    AMAZON("com.amazon.venezia"),
    SAMSUNG("com.sec.android.app.samsungapps"),
    XIAOMI("com.xiaomi.market"),
    HUAWEI("com.huawei.appmarket"),
    OPPO("com.oppo.market"),
    VIVO("com.bbk.appstore"),
    UNKNOWN("unknown");
}