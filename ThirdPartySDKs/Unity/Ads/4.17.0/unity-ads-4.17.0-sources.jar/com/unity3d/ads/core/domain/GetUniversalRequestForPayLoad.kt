package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

interface GetUniversalRequestForPayLoad {
    suspend operator fun invoke(payload: UniversalRequest.Payload): UniversalRequest
}