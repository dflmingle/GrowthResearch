package com.unity3d.ads.core.data.datasource

interface UnityBootConfigDataSource {
    fun getValue(key: String): String?
    
    companion object {
        const val BUILD_GUID = "build-guid"
    }
}
