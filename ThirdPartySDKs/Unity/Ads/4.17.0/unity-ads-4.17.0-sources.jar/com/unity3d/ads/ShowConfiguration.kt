package com.unity3d.ads

@UnityAdsExperimental
class ShowConfiguration private constructor(
    val customRewardString: String? = null,
    val extras: Map<String, String> = emptyMap()
) {
    class Builder {
        private var customRewardString: String? = null
        private var extras: Map<String, String> = emptyMap()

        fun withCustomRewardString(customRewardString: String): Builder {
            this.customRewardString = customRewardString
            return this
        }

        fun withExtras(extras: Map<String, String>): Builder {
            this.extras = extras
            return this
        }

        fun build(): ShowConfiguration {
            return ShowConfiguration(customRewardString, extras)
        }
    }
}