package com.unity3d.ads.core.domain

interface CheckForGameIdAndTestModeChanges {
    operator fun invoke(legacy: Boolean)
}