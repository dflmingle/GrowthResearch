package com.unity3d.ads.core.data.repository

import com.google.protobuf.ByteString
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.core.data.datasource.AndroidUnityInfoDataSource
import com.unity3d.ads.core.data.model.InitializationConfigurationInternal
import com.unity3d.ads.core.data.datasource.ByteStringDataSource
import com.unity3d.ads.core.data.model.InitializationState
import com.unity3d.ads.core.data.model.SessionChange
import com.unity3d.ads.core.data.model.TokenCounters
import com.unity3d.ads.core.data.model.exception.InitializationException
import com.unity3d.ads.core.domain.SendDiagnosticEvent
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.INIT_MISSED_NATIVE_PARSING
import com.unity3d.ads.core.extensions.toByteString
import com.unity3d.services.UnityAdsConstants
import com.unity3d.services.core.properties.ClientProperties
import com.unity3d.services.core.properties.SdkProperties
import com.unity3d.services.core.properties.SessionIdReader
import gatewayprotocol.v1.AdFormatOuterClass.AdFormat
import gatewayprotocol.v1.InitializationResponseOuterClass.RequestUrlOverride
import gatewayprotocol.v1.NativeConfigurationOuterClass.NativeConfiguration
import gatewayprotocol.v1.NativeConfigurationOuterClass.FeatureFlags
import gatewayprotocol.v1.SessionCountersOuterClass.SessionCounters
import gatewayprotocol.v1.copy
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

import java.util.UUID

internal class AndroidSessionRepository(
    private val gatewayCacheDataSource: ByteStringDataSource,
    private val privacyDataSource: ByteStringDataSource,
    private val fsmDataSource: ByteStringDataSource,
    private val nativeConfigDataSource: ByteStringDataSource,
    private val unityInfoDataSource: AndroidUnityInfoDataSource,
    defaultNativeConfiguration: NativeConfiguration,
    dispatcher: CoroutineDispatcher,
    sendDiagnosticEvent: SendDiagnosticEvent
) : SessionRepository {
    private val _sdkConfiguration = MutableStateFlow(value = defaultNativeConfiguration)
    private val isInit = MutableStateFlow(false)

    init {
        CoroutineScope(dispatcher).launch {
            try {
                val data = nativeConfigDataSource.get().data
                if (!data.isEmpty) {
                    _sdkConfiguration.value = NativeConfiguration.parseFrom(data)
                }
            } catch (e: Exception) {
                sendDiagnosticEvent(INIT_MISSED_NATIVE_PARSING, tags = mapOf("debugReason" to (e.message?: "unknown")))
            }
            isInit.value = true
        }
    }

    private val persistedNativeConfiguration = _sdkConfiguration.combine(isInit) { sdkConfig, isInit ->
        sdkConfig to isInit
    }.filter { it.second }.map { it.first }

    override val scarEligibleFormats = mutableListOf<AdFormat>()

    private var _onChange = MutableSharedFlow<SessionChange>()
    override val onChange = _onChange.asSharedFlow()

    private var _gameId = MutableStateFlow(value = ClientProperties.getGameId() ?: null)
    override var gameId
        get() = _gameId.updateAndGet { ClientProperties.getGameId() ?: null }
        set(value) = _gameId.update {
            ClientProperties.setGameId(value)
            value
        }

    private val _sessionId = MutableStateFlow(value = UUID.fromString(SessionIdReader.sessionId).toByteString())
    override val sessionId: ByteString
        get() = _sessionId.value

    private val _isTestModeEnabled = MutableStateFlow(value = SdkProperties.isTestMode())
    override val isTestModeEnabled: Boolean
        get() = _isTestModeEnabled.updateAndGet { SdkProperties.isTestMode() }

    private val _sessionCounters = MutableStateFlow<SessionCounters>(value = SessionCounters.newBuilder().build())
    override var sessionCounters: SessionCounters
        get() = _sessionCounters.value
        set(value) = _sessionCounters.update { value }

    private val _tokenCounters = MutableStateFlow(value = TokenCounters(0, 0, 0))
    override var tokenCounters: TokenCounters
        get() = _tokenCounters.value
        set(value) = _tokenCounters.update { value }

    private val _initializationError: MutableStateFlow<InitializationException?> = MutableStateFlow(null)
    override var initializationError: InitializationException?
        get() = _initializationError.value
        set(value) = _initializationError.update { value }

    override fun incrementLoadRequestCount() {
        _sessionCounters.update {
            it.copy { loadRequests += 1 }
        }
    }

    override fun incrementLoadRequestAdmCount() {
        _sessionCounters.update {
            it.copy { loadRequestsAdm += 1 }
        }
    }

    override fun incrementBannerLoadRequestCount() {
        _sessionCounters.update {
            it.copy { bannerLoadRequests += 1 }
        }
    }

    override fun incrementBannerLoadRequestAdmCount() {
        _sessionCounters.update {
            it.copy { bannerRequestsAdm += 1 }
        }
    }

    override fun incrementBannerImpressionCount() {
        _sessionCounters.update {
            it.copy { bannerImpressions += 1 }
        }
    }

    override fun incrementGlobalAdsFocusChangeCount() {
        _sessionCounters.update {
            it.copy { globalAdsFocusChangeCount += 1 }
        }
    }

    override fun addTimeToGlobalAdsFocusTime(timeMs: Int) {
        _sessionCounters.update {
            it.copy { globalAdsFocusTime += timeMs }
        }
    }

    override fun incrementFocusChangeCount() {
        _sessionCounters.update {
            it.copy { focusChangeCount += 1 }
        }
    }

    override fun incrementTokenSequenceNumber() {
        _tokenCounters.update {
            it.copy(seq = it.seq + 1)
        }
    }

    override fun incrementTokenWinsCount() {
        _tokenCounters.update {
            it.copy(wins =  it.wins + 1)
        }
    }

    override fun incrementTokenStartsCount() {
        _tokenCounters.update {
            it.copy(starts = it.starts + 1)
        }
    }

    override fun resetTokenCounters() {
        _tokenCounters.update {
            TokenCounters(0, 0, 0)
        }
    }

    private val _sessionToken = MutableStateFlow<ByteString>(value = ByteString.EMPTY)
    override var sessionToken: ByteString
        get() = _sessionToken.value
        set(value) = _sessionToken.update { value }

    private val _currentState = MutableStateFlow<ByteString>(value = ByteString.EMPTY)
    override var gatewayState: ByteString
        get() = _currentState.value
        set(value) = _currentState.update { value }

    override var nativeConfiguration: NativeConfiguration
        get() =
            if (!isInit.value) {
                // In case we are not initialized yet, we need to wait for the native configuration to be loaded
                runBlocking {
                    persistedNativeConfiguration.first()
                }
            } else {
                _sdkConfiguration.value
            }

        set(value) = _sdkConfiguration.update { value }

    private val _gatewayUrl = MutableStateFlow(value = UnityAdsConstants.DefaultUrls.GATEWAY_URL)
    override var gatewayUrl: String
        get() = _gatewayUrl.value
        set(value) = _gatewayUrl.update { value }

    private val _initializationState = MutableStateFlow(value = InitializationState.NOT_INITIALIZED)
    override var initializationState: InitializationState
        get() = _initializationState.value
        set(value) = _initializationState.update { value }

    private val _requestUrlOverride: MutableStateFlow<List<RequestUrlOverride>> = MutableStateFlow(emptyList())
    override var requestUrlOverrides: List<RequestUrlOverride>
        get() = _requestUrlOverride.value
        set(value) = _requestUrlOverride.update { value }

    override val observeInitializationState: Flow<InitializationState>
        get() = _initializationState

    override val isSdkInitialized: Boolean
        get() = initializationState == InitializationState.INITIALIZED

    override val isDiagnosticsEnabled: Boolean
        get() = nativeConfiguration.diagnosticEvents.enabled

    override val featureFlags: FeatureFlags
        get() = nativeConfiguration.featureFlags

    private val _headerBiddingTokenCounter = MutableStateFlow(value = 0)
    override val headerBiddingTokenCounter: Int
        get() = _headerBiddingTokenCounter.getAndUpdate { it + 1 }

    override suspend fun getGatewayCache(): ByteString = gatewayCacheDataSource.get().data
    override suspend fun setGatewayCache(value: ByteString) = gatewayCacheDataSource.set(value)

    override suspend fun getPrivacy(): ByteString = privacyDataSource.get().data
    override suspend fun setPrivacy(value: ByteString) {
        privacyDataSource.set(value)
        _onChange.emit(SessionChange.UserConsentChange(value))
    }

    override suspend fun getPrivacyFsm(): ByteString = fsmDataSource.get().data
    override suspend fun setPrivacyFsm(value: ByteString) {
        fsmDataSource.set(value)
        _onChange.emit(SessionChange.PrivacyFsmChange(value))
    }

    private val _shouldInitialize = MutableStateFlow(value = true)
    override var shouldInitialize: Boolean
        get() = _shouldInitialize.value
        set(value) = _shouldInitialize.update { value }

    override val isOmEnabled: Boolean
        get() = nativeConfiguration.enableOm

    override suspend fun persistNativeConfiguration() {
        nativeConfigDataSource.set(nativeConfiguration.toByteString())
    }

    private val _isFirstInitAttempt = MutableStateFlow(value = true)
    override val isFirstInitAttempt: Boolean
        get() = _isFirstInitAttempt.getAndUpdate { false }

    override val unityInstallationId: String?
        get() = unityInfoDataSource.getUnityInstallationId()
    override val unityMegaSessionId: String?
        get() = unityInfoDataSource.getUnityMegaSessionId()

    @OptIn(UnityAdsExperimental::class)
    override var initializationConfiguration: InitializationConfigurationInternal? = null
}