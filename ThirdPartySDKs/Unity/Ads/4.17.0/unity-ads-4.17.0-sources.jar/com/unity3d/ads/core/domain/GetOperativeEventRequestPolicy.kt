package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.gatewayclient.RequestPolicy

internal class GetOperativeEventRequestPolicy(private val sessionRepository: SessionRepository): GetRequestPolicy {
    override fun invoke(): RequestPolicy {
        return RequestPolicy(
            maxDuration = sessionRepository.nativeConfiguration.operativeEventPolicy.retryPolicy.maxDuration,
            retryMaxInterval = sessionRepository.nativeConfiguration.operativeEventPolicy.retryPolicy.retryMaxInterval,
            retryWaitBase = sessionRepository.nativeConfiguration.operativeEventPolicy.retryPolicy.retryWaitBase,
            retryJitterPct = sessionRepository.nativeConfiguration.operativeEventPolicy.retryPolicy.retryJitterPct,
            retryScalingFactor = sessionRepository.nativeConfiguration.operativeEventPolicy.retryPolicy.retryScalingFactor,
            connectTimeout = sessionRepository.nativeConfiguration.operativeEventPolicy.timeoutPolicy.connectTimeoutMs,
            readTimeout = sessionRepository.nativeConfiguration.operativeEventPolicy.timeoutPolicy.readTimeoutMs,
            writeTimeout = sessionRepository.nativeConfiguration.operativeEventPolicy.timeoutPolicy.writeTimeoutMs,
            overallTimeout = sessionRepository.nativeConfiguration.operativeEventPolicy.timeoutPolicy.overallTimeoutMs,
            shouldStoreLocally = sessionRepository.nativeConfiguration.operativeEventPolicy.retryPolicy.shouldStoreLocally
        )
    }
}