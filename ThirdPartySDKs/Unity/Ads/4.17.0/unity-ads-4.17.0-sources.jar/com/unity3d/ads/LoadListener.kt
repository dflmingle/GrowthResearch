package com.unity3d.ads

@UnityAdsExperimental
fun interface LoadListener<UnityAd> {
    fun onAdLoaded(unityAd: UnityAd?, error: UnityAdsError?)
}