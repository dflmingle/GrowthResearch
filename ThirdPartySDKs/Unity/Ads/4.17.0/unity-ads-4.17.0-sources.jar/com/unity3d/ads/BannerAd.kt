package com.unity3d.ads

import android.view.View
import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.model.AdObjectState
import com.unity3d.ads.core.data.model.LoadConfigurationInternal
import com.unity3d.ads.core.data.repository.AdRepository
import com.unity3d.ads.core.domain.SafeCallbackInvoke
import com.unity3d.ads.core.extensions.toByteString
import com.unity3d.ads.metadata.MetaData
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import com.unity3d.services.core.di.ServiceKey
import com.unity3d.services.core.di.ServiceProvider
import com.unity3d.services.core.di.ServiceProvider.NAMED_LOAD_SCOPE
import com.unity3d.services.core.properties.ClientProperties
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference

internal interface BannerShowListenerWithOnFailedToShow {
    fun onBannerFailedToShow(bannerAdView: BannerView, errorInfo: BannerErrorInfo)
}

@UnityAdsExperimental
class BannerAd internal constructor(
    private val adObject: AdObject,
    val view: View,
    private val safeCallbackInvoke: SafeCallbackInvoke
) {
    var onAdExpired: AdExpiredListener<BannerAd>? = null

    init {
        adObject.adPlayer?.scope?.let { scope ->
            scope.launch {
                adObject.state
                    .filter(AdObjectState.EXPIRED::equals)
                    .take(1)
                    .collect {
                        safeCallbackInvoke {
                            onAdExpired?.onAdExpired(this@BannerAd)
                        }
                    }
            }
        }
    }

    companion object {
        @JvmStatic
        fun load(configuration: BannerConfiguration, listener: LoadListener<BannerAd>) {
            val loadScope = ServiceProvider.getRegistry().resolveService<CoroutineScope>(
                ServiceKey(
                    named = NAMED_LOAD_SCOPE,
                    instanceClass = CoroutineScope::class
                )
            )
            loadScope.launch {
                val context = ClientProperties.getApplicationContext()
                if (context == null) {
                    listener.onAdLoaded(
                        null,
                        UnityAdsError(
                            code = 0,
                            message = "Failed to load banner ad for placement: ${configuration.placementId}. Verify that Unity Ads has been initialized."
                        )
                    )
                    return@launch
                }
                val opportunityId = UUID.randomUUID()
                val unityAdsLoadOptions = UnityAdsLoadOptions().also {
                    it.objectId = opportunityId.toString()
                    it.setAdMarkup(configuration.adMarkup)
                    it.loadConfiguration = LoadConfigurationInternal(
                        placementId = configuration.placementId,
                        adMarkup = configuration.adMarkup,
                        mediationAdUnitId = configuration.mediationAdUnitId,
                        mediationInfo = configuration.mediationInfo,
                        extras = configuration.extras
                    )
                }

                if (configuration.extras.isNotEmpty()) {
                    MetaData(context).run {
                        configuration.extras.forEach { entry ->
                            set(entry.key, entry.value)
                        }

                        commit()
                    }
                }

                val bannerAdRef = AtomicReference<BannerAd?>(null)
                val bannerSize = UnityBannerSize(
                    configuration.bannerSize.width,
                    configuration.bannerSize.height,
                )

                val bannerView =
                    BannerView(context, configuration.placementId, bannerSize)
                bannerView.listener =
                    object : BannerView.IListener, BannerShowListenerWithOnFailedToShow {
                        override fun onBannerLoaded(bannerAdView: BannerView) {
                            val adRepository = ServiceProvider.getRegistry()
                                .resolveService<AdRepository>(ServiceKey(instanceClass = AdRepository::class))
                            val safeCallbackInvoke = ServiceProvider.getRegistry()
                                .resolveService<SafeCallbackInvoke>(ServiceKey(instanceClass = SafeCallbackInvoke::class))
                            val adObject = adRepository.getAd(opportunityId.toByteString())

                            if (adObject == null) {
                                listener.onAdLoaded(
                                    null,
                                    UnityAdsError(
                                        code = 0,
                                        message = "Failed to load banner ad for placement: ${configuration.placementId}"
                                    )
                                )
                                return
                            }

                            val bannerAd = BannerAd(adObject, bannerView, safeCallbackInvoke)
                            bannerAdRef.set(bannerAd)
                            listener.onAdLoaded(bannerAd, null)
                        }

                        override fun onBannerFailedToLoad(
                            bannerAdView: BannerView,
                            errorInfo: BannerErrorInfo
                        ) {
                            listener.onAdLoaded(
                                null,
                                UnityAdsError(
                                    code = errorInfo.publicErrorCode,
                                    message = errorInfo.errorMessage
                                        ?: "Failed to load banner ad for placement: ${bannerAdView.placementId}."
                                )
                            )
                        }

                        override fun onBannerClick(bannerAdView: BannerView) {
                            bannerAdRef.get()?.let { bannerAd ->
                                configuration.listener.onClicked(bannerAd)
                            }
                        }

                        override fun onBannerLeftApplication(bannerAdView: BannerView) {
                            // no-op
                        }

                        override fun onBannerFailedToShow(
                            bannerAdView: BannerView,
                            errorInfo: BannerErrorInfo
                        ) {
                            bannerAdRef.get()?.let { bannerAd ->
                                configuration.listener.onFailedToShow(
                                    bannerAd,
                                    UnityAdsError(
                                        code = errorInfo.publicErrorCode,
                                        message = errorInfo.errorMessage
                                    )
                                )
                            }
                        }

                        override fun onBannerShown(bannerAdView: BannerView) {
                            bannerAdRef.get()?.let { bannerAd ->
                                configuration.listener.onImpression(bannerAd)
                            }
                        }
                    }

                bannerView.load(unityAdsLoadOptions)
            }
        }
    }
}
