package com.unity3d.ads.core.domain

import com.unity3d.ads.gatewayclient.RequestPolicy

interface GetRequestPolicy {
    operator fun invoke(): RequestPolicy
}