package com.unity3d.ads.network.model

sealed interface HttpBody {
    class StringBody(val content: String) : HttpBody
    class ByteArrayBody(val content: ByteArray) : HttpBody
    object EmptyBody : HttpBody
}
