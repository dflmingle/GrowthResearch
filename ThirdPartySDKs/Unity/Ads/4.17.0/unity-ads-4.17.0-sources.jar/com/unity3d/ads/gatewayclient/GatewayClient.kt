package com.unity3d.ads.gatewayclient

import com.unity3d.ads.core.data.model.OperationType
import com.unity3d.services.UnityAdsConstants
import gatewayprotocol.v1.UniversalRequestOuterClass
import gatewayprotocol.v1.UniversalResponseOuterClass

interface GatewayClient {
    suspend fun request(url: String = UnityAdsConstants.DefaultUrls.GATEWAY_URL,
                        request: UniversalRequestOuterClass.UniversalRequest,
                        requestPolicy: RequestPolicy,
                        operationType: OperationType = OperationType.UNKNOWN
    ): UniversalResponseOuterClass.UniversalResponse
}