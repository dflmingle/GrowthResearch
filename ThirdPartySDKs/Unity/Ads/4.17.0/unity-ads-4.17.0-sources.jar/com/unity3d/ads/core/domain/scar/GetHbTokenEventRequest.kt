package com.unity3d.ads.core.domain.scar

import com.google.protobuf.ByteString
import com.unity3d.services.ads.gmascar.models.BiddingSignals
import gatewayprotocol.v1.GetTokenEventRequestOuterClass.GetTokenEventRequest

fun interface GetHbTokenEventRequest {
    suspend operator fun invoke(
        tokenId: ByteString,
        biddingSignals: BiddingSignals
    ): GetTokenEventRequest
}