package com.unity3d.ads.core.configuration

import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.services.core.configuration.ConfigurationReader
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

internal class CommonAlternativeFlowReader(
    private val configurationReader: ConfigurationReader,
    private val sessionRepository: SessionRepository,
    private val mediationMetadataReader: MediationTraitsMetadataReader,
    private val forceAlternativeFlow: ForceAlternativeFlow
) : AlternativeFlowReader {
    private val isAlternativeFlowRead = MutableStateFlow(false)
    private val isAlternativeFlowEnabled = MutableStateFlow(true)

    override operator fun invoke(): Boolean {
        // Early return if we already read the alternative flow value
        if (isAlternativeFlowRead.value) return isAlternativeFlowEnabled.value

        if (forceAlternativeFlow.forceAlternativeFlow) {
            isAlternativeFlowEnabled.value = true
            isAlternativeFlowRead.value = true
            return true
        }

        // Check in Mediation metadata if the alternative flow is enabled
        mediationMetadataReader.read<JSONObject?>()
            ?.takeIf {it.has(MediationTraitsMetadataReader.BOLD_SDK_ENABLED)}
            ?.let {
                isAlternativeFlowEnabled.value =
                    it.optBoolean(MediationTraitsMetadataReader.BOLD_SDK_ENABLED)
                isAlternativeFlowRead.value = true
            }

        // Check in the native configuration (for boldSdkNextSessionEnabled flag) unless its been read from elsewhere
        if (!isAlternativeFlowRead.value) {
            // Check if legacy config explicitly sets isBoldSdkNextSessionEnabled to false (default is true)
            if (!configurationReader.currentConfiguration.experiments.isBoldSdkNextSessionEnabled) {
                isAlternativeFlowEnabled.value = false
            } else {
                // If its default (or explicitly true), check the native configuration for the boldSdkNextSessionEnabled flag (which is also true by default)
                isAlternativeFlowEnabled.value =
                    sessionRepository.nativeConfiguration.featureFlags.boldSdkNextSessionEnabled
            }
            isAlternativeFlowRead.value = true
        }
        return isAlternativeFlowEnabled.value
    }
}