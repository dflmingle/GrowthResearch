package com.unity3d.ads.core.domain

interface GetGameId {
    operator fun invoke(): String?
}