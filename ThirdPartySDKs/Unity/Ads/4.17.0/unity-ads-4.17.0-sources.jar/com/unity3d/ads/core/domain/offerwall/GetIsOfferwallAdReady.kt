package com.unity3d.ads.core.domain.offerwall

import com.unity3d.ads.core.data.manager.OfferwallManager

class GetIsOfferwallAdReady(private val offerwallManager: OfferwallManager) {
    suspend operator fun invoke(
        placementName: String
    ): Boolean {
        return offerwallManager.isAdReady(
            placementName = placementName,
        )
    }
}