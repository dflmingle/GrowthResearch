package com.unity3d.ads.core.data.repository

import com.unity3d.ads.core.data.datasource.DeveloperConsentDataSource



class AndroidDeveloperConsentRepository(private val developerConsentDataSource: DeveloperConsentDataSource): DeveloperConsentRepository {
    override val developerConsent
        get() = developerConsentDataSource.developerConsent
}