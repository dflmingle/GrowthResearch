package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import com.unity3d.ads.core.data.model.LoadConfigurationInternal
import gatewayprotocol.v1.AdFormatOuterClass.AdFormat
import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

internal interface GetAdPlayerConfigRequest {
    suspend operator fun invoke(
        placement: String,
        opportunityId: ByteString,
        configToken: ByteString,
        adFormat: AdFormat?,
        loadConfiguration: LoadConfigurationInternal? = null,
    ): UniversalRequest
}