package com.unity3d.ads.core.domain

import gatewayprotocol.v1.UniversalRequestOuterClass.UniversalRequest

interface GetInitializationCompletedRequest {
    suspend operator fun invoke(): UniversalRequest
}