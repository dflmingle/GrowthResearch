package com.unity3d.ads.injection

class Factory<out T>(private val initializer: () -> T) : Lazy<T> {
    override val value: T
        get() = initializer()

    override fun isInitialized(): Boolean = false
}
