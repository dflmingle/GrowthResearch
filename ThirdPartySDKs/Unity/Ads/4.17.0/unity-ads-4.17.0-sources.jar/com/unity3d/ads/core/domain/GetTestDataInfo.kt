package com.unity3d.ads.core.domain

import gatewayprotocol.v1.TestDataOuterClass.TestData

interface GetTestDataInfo {
    fun invoke(): TestData?
}