package com.unity3d.ads.core.domain

interface CleanAssets {
    suspend operator fun invoke()
}