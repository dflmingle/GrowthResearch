package com.unity3d.ads.core.domain.privacy

import com.unity3d.services.core.di.ServiceProvider.DEV_CONSENT_PRIVACY_RULES
import com.unity3d.services.core.misc.JsonFlattenerRules





class DeveloperConsentFlattenerRulesUseCase : FlattenerRulesUseCase {
    override fun invoke(): JsonFlattenerRules {
        return JsonFlattenerRules(
        mutableListOf(
            "privacy",
            "gdpr",
            "pipl",
            "user"
        ),
        listOf("value"),
        mutableListOf(
            "ts",
            )
        )
    }
}