package com.unity3d.ads.adplayer

import com.unity3d.ads.adplayer.model.WebViewClientError

sealed class AdPlayerError(message: String) : Exception(message)
class LoadWebViewError(val errors: List<WebViewClientError>) : AdPlayerError("AdPlayer was not able to load the webview.")
