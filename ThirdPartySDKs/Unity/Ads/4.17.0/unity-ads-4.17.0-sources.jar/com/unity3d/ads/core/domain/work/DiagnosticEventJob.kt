package com.unity3d.ads.core.domain.work

import android.content.Context
import androidx.work.WorkerParameters
import com.unity3d.ads.core.domain.GetRequestPolicy
import com.unity3d.ads.core.domain.events.UniversalRequestEventSender
import com.unity3d.services.core.di.IServiceComponent
import com.unity3d.services.core.di.ServiceProvider
import com.unity3d.services.core.di.inject
import gatewayprotocol.v1.UniversalRequestOuterClass

internal class DiagnosticEventJob(
    context: Context,
    workerParams: WorkerParameters
) : UniversalRequestJob(context, workerParams), IServiceComponent {

    private val getDiagnosticRequestPolicy: GetRequestPolicy by inject(ServiceProvider.NAMED_OTHER_REQ)
    private val diagnosticEventRequestWorkModifier: DiagnosticEventRequestWorkModifier by inject()

    override val universalRequestEventSender: UniversalRequestEventSender by inject(ServiceProvider.DIAGNOSTICS_EVENT_SENDER)

    override suspend fun doWork(): Result {
        return try {
            val universalRequestId =
                workerParams.inputData.getString(UniversalRequestWorkerData.KEY_UNIVERSAL_REQUEST_ID)?: return Result.success()
            val rawUniversalRequest = runCatching {
                universalRequestDataSource.get().getUniversalRequestMapOrThrow(universalRequestId)
            }.getOrElse {
                // Request is not in storage anymore, mark as success so that its cleared from WorkDB
                return Result.success()
            }
            val universalRequest = UniversalRequestOuterClass.UniversalRequest.parseFrom(rawUniversalRequest)
            val modifiedUniversalRequest = diagnosticEventRequestWorkModifier(universalRequest)
            universalRequestDataSource.set(universalRequestId, modifiedUniversalRequest.toByteString())
            requestPolicy = getDiagnosticRequestPolicy()
            super.doWork()
        } catch (exception: Throwable) {
            logger.trace("DiagnosticEventJob failed to process work", exception)
            return Result.retry()
        }
    }
}