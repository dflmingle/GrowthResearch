package com.unity3d.ads.core.domain

import com.google.protobuf.kotlin.toByteStringUtf8
import com.unity3d.ads.AdFormat
import com.unity3d.ads.TokenConfiguration
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.core.data.manager.OfferwallManager
import com.unity3d.ads.core.data.repository.CampaignRepository
import com.unity3d.ads.core.data.repository.DeviceInfoRepository
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.data.repository.TcfRepository
import com.unity3d.ads.core.extensions.toProtoAdFormat
import gatewayprotocol.v1.HeaderBiddingTokenOuterClass.HeaderBiddingToken
import gatewayprotocol.v1.bannerSize
import gatewayprotocol.v1.headerBiddingToken
import gatewayprotocol.v1.tokenCounters

internal class AndroidBuildHeaderBiddingToken(
    private val generateId: GetByteStringId,
    private val getClientInfo: GetClientInfo,
    private val getTimestamps: GetSharedDataTimestamps,
    private val getLimitedSessionToken: GetLimitedSessionToken,
    private val getInitializationData: GetInitializationData,
    private val deviceInfoRepository: DeviceInfoRepository,
    private val sessionRepository: SessionRepository,
    private val campaignRepository: CampaignRepository,
    private val tcfRepository: TcfRepository,
    private val testDataInfo: AndroidTestDataInfo,
    private val offerwallManager: OfferwallManager,
    private val mediationInfoConverter: MediationInfoConverter
) : BuildHeaderBiddingToken {
    @OptIn(UnityAdsExperimental::class)
    override suspend fun invoke(tokenNumber: Int,
                                tokenConfiguration: TokenConfiguration?,
                                scarSignalsCollected: Boolean): HeaderBiddingToken {
        val currentTokenCounters = sessionRepository.tokenCounters
        val sToken = sessionRepository.sessionToken

        sessionRepository.incrementTokenSequenceNumber()

        return headerBiddingToken {
            // Common fields
            tokenId = generateId()
            this.tokenNumber = tokenNumber
            clientInfo = getClientInfo()
            timestamps = getTimestamps()
            tokenConfiguration?.let { tokenConfig ->
                adFormat = tokenConfig.adFormat.toProtoAdFormat()
                extras.putAll(tokenConfig.extras)
                tokenConfig.mediationInfo?.let { mediationInfo = mediationInfoConverter(it) }
                tokenConfig.placementId?.let { placementId = it }
                tokenConfig.mediationAdUnitId?.let { mediationAdUnitId = it }
                tokenConfig.bannerSize?.let { size ->
                    bannerSize = bannerSize {
                        width = size.width
                        height = size.height
                    }
                }
            }
            sessionCounters = sessionRepository.sessionCounters
            dynamicDeviceInfo = deviceInfoRepository.dynamicDeviceInfo
            val piiData = deviceInfoRepository.piiData
            pii = piiData
            campaignState = campaignRepository.getCampaignState()
            tcfRepository.tcfString?.let { tcf = it.toByteStringUtf8() }
            this.scarSignalsCollected = scarSignalsCollected
            this.offerwallEnabled = offerwallManager.isConnected()
            // Specific fields
            if (sToken.isEmpty) {
                if (sessionRepository.gameId?.isNotEmpty() == true) {
                    // Init Token
                    initializationData = getInitializationData()
                } else {
                    // Limited Token
                    limitedSessionToken = getLimitedSessionToken()
                }
                staticDeviceInfo = deviceInfoRepository.staticDeviceInfo()
            } else {
                // Full Session
                sessionToken = sessionRepository.sessionToken
                staticDeviceInfo = deviceInfoRepository.cachedStaticDeviceInfo()
            }
            testDataInfo()?.let { testData = it }
            tokenCounters = tokenCounters {
                seq = currentTokenCounters.seq
                wins = currentTokenCounters.wins
                starts = currentTokenCounters.starts
            }
        }
    }
}