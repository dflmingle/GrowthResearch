package com.unity3d.ads.core.domain

import com.unity3d.ads.core.data.model.AdObject

interface GetAdObject {
    operator fun invoke(opportunityId: String): AdObject?
}