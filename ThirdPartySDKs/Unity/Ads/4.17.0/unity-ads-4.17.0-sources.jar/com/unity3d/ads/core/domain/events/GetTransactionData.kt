package com.unity3d.ads.core.domain.events

import com.unity3d.services.store.gpbl.bridges.PurchaseBridge
import gatewayprotocol.v1.TransactionEventRequestOuterClass

fun interface GetTransactionData {
    operator fun invoke(purchaseDetail: PurchaseBridge, productDetailJson: String): TransactionEventRequestOuterClass.TransactionData
}