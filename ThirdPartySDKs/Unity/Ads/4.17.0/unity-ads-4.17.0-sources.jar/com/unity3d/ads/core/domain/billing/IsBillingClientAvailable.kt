package com.unity3d.ads.core.domain.billing

class IsBillingClientAvailable {
    operator fun invoke(): Boolean = runCatching {
        Class.forName("com.android.billingclient.api.BillingClient")
    }.isSuccess
}