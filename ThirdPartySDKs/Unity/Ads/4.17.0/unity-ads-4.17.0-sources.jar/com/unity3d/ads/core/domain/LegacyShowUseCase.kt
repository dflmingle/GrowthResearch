package com.unity3d.ads.core.domain

import com.google.protobuf.ByteString
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsExperimental
import com.unity3d.ads.UnityAdsLoadOptions
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.adplayer.EmbeddableAdPlayer
import com.unity3d.ads.adplayer.model.ShowStatus
import com.unity3d.ads.core.data.model.AdObject
import com.unity3d.ads.core.data.model.AdObjectState
import com.unity3d.ads.core.data.model.InitializationState
import com.unity3d.ads.core.data.model.Listeners
import com.unity3d.ads.core.data.model.LoadResult.Companion.MSG_NOT_INITIALIZED
import com.unity3d.ads.core.data.model.LoadResult.Companion.MSG_PLACEMENT_NULL
import com.unity3d.ads.core.data.model.OperationType
import com.unity3d.ads.core.data.model.ShowEvent
import com.unity3d.ads.core.data.repository.AdRepository
import com.unity3d.ads.core.data.repository.SessionRepository
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.NEW_API
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.OPERATION
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_AD_OBJECT_EXPIRED
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_AD_OBJECT_NOT_FOUND
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_AD_PLAYER_SCOPE
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_ALREADY_SHOWING
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_CODE
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_DEBUG
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_NOT_INITIALIZED
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_OPPORTUNITY_ID
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_PLACEMENT_NOT_LOADED
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_PLACEMENT_NULL
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_PLACEMENT_VALIDATION
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_TIMEOUT
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_UNCAUGHT_EXCEPTION
import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.SHOW_FAILURE
import com.unity3d.ads.core.domain.events.GetOperativeEventApi
import com.unity3d.ads.core.extensions.elapsedMillis
import com.unity3d.ads.core.extensions.getShortenedStackTrace
import com.unity3d.ads.core.extensions.timeoutAfter
import com.unity3d.ads.core.extensions.toByteString
import com.unity3d.ads.core.extensions.toUUID
import com.unity3d.ads.core.extensions.toUnityAdsShowCompletionState
import com.unity3d.ads.core.log.Logger
import com.unity3d.services.UnityAdsConstants.Messages.MSG_INTERNAL_ERROR
import gatewayprotocol.v1.DiagnosticEventRequestOuterClass.DiagnosticAdType.DIAGNOSTIC_AD_TYPE_UNSPECIFIED
import gatewayprotocol.v1.OperativeEventRequestOuterClass.OperativeEventErrorType
import gatewayprotocol.v1.OperativeEventRequestOuterClass.OperativeEventType
import gatewayprotocol.v1.operativeEventErrorData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.isActive
import java.util.UUID
import kotlin.time.ExperimentalTime
import kotlin.time.TimeMark
import kotlin.time.TimeSource

@OptIn(ExperimentalTime::class)
internal class LegacyShowUseCase(
    private val show: Show,
    private val adRepository: AdRepository,
    private val sendDiagnosticEvent: SendDiagnosticEvent,
    private val getOperativeEventApi: GetOperativeEventApi,
    private val getInitializationState: GetInitializationState,
    private val sessionRepository: SessionRepository,
    private val safeCallbackInvoke: SafeCallbackInvoke,
    private val logger: Logger,
) {
    private val hasStarted = MutableStateFlow(false)
    private val timeoutCancellationRequested = MutableStateFlow(false)
    private var adObject: AdObject? = null
    private var placement: String? = null
    private var unityAdsShowOptions: UnityAdsShowOptions? = null

    suspend operator fun invoke(
        placement: String?,
        unityAdsShowOptions: UnityAdsShowOptions?,
        listeners: Listeners
    ) {
        val startTime = TimeSource.Monotonic.markNow()
        this.placement = placement
        this.unityAdsShowOptions = unityAdsShowOptions
        logger.debug("Show for placement $placement called")
        var isWrongObjectIdFormat = false
        var placementNotLoaded = false

        val opportunityId = runCatching {
            // First check in the show options for a valid opportunityId
            unityAdsShowOptions?.let(::getOpportunityId)
        }.getOrElse {
            // If the opportunityId provided is not in proper format, send an error
            isWrongObjectIdFormat = true
            // Generate a UUID if invalid
            UUID.randomUUID().toString()
        } ?: run {
            // If the opportunityId is not found in the show options, check if the placement is loaded
            if (placement != null) {
                val opportunityIdForPlacement = adRepository.pollOpportunityIdForPlacement(placement)?.toUUID()?.toString()
                if (opportunityIdForPlacement == null) {
                    placementNotLoaded = true
                    UUID.randomUUID().toString()
                } else {
                    opportunityIdForPlacement
                }
            } else {
                // If no placement is provided, generate a new UUID
                UUID.randomUUID().toString()
            }

        }

        showStart(
            opportunityId = opportunityId,
            showOptions = unityAdsShowOptions
        )

        val reportShowError = showError(startTime, placement ?: "", opportunityId, listeners, unityAdsShowOptions)

        if (getInitializationState() != InitializationState.INITIALIZED) {
            reportShowError(REASON_NOT_INITIALIZED, UnityAds.UnityAdsShowError.NOT_INITIALIZED, MSG_NOT_INITIALIZED, null, null)
            return
        }

        if (placement == null) {
            reportShowError(REASON_PLACEMENT_NULL, UnityAds.UnityAdsShowError.INVALID_ARGUMENT, MSG_PLACEMENT_NULL, null, null)
            return
        }

        if (isWrongObjectIdFormat) {
            val objectId = unityAdsShowOptions?.data?.opt(KEY_OBJECT_ID)?.toString()
            reportShowError(REASON_OPPORTUNITY_ID, UnityAds.UnityAdsShowError.INVALID_ARGUMENT, MESSAGE_OPPORTUNITY_ID, null, objectId)
            return
        }

        if (placementNotLoaded) {
            reportShowError(REASON_PLACEMENT_NOT_LOADED, UnityAds.UnityAdsShowError.INVALID_ARGUMENT, MESSAGE_PLACEMENT_NOT_LOADED.format(placement), null, null)
            return
        }

        val opportunityIdByteString = UUID.fromString(opportunityId).toByteString()
        val adObject = adRepository.getAd(opportunityIdByteString)
        this.adObject = adObject
        if (adObject == null) {
            reportShowError(REASON_AD_OBJECT_NOT_FOUND, UnityAds.UnityAdsShowError.INTERNAL_ERROR, MESSAGE_NO_AD_OBJECT + opportunityId, null, null)
            return
        }

        if (adObject.state.value == AdObjectState.EXPIRED) {
            reportShowError(REASON_AD_OBJECT_EXPIRED, UnityAds.UnityAdsShowError.EXPIRED, MESSAGE_AD_OBJECT_EXPIRED, null, null)
            adRepository.removeAd(opportunityIdByteString)
            return
        }

        if (adObject.adPlayer?.scope?.isActive == false) {
            reportShowError(REASON_AD_PLAYER_SCOPE, UnityAds.UnityAdsShowError.INTERNAL_ERROR, MESSAGE_AD_PLAYER_UNAVAILABLE, null, null)
            return
        }

        val isBanner = adObject.adPlayer is EmbeddableAdPlayer

        if (!isBanner && isFullscreenAdShowing) {
            reportShowError(REASON_ALREADY_SHOWING, UnityAds.UnityAdsShowError.ALREADY_SHOWING, MESSAGE_ALREADY_SHOWING, null, null)
            return
        }

        if (sessionRepository.nativeConfiguration.featureFlags.opportunityIdPlacementValidation && adObject.placementId != placement) {
            reportShowError(REASON_PLACEMENT_VALIDATION, UnityAds.UnityAdsShowError.INVALID_ARGUMENT, MSG_OPPORTUNITY_AND_PLACEMENT_NOT_MATCHING, null, null)
            return
        }

        val useTimeout = true // sessionRepository.nativeConfiguration.featureFlags.showTimeoutEnabled
        val timeoutMillis = sessionRepository.nativeConfiguration.adOperations.showTimeoutMs.toLong()

        if (!isBanner) {
            isFullscreenAdShowing = true
        }

        show(adObject, unityAdsShowOptions)
            .timeoutAfter(timeoutMillis) { close ->
                if (hasStarted.value || timeoutCancellationRequested.value) return@timeoutAfter
                sendOperativeError(
                    OperativeEventErrorType.OPERATIVE_EVENT_ERROR_TYPE_TIMEOUT,
                    MESSAGE_OPT_TIMEOUT,
                    adObject
                )
                if (useTimeout) {
                    show.terminate(adObject)
                    reportShowError(REASON_TIMEOUT, UnityAds.UnityAdsShowError.TIMEOUT, MESSAGE_TIMEOUT + placement, null, null)
                    close()
                }
            }
            .catch {
                // Will only catch exceptions thrown from upstream flows
                reportShowError(REASON_UNCAUGHT_EXCEPTION, UnityAds.UnityAdsShowError.INTERNAL_ERROR, MSG_INTERNAL_ERROR, null, it.getShortenedStackTrace())
                if (!isBanner) {
                    isFullscreenAdShowing = false
                }
            }
            .collect {
                try {
                    when (it) {
                        is ShowEvent.Started -> showStarted(startTime, placement, listeners)
                        is ShowEvent.Clicked -> showClicked(startTime, placement, listeners)
                        is ShowEvent.Completed -> showCompleted(startTime, placement, it.status, listeners, it.reason, it.reasonDebug, unityAdsShowOptions)
                        is ShowEvent.ReceivedReward -> showReceivedReward(startTime, placement, listeners)
                        is ShowEvent.Error -> {
                            if (hasStarted.value) {
                                // If show has started, trigger ShowEvent.Completed instead of error
                                showCompleted(startTime, placement, ShowStatus.ERROR, listeners, it.reason, it.message, unityAdsShowOptions)
                            } else {
                                // If show hasn't started yet, handle as normal error
                                sendOperativeError(
                                    OperativeEventErrorType.OPERATIVE_EVENT_ERROR_TYPE_UNSPECIFIED,
                                    it.message,
                                    adObject
                                )
                                reportShowError(it.reason, UnityAds.UnityAdsShowError.INTERNAL_ERROR, it.message, it.errorCode, it.message)
                            }
                        }

                        is ShowEvent.CancelTimeout -> cancelTimeout(startTime)
                        is ShowEvent.LeftApplication -> bannerLeftApplication(startTime, placement, listeners)
                    }
                } catch (exception: Throwable) {
                    // Ensure we call the show listeners onError callback on any unexpected exceptions happening inside the final flow collector
                    reportShowError(
                        REASON_UNCAUGHT_EXCEPTION,
                        UnityAds.UnityAdsShowError.INTERNAL_ERROR,
                        MSG_INTERNAL_ERROR,
                        null,
                        exception.getShortenedStackTrace()
                    )
                }
            }

        if (!isBanner) {
            isFullscreenAdShowing = false
        }

    }

    fun showReceivedReward(
        startTime: TimeMark,
        placement: String,
        listeners: Listeners
    ) {
        logger.info("Rewarding ad ${getAdInfoString()}")
        hasStarted.value = true
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_REWARDED,
            value = startTime.elapsedMillis(),
            adObject = adObject,
        )

        safeCallbackInvoke { listeners.onRewarded(placement) }
    }

    private fun bannerLeftApplication(startTime: TimeMark, placement: String, listeners: Listeners) {
        logger.info("Left app while showing ad ${getAdInfoString()}")
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_LEFT_APPLICATION,
            value = startTime.elapsedMillis(),
            adObject = adObject
        )
        safeCallbackInvoke { listeners.onLeftApplication(placement) }
    }

    private suspend fun sendOperativeError(
        operativeEvent: OperativeEventErrorType,
        operativeMessage: String,
        adObject: AdObject
    ) {
        val errorData = operativeEventErrorData {
            errorType = operativeEvent
            message = operativeMessage
        }
        getOperativeEventApi(
            operativeEventType = OperativeEventType.OPERATIVE_EVENT_TYPE_SHOW_ERROR,
            adObject = adObject,
            additionalEventData = errorData.toByteString()
        )
    }

    private fun cancelTimeout(startTime: TimeMark) {
        timeoutCancellationRequested.value = true
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_CANCEL_TIMEOUT,
            value = startTime.elapsedMillis(),
            adObject = adObject,
        )
    }

    private fun showStarted(startTime: TimeMark, placement: String, listeners: Listeners) {
        logger.info("Started showing ad ${getAdInfoString()}")
        hasStarted.value = true
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_WV_STARTED,
            value = startTime.elapsedMillis(),
            adObject = adObject,
        )

        safeCallbackInvoke { listeners.onStart(placement) }
    }

    private fun showClicked(startTime: TimeMark, placement: String, listeners: Listeners) {
        logger.info("Clicked on ad ${getAdInfoString()}")
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_CLICKED,
            value = startTime.elapsedMillis(),
            adObject = adObject,
        )
        safeCallbackInvoke { listeners.onClick(placement) }
    }

    @Throws(IllegalArgumentException::class)
    private fun getOpportunityId(unityAdsShowOptions: UnityAdsShowOptions): String? {
        return unityAdsShowOptions.data?.opt(KEY_OBJECT_ID)?.toString()?.let {
            UUID.fromString(it).toString()
        }
    }

    private fun showStart(opportunityId: String, showOptions: UnityAdsShowOptions?) =
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_STARTED,
            adObject = getTmpAdObject(opportunityId = opportunityId),
            tags = mapOf(
                NEW_API to (showOptions?.showConfiguration != null).toString()
            )
        )

    private fun showCompleted(
        startTime: TimeMark,
        placement: String,
        status: ShowStatus,
        listeners: Listeners,
        reason: String? = null,
        reasonDebug: String? = null,
        showOptions: UnityAdsShowOptions?
    ) {
        logger.info("Finished showing ad ${getAdInfoString()}")
        val tags = buildMap {
            reason?.let { put(REASON, it) }
            reasonDebug?.let { put(REASON_DEBUG, it) }
            NEW_API to (showOptions?.showConfiguration != null).toString()
        }
        sendDiagnosticEvent(
            event = SendDiagnosticEvent.SHOW_SUCCESS,
            value = startTime.elapsedMillis(),
            adObject = adObject,
            tags = tags
        )
        safeCallbackInvoke { listeners.onComplete(placement, status.toUnityAdsShowCompletionState(sessionRepository.nativeConfiguration.defaultShowCompletionState)) }
    }

    private fun showError(
        startTime: TimeMark,
        placement: String,
        opportunityId: String,
        listeners: Listeners,
        showOptions: UnityAdsShowOptions?
    ): suspend (String, UnityAds.UnityAdsShowError, String, Int?, String?) -> Unit =
        { diagnosticReason: String, reason: UnityAds.UnityAdsShowError, message: String, code: Int?, debugMessage: String? ->
            logger.error("Failed to show ad ${getAdInfoString()}, error: $message")
            val adObject = adObject ?: getTmpAdObject(opportunityId)
            sendDiagnosticEvent(event = SHOW_FAILURE, value = startTime.elapsedMillis(), tags = getTags(diagnosticReason, code, debugMessage, showOptions), adObject = adObject)
            safeCallbackInvoke { listeners.onError(placement, reason, message) }
        }

    private fun getTags(diagnosticReason: String, code: Int?, debugMessage: String?, showOptions: UnityAdsShowOptions?): Map<String, String> {
        return mutableMapOf(
            OPERATION to OperationType.SHOW.toString(),
            REASON to diagnosticReason,
            NEW_API to (showOptions?.showConfiguration != null).toString()
        ).apply {
            code?.let { put(REASON_CODE, it.toString()) }
            debugMessage?.let { put(REASON_DEBUG, it) }
        }
    }

    @OptIn(UnityAdsExperimental::class)
    private fun getTmpAdObject(opportunityId: String): AdObject {
        val opportunityIdByteString = UUID.fromString(opportunityId).toByteString()
        val adObject = adRepository.getAd(opportunityIdByteString)
        if (adObject != null) {
            return adObject
        }

        return AdObject(
            opportunityId = opportunityIdByteString,
            placementId = placement ?: "",
            trackingToken = ByteString.EMPTY,
            adPlayer = null,
            loadOptions = UnityAdsLoadOptions(),
            isHeaderBidding = false,
            adType = DIAGNOSTIC_AD_TYPE_UNSPECIFIED,
        )
    }

    private fun getAdInfoString(): String {
        return "for placement ${adObject?.placementId} with instance id ${adObject?.opportunityId?.toUUID()}"
    }

    companion object {
        const val KEY_OBJECT_ID = "objectId"
        const val MESSAGE_PLACEMENT_NOT_LOADED = "Placement %s must be Loaded before calling Show"
        const val MESSAGE_OPPORTUNITY_ID = "No valid opportunity id provided"
        const val MESSAGE_NO_AD_OBJECT = "No ad object found for opportunity id: "
        const val MESSAGE_ALREADY_SHOWING = "Can't show a new ad unit when ad unit is already open"
        const val MESSAGE_TIMEOUT = "[UnityAds] Timeout while trying to show "
        const val MESSAGE_AD_OBJECT_EXPIRED = "The ad has expired"
        const val MSG_OPPORTUNITY_AND_PLACEMENT_NOT_MATCHING =
            "[UnityAds] Object ID and Placement ID provided does not match previously loaded ad"
        const val MESSAGE_OPT_TIMEOUT = "timeout"
        const val MESSAGE_AD_PLAYER_UNAVAILABLE = "Ad player is unavailable."
        @Volatile
        private var isFullscreenAdShowing = false
    }
}