package com.unity3d.ads.core.data.datasource

interface TcfDataSource {
    val tcfString: String?
}