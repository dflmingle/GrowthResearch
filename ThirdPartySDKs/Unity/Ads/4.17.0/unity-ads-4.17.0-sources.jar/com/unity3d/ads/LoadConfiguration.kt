package com.unity3d.ads

@UnityAdsExperimental
class LoadConfiguration private constructor(
    val placementId: String,
    val adMarkup: String?,
    val mediationInfo: MediationInfo?,
    val mediationAdUnitId: String?,
    val extras: Map<String, String>,
) {
    class Builder(val placementId: String) {
        private var adMarkup: String? = null
        private var mediationInfo: MediationInfo? = null
        private var mediationAdUnitId: String? = null
        private var extras: Map<String, String> = emptyMap()

        fun withAdMarkup(adMarkup: String): Builder {
            this.adMarkup = adMarkup
            return this
        }

        fun withExtras(extras: Map<String, String>): Builder {
            this.extras = extras
            return this
        }

        fun withMediationInfo(mediationInfo: MediationInfo): Builder {
            this.mediationInfo = mediationInfo
            return this
        }

        fun withMediationAdUnitId(mediationAdUnitId: String): Builder {
            this.mediationAdUnitId = mediationAdUnitId
            return this
        }

        fun build(): LoadConfiguration {
            return LoadConfiguration(placementId, adMarkup, mediationInfo, mediationAdUnitId, extras)
        }
    }
}