package com.unity3d.ads.core.domain

import gatewayprotocol.v1.NativeConfigurationOuterClass.RequestPolicy

interface GetSafeguardedInitializationPolicy {
    operator fun invoke(requestPolicy: RequestPolicy): RequestPolicy
}