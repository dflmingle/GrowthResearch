package com.unity3d.ads.core.domain

interface TriggerInitializationCompletedRequest {
    suspend operator fun invoke()
}