package com.unity3d.ads.core.data.model

import com.iab.omid.library.unity3d.adsession.CreativeType
import com.iab.omid.library.unity3d.adsession.ImpressionType
import com.iab.omid.library.unity3d.adsession.Owner

data class OmidOptions (
    val isolateVerificationScripts: Boolean = false,
    val impressionOwner: Owner? = null,
    val videoEventsOwner: Owner? = null,
    val customReferenceData: String? = null,
    val impressionType: ImpressionType? = null,
    val creativeType: CreativeType? = null,
    val mediaEventsOwner: Owner? = null,
)