package com.unity3d.ads.core.data.repository

interface LegacyUserConsentRepository {
    val legacyFlowUserConsent: String?
}