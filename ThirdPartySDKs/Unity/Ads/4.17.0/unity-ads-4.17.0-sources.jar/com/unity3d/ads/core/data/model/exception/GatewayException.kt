package com.unity3d.ads.core.data.model.exception

import com.unity3d.ads.core.domain.SendDiagnosticEvent.Companion.REASON_GATEWAY
import gatewayprotocol.v1.ErrorOuterClass.PublicErrorCode

data class GatewayException(
    override val message: String,
    val throwable: Throwable? = null,
    val reason: String = REASON_GATEWAY,
    val reasonDebug: String? = null,
    val errorCode: PublicErrorCode? = null,
) : UnityAdsNetworkException(message) {
    companion object {
        const val GATEWAY_RESPONSE_DEPTH_UNIVERSAL = "universal"
        const val GATEWAY_RESPONSE_DEPTH_INITIALIZATION = "initialization"
    }
}