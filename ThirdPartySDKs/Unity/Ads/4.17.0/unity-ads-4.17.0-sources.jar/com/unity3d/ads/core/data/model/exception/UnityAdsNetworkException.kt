package com.unity3d.ads.core.data.model.exception

import com.unity3d.ads.core.data.model.OperationType

open class UnityAdsNetworkException(
    override val message: String,
    val type: OperationType = OperationType.UNKNOWN,
    val code: Int? = null,
    val url: String? = null,
    val protocol: String? = null,
    val cronetCode: Int? = null,
    val client: String? = null,
) : Exception(message)