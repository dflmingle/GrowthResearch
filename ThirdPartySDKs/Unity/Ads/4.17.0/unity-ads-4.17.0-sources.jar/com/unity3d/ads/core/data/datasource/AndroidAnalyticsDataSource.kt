package com.unity3d.ads.core.data.datasource

import com.unity3d.services.core.preferences.AndroidPreferences
import com.unity3d.services.core.properties.ClientProperties

class AndroidAnalyticsDataSource : AnalyticsDataSource {
    override val userId : String?
        get() = AndroidPreferences.getString(ClientProperties.getAppName() + ".v2.playerprefs", "unity.cloud_userid")
}