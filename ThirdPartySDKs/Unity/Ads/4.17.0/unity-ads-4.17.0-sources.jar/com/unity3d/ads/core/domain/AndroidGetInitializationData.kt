package com.unity3d.ads.core.domain

import gatewayprotocol.v1.initializationData

class AndroidGetInitializationData(
    private val getInitializeRequestPayload: GetInitializationRequestPayload,
    private val getUniversalRequestSharedData: GetUniversalRequestSharedData,
) : GetInitializationData {
    override suspend fun invoke() = initializationData {
        initializationRequest = getInitializeRequestPayload()
        sharedData = getUniversalRequestSharedData()
    }
}