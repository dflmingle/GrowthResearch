package com.unity3d.ads.core.data.datasource

fun interface StoreDataSource {
    fun fetchStores(additionalStores: List<String>): List<String>
}