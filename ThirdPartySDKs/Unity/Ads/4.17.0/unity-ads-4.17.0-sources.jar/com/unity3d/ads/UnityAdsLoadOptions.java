package com.unity3d.ads;

import com.unity3d.ads.core.data.model.LoadConfigurationInternal;
import androidx.annotation.RestrictTo;

public class UnityAdsLoadOptions extends UnityAdsBaseOptions {
	private String AD_MARKUP = "adMarkup";

	public UnityAdsLoadOptions() {
		super();
	}

	public void setAdMarkup(String adMarkup) {
		set(AD_MARKUP, adMarkup);
	}

	@RestrictTo(RestrictTo.Scope.LIBRARY)
	public LoadConfigurationInternal loadConfiguration = null;
}
