package com.unity3d.ads.core.domain

import gatewayprotocol.v1.ClientInfoOuterClass

class CommonMediationProviderParser : MediationProviderParser {
    override fun invoke(mediationProvider: String?): ClientInfoOuterClass.MediationProvider {
        return mediationProvider?.let {
            when {
                it.startsWith("AppLovinSdk_") -> ClientInfoOuterClass.MediationProvider.MEDIATION_PROVIDER_MAX
                it.equals("AdMob", ignoreCase = true) -> ClientInfoOuterClass.MediationProvider.MEDIATION_PROVIDER_ADMOB
                it.equals("MAX", ignoreCase = true) -> ClientInfoOuterClass.MediationProvider.MEDIATION_PROVIDER_MAX
                it.equals("ironSource", ignoreCase = true) -> ClientInfoOuterClass.MediationProvider.MEDIATION_PROVIDER_LEVELPLAY
                else -> ClientInfoOuterClass.MediationProvider.MEDIATION_PROVIDER_CUSTOM
            }
        } ?: ClientInfoOuterClass.MediationProvider.MEDIATION_PROVIDER_UNSPECIFIED
    }
}