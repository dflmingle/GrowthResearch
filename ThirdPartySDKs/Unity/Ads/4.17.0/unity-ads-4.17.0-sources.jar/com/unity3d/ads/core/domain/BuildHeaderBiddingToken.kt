package com.unity3d.ads.core.domain

import com.unity3d.ads.TokenConfiguration
import gatewayprotocol.v1.HeaderBiddingTokenOuterClass.HeaderBiddingToken

interface BuildHeaderBiddingToken {
    suspend operator fun invoke(tokenNumber: Int, tokenConfiguration: TokenConfiguration? = null, scarSignalsCollected: Boolean = false): HeaderBiddingToken
}