package com.unity3d.ads.core.domain

interface InitializeBoldSDK {
    suspend operator fun invoke(source: String)
}
