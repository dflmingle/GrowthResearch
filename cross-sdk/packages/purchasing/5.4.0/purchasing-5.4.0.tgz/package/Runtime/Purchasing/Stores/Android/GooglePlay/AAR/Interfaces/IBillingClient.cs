using System;
using System.Collections.Generic;
using UnityEngine.Purchasing.Models;

namespace UnityEngine.Purchasing.GoogleBilling.Interfaces
{
    interface IBillingClient : IBillingClientBase
    {
        void GetBillingConfigAsync(Action<IGoogleBillingResult, string> onBillingConfigResponse);
        void QueryPurchasesAsync(string skuType, Action<IGoogleBillingResult, IEnumerable<AndroidJavaObject>> onQueryPurchasesResponse);
        void QueryProductDetailsAsync(List<string> skus, string type, Action<IGoogleBillingResult, List<AndroidJavaObject>> onProductDetailsResponseAction);
        AndroidJavaObject LaunchBillingFlow(AndroidJavaObject productDetails, string oldPurchaseToken, GooglePlayReplacementMode? replacementMode);
        void ConsumeAsync(string purchaseToken, Action<IGoogleBillingResult> onConsume);
        void AcknowledgePurchase(string purchaseToken, Action<IGoogleBillingResult> onAcknowledge);
        void SetObfuscationAccountId(string obfuscationAccountId);
        void SetObfuscationProfileId(string obfuscationProfileId);
    }
}
